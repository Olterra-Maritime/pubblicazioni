import sys
from common import *
d = newdoc()
W = (2000, 2100, 4400, 860)
H = ['Termine', 'Inglese', 'Significato', 'Lezione']
MISS = []
def T(rows):
    out = []
    for a, b, c, p in rows:
        try: out.append((a, b, c, where(p, slides=False)))
        except SystemExit as e: MISS.append(a)
    table(d, H, out, W)
P = d.add_paragraph
d.add_heading('Glossario', 1)
d.add_heading(TIT, 2)
P(HEAD)
P('Termini tecnici italiani delle tre lezioni con l\'equivalente inglese usato nelle regole IACS, nei certificati e a bordo. La colonna "Lezione" indica dove il termine compare (L1 acciai, L2 altri materiali e saldatura, L3 corrosione e bacino). Le sigle sono nel documento separato "Sigle e acronimi".')

d.add_heading('Acciai e trattamenti', 2)
T([
    ('Acciaio da scafo', 'Hull structural steel', 'Acciaio laminato per la struttura dello scafo, certificato secondo la UR W11', r'acciai[oe]? da scafo'),
    ('Grado', 'Grade', 'Combinazione di resistenza e tenacità (es. A, DH36) che identifica l\'acciaio', r'\bgrad[oi]\b'),
    ('Snervamento', 'Yield strength', 'Tensione oltre la quale la deformazione diventa permanente', r'snervamento'),
    ('Resistenza a trazione', 'Tensile strength', 'Tensione massima sopportata nella prova di trazione', r'resistenza a trazione'),
    ('Duttilità', 'Ductility', 'Capacità di deformarsi plasticamente prima di rompersi', r'duttil'),
    ('Tenacità', 'Toughness', 'Capacità di assorbire energia in presenza di un intaglio; si misura con la prova Charpy', r'tenacit'),
    ('Rottura fragile', 'Brittle fracture', 'Rottura improvvisa senza deformazione, favorita da basse temperature e intagli', r'fragil'),
    ('Temperatura di transizione', 'Transition temperature', 'Temperatura sotto la quale l\'acciaio passa da comportamento duttile a fragile', r'transizione'),
    ('Strappo lamellare', 'Lamellar tearing', 'Distacco a gradini nello spessore della lamiera sotto trazione trasversale; si previene con acciai Z', r'strappo lamellare'),
    ('Normalizzazione', 'Normalizing', 'Riscaldo sopra la trasformazione e raffreddamento in aria: grano fine', r'normalizz'),
    ('Laminazione termomeccanica', 'Thermo-mechanical rolling', 'Laminazione a temperature controllate che dà resistenza e tenacità con poco carbonio', r'termomeccanic'),
    ('Bonifica', 'Quenching and tempering', 'Tempra seguita da rinvenimento', r'bonific'),
    ('Carbonio equivalente', 'Carbon equivalent', 'Indice della saldabilità che somma gli effetti degli elementi di lega', r'carbonio equivalente'),
    ('Fattore del materiale', 'Material factor', 'Coefficiente k delle regole che riduce lo spessore per gli acciai ad alta resistenza', r'fattore (del materiale|k)'),
    ('Classe di materiale', 'Material class', 'Classe I–III (CSR) che con lo spessore determina il grado richiesto per ogni elemento', r'class[ei] di materiale'),
    ('Certificato del materiale', 'Material certificate', 'Documento dell\'acciaieria con colata, composizione, prove e timbro della classe', r'certificat'),
    ('Marcatura', 'Marking', 'Identificazione stampata sulla lamiera: grado, colata, timbro della classe', r'marcatura'),
])

d.add_heading('Altri materiali', 2)
T([
    ('Acciaio inossidabile', 'Stainless steel', 'Acciaio con almeno 10,5 % di cromo, protetto da un film passivo', r'inossidabil'),
    ('Austenitico', 'Austenitic', 'Famiglia di inox al cromo-nichel (es. 316L), amagnetica e tenace a bassa temperatura', r'austenitic'),
    ('Duplex', 'Duplex', 'Inox austeno-ferritico, più resistente e meno sensibile alla tensocorrosione', r'duplex'),
    ('Film passivo', 'Passive film', 'Strato sottile di ossidi di cromo che protegge l\'inox', r'passiv'),
    ('Ghisa sferoidale', 'Spheroidal graphite (nodular) cast iron', 'Ghisa con grafite a noduli, duttile (UR W10)', r'sferoidal|nodular'),
    ('Ghisa grigia', 'Grey cast iron', 'Ghisa con grafite lamellare, fragile (UR W9)', r'ghisa grigia|ghise grigie'),
    ('Getto', 'Casting', 'Pezzo ottenuto colando metallo in forma', r'\bgett[oi]\b'),
    ('Fucinato', 'Forging', 'Pezzo deformato a caldo per pressatura o martellatura', r'fucinat'),
    ('Lega di alluminio', 'Aluminium alloy', 'Leghe 5xxx e 6xxx per sovrastrutture e unità veloci (UR W25)', r'allumini'),
    ('Giunto bimetallico', 'Bimetallic transition joint', 'Elemento placcato acciaio-alluminio che separa i due metalli', r'bimetallic'),
    ('Cupronichel', 'Copper-nickel', 'Lega rame-nichel (90/10, 70/30) per tubi di acqua di mare', r'cupronichel'),
    ('Vetroresina', 'Glass reinforced plastic', 'Composito di fibre di vetro e resina', r'vetroresina'),
    ('Amianto', 'Asbestos', 'Minerale fibroso cancerogeno, vietato a bordo (SOLAS II-1/3-5)', r'amianto'),
])

d.add_heading('Prove e controlli', 2)
T([
    ('Prova di trazione', 'Tensile test', 'Prova che misura snervamento, resistenza e allungamento', r'prova di trazione|prove di trazione'),
    ('Prova di resilienza (Charpy)', 'Charpy V-notch impact test', 'Provino intagliato rotto con un pendolo: energia assorbita a una temperatura data', r'Charpy'),
    ('Prova di piega', 'Bend test', 'Piegatura del provino saldato per verificare duttilità e difetti', r'piega'),
    ('Durezza', 'Hardness', 'Resistenza alla penetrazione (Vickers, Brinell, Rockwell)', r'durezza'),
    ('Controllo non distruttivo', 'Non-destructive testing', 'Esame che non danneggia il pezzo (visivo, liquidi penetranti, magnetoscopia, ultrasuoni, radiografia)', r'non distruttiv'),
    ('Liquidi penetranti', 'Dye penetrant', 'Controllo delle cricche aperte in superficie', r'liquidi penetranti'),
    ('Magnetoscopia', 'Magnetic particle inspection', 'Controllo di cricche superficiali nei materiali ferromagnetici', r'magnetoscop'),
    ('Ultrasuoni', 'Ultrasonic testing', 'Controllo di difetti interni e misura degli spessori', r'ultrasuoni'),
    ('Spessimetria', 'Thickness measurement', 'Campagna di misure di spessore a ultrasuoni', r'spessimetri'),
])

d.add_heading('Saldatura', 2)
T([
    ('Procedimento di saldatura', 'Welding procedure', 'Insieme di processo, materiali e parametri qualificato con prove', r'procediment'),
    ('Qualifica del saldatore', 'Welder qualification', 'Prova che abilita il saldatore per processo, posizione e spessori (UR W32)', r'qualific'),
    ('Materiale d\'apporto', 'Welding consumable', 'Elettrodo o filo approvato per il grado di acciaio (UR W17)', r'apporto'),
    ('Preriscaldo', 'Preheating', 'Riscaldo dei lembi prima di saldare per evitare cricche a freddo', r'preriscald'),
    ('Cricca a freddo', 'Cold crack', 'Cricca da idrogeno che si forma ore dopo la saldatura', r'cricch?[ea] a freddo'),
    ('Porosità', 'Porosity', 'Bolle di gas nel cordone', r'porosit'),
    ('Mancata fusione', 'Lack of fusion', 'Zona in cui il metallo d\'apporto non si è fuso con il metallo base', r'mancata fusione|incollatur'),
    ('Sottotaglio', 'Undercut', 'Solco al bordo del cordone che riduce la sezione e innesca fatica', r'sottotagli|marginatur'),
    ('Lavoro a caldo', 'Hot work', 'Saldatura, taglio o molatura a bordo: richiede permesso, bonifica e sorveglianza', r'lavor[oi] a caldo'),
    ('Spazio chiuso', 'Enclosed space', 'Ambiente con aria non garantita: ingresso solo con permesso e misure dell\'atmosfera', r'spazi[oi] chius'),
])

d.add_heading('Corrosione e protezione', 2)
T([
    ('Corrosione', 'Corrosion', 'Degrado del metallo per reazione elettrochimica con l\'ambiente', r'corrosione'),
    ('Anodo / catodo', 'Anode / cathode', 'Elettrodo che si corrode / elettrodo protetto della cella di corrosione', r'anodo'),
    ('Elettrolita', 'Electrolyte', 'Liquido conduttore (acqua di mare) che chiude la cella', r'elettrolit'),
    ('Serie galvanica', 'Galvanic series', 'Ordine dei metalli per potenziale in acqua di mare', r'serie galvanica'),
    ('Corrosione galvanica', 'Galvanic corrosion', 'Corrosione del metallo meno nobile accoppiato a uno più nobile', r'galvanica'),
    ('Pitting (vaiolatura)', 'Pitting', 'Crateri localizzati più profondi della corrosione media', r'pitting'),
    ('Corrosione ai bordi', 'Edge corrosion', 'Corrosione locale ai bordi liberi e intorno alle aperture', r'bordi liberi|corrosione ai bordi'),
    ('Solchi', 'Grooving', 'Corrosione lineare lungo le saldature e i rinforzi', r'grooving|solchi'),
    ('Corrosione interstiziale', 'Crevice corrosion', 'Corrosione in fessure e sotto depositi dove manca ossigeno', r'interstizial'),
    ('Erosione-corrosione', 'Erosion-corrosion', 'Corrosione accelerata da flusso veloce o turbolento', r'erosione'),
    ('Cavitazione', 'Cavitation', 'Danno da implosione di bolle di vapore su eliche, giranti, camicie', r'cavitazione'),
    ('Dezincificazione', 'Dezincification', 'Perdita selettiva dello zinco negli ottoni', r'dezincific|dealligazione'),
    ('Tensocorrosione', 'Stress corrosion cracking', 'Cricche per sforzo e ambiente specifico insieme', r'tensocorrosione|sotto sforzo'),
    ('Fatica-corrosione', 'Corrosion fatigue', 'Fatica accelerata dall\'ambiente corrosivo', r'fatica-corrosione|corrosione e fatica'),
    ('Corrosione a freddo', 'Cold corrosion', 'Attacco da acido solforico condensato sulle camicie dei motori a due tempi', r'cold corrosion|corrosione a freddo'),
    ('Corrosione a caldo', 'Hot corrosion', 'Attacco da ceneri fuse di vanadio e sodio su valvole e turbine', r'hot corrosion|corrosione a caldo'),
    ('Punto di rugiada acido', 'Acid dew point', 'Temperatura sotto la quale condensa l\'acido dei fumi', r'rugiada acid'),
    ('Margine di corrosione', 'Corrosion addition', 'Spessore aggiunto dalle regole per la corrosione prevista', r'margin[ei] di corrosione'),
    ('Spessore netto', 'Net thickness', 'Spessore usato nei calcoli CSR, senza margine di corrosione', r'spessore netto|spessori netti'),
    ('Spessore di rinnovo', 'Renewal thickness', 'Spessore sotto il quale l\'elemento va sostituito', r'rinnovo'),
    ('Corrosione sostanziale', 'Substantial corrosion', 'Corrosione vicina al limite: richiede misure alle visite successive', r'corrosione sostanziale'),
    ('Rivestimento', 'Coating', 'Pittura protettiva; stato GOOD, FAIR o POOR', r'rivestiment'),
    ('Sabbiatura', 'Blast cleaning', 'Preparazione della superficie con abrasivo (grado Sa 2½)', r'sabbiatur'),
    ('Antivegetativa', 'Antifouling', 'Pittura di carena che impedisce l\'attecchimento di organismi', r'antivegetativ'),
    ('Anodo sacrificale', 'Sacrificial anode', 'Blocco di zinco, alluminio o magnesio che si consuma al posto dello scafo', r'anod[oi] sacrifical'),
    ('Corrente impressa', 'Impressed current', 'Protezione catodica con anodi inerti alimentati e regolati', r'corrente impressa'),
    ('Sovraprotezione', 'Overprotection', 'Potenziale troppo negativo: distacco della pittura, idrogeno', r'sovraprotezione'),
])

d.add_heading('Visite e bacino', 2)
T([
    ('Visita annuale / intermedia / di rinnovo', 'Annual / intermediate / renewal (special) survey', 'Visite del ciclo di classe quinquennale (UR Z7)', r'visit[ae] annual'),
    ('Visita della carena', 'Bottom survey', 'Esame dell\'opera viva in bacino o in acqua, due volte in 5 anni', r'visit[ae] della carena'),
    ('Bacino di carenaggio', 'Dry dock', 'Struttura in cui la nave resta all\'asciutto per visite e lavori', r'bacino'),
    ('Taccate', 'Keel blocks', 'Appoggi su cui posa la chiglia in bacino', r'taccat'),
    ('Piano di invasatura', 'Docking plan', 'Disegno con posizioni delle taccate e delle aperture di fondo', r'invasatura'),
    ('Lista lavori', 'Repair specification / work list', 'Elenco dei lavori da eseguire in bacino', r'lista lavori'),
    ('Abbassamento dell\'asse', 'Shaft weardown', 'Usura del cuscinetto poppiero misurata nel bacino', r'abbassamento'),
    ('Tenuta dell\'astuccio', 'Stern tube seal', 'Tenuta che separa l\'olio dell\'astuccio dall\'acqua di mare', r'tenut[ae]'),
    ('Agugliotto', 'Pintle', 'Perno su cui ruota il timone', r'agugliott'),
    ('Cassa di presa', 'Sea chest', 'Cassa nello scafo da cui aspirano le pompe dell\'acqua di mare', r'cass[ae] di presa'),
    ('Valvola di fasciame', 'Shipside valve', 'Valvola montata sullo scafo su una presa o uno scarico a mare', r'valvol[ae] di fasciame'),
    ('Manutenzione su condizione', 'Condition-based maintenance', 'Intervento deciso dalle misure (vibrazioni, olio, temperature)', r'su condizione|condition based'),
])

finish(d, 'out/Glossario_UD_4.1.1A_Materiali.docx')
print('MANCANTI', MISS)
