from common import *
d = newdoc()
W = (1500, 2500, 3900, 1460)
H = ['Sigla', 'Per esteso', 'Spiegazione in chiaro', 'Dove (lezione: slide)']
def T(rows): table(d, H, [(a, b, c, where(p)) for a, b, c, p in rows], W)
P = d.add_paragraph
d.add_heading('Sigle e acronimi', 1)
d.add_heading(TIT, 2)
P(HEAD)
P('Le sigle che compaiono nelle slide e nelle note del docente delle tre lezioni, sciolte e spiegate con parole semplici. La colonna "Dove" indica lezione e slide (L1 acciai, L2 altri materiali e saldatura, L3 corrosione e bacino). I termini senza sigla sono nel glossario della U.D.')

d.add_heading('Come si leggono i riferimenti', 2)
P('IACS UR W11 è il requisito uniforme n. W11 dell\'IACS (serie W = materiali e saldatura, serie Z = visite, serie S = robustezza, serie M = macchine). Rec. 47 è una raccomandazione IACS. CSR Pt 1 Ch 3 Sec 1 è la Parte 1, Capitolo 3, Sezione 1 delle Common Structural Rules. SOLAS II-1/3-2 è il capitolo II-1, regola 3-2. MSC.215(82) è la risoluzione n. 215 del Comitato per la sicurezza marittima, 82ª sessione; MEPC è l\'equivalente per l\'ambiente marino.')

d.add_heading('Enti, convenzioni e codici', 2)
T([
    ('IMO', 'International Maritime Organization', 'Agenzia ONU che emana le convenzioni marittime', r'\bIMO\b'),
    ('MSC', 'Maritime Safety Committee', 'Comitato IMO per la sicurezza; adotta emendamenti alla SOLAS', r'\bMSC\b'),
    ('MEPC', 'Marine Environment Protection Committee', 'Comitato IMO per l\'ambiente; qui la risoluzione che vieta la cibutrina', r'\bMEPC\b'),
    ('IACS', 'International Association of Classification Societies', 'Associazione delle principali società di classifica; emana UR e raccomandazioni', r'\bIACS\b'),
    ('UR', 'Unified Requirement', 'Requisito uniforme IACS, applicato da tutte le società membri', r'\bUR\b'),
    ('Rec.', 'Recommendation', 'Raccomandazione IACS, non obbligatoria (es. Rec. 46 rivestimenti, Rec. 47 qualità di costruzione e riparazione, Rec. 74 manutenzione)', r'Rec\. \d'),
    ('CSR', 'Common Structural Rules', 'Regole strutturali comuni IACS per portarinfuse e petroliere', r'\bCSR\b'),
    ('SOLAS', 'International Convention for the Safety of Life at Sea', 'Convenzione per la sicurezza della vita in mare', r'\bSOLAS\b'),
    ('STCW', 'Convention on Standards of Training, Certification and Watchkeeping', 'Convenzione sulla formazione dei marittimi; la tabella A-III/2 è quella dei direttori di macchina', r'\bSTCW\b'),
    ('ISM', 'International Safety Management Code', 'Sistema di gestione della sicurezza della compagnia; la sezione 10 riguarda la manutenzione', r'\bISM\b'),
    ('SMS', 'Safety Management System', 'Sistema di gestione della sicurezza di bordo previsto dal Codice ISM (procedure, permessi di lavoro)', r'\bSMS\b'),
    ('AFS', 'International Convention on the Control of Harmful Anti-fouling Systems on Ships', 'Convenzione che vieta le antivegetative dannose (TBT, cibutrina)', r'\bAFS\b'),
    ('IAFS', 'International Anti-fouling System Certificate', 'Certificato internazionale del sistema antivegetativo (navi di 400 GT e oltre in viaggi internazionali)', r'\bIAFS\b'),
    ('PSPC', 'Performance Standard for Protective Coatings', 'Norma IMO sui rivestimenti delle cisterne di zavorra (MSC.215(82)), resa obbligatoria da SOLAS II-1/3-2', r'\bPSPC\b'),
    ('CTF', 'Coating Technical File', 'Fascicolo tecnico del rivestimento PSPC che resta a bordo', r'\bCTF\b'),
    ('IHM', 'Inventory of Hazardous Materials', 'Inventario dei materiali pericolosi a bordo (amianto, PCB, metalli pesanti)', r'\bIHM\b'),
    ('IGC', 'International Gas Carrier Code', 'Codice per le navi gasiere: materiali per basse temperature', r'\bIGC\b'),
    ('IBC', 'International Bulk Chemical Code', 'Codice per le navi chimichiere: materiali delle cisterne', r'\bIBC\b'),
    ('IMSBC', 'International Maritime Solid Bulk Cargoes Code', 'Codice per i carichi solidi alla rinfusa; le schede indicano anche i rischi di corrosione', r'\bIMSBC\b'),
    ('ISGOTT', 'International Safety Guide for Oil Tankers and Terminals', 'Guida di settore per la sicurezza su petroliere e terminali (lavori a caldo)', r'\bISGOTT\b'),
    ('HSSC', 'Harmonized System of Survey and Certification', 'Sistema armonizzato che allinea le date delle visite statutarie', r'\bHSSC\b'),
    ('ESP', 'Enhanced Survey Programme', 'Programma di visite rafforzate per portarinfuse e petroliere', r'\bESP\b'),
    ('PMS', 'Planned Maintenance System', 'Sistema di manutenzione programmata di bordo', r'\bPMS\b'),
    ('IWS', 'In-Water Survey', 'Visita della carena in acqua con sommozzatori, al posto del bacino quando approvata', r'\bIWS\b'),
    ('VGP', 'Vessel General Permit', 'Permesso ambientale statunitense per gli scarichi delle navi (lubrificanti dell\'astuccio)', r'\bVGP\b'),
    ('ASTM', 'ASTM International (American Society for Testing and Materials)', 'Ente di normazione statunitense; qui la norma G82 sulla serie galvanica', r'\bASTM\b'),
    ('ISO', 'International Organization for Standardization', 'Ente internazionale di normazione (es. ISO 8501-1 gradi di sabbiatura, ISO 8217 combustibili)', r'\bISO\b'),
    ('EN', 'Norma europea', 'Norma del CEN recepita in Italia come UNI EN', r'\bEN \d|UNI EN'),
    ('IIW', 'International Institute of Welding', 'Istituto internazionale della saldatura; la formula del Ceq ne porta il nome', r'\bIIW\b'),
    ('D.D.', 'Decreto Direttoriale', 'Qui il D.D. 201/2024 con i programmi dei corsi', r'D\.D\.'),
    ('U.D.', 'Unità didattica', 'Parte numerata del programma del corso', r'U\.D\.'),
    ('CC BY-NC-SA 4.0', 'Creative Commons Attribuzione – Non commerciale – Condividi allo stesso modo 4.0', 'Licenza del materiale', r'BY-NC-SA'),
])

d.add_heading('Acciai e loro designazioni', 2)
T([
    ('A, B, D, E', 'Gradi dell\'acciaio normale da scafo', 'Stessa resistenza (ReH 235 N/mm²), tenacità crescente: Charpy a +20, 0, −20, −40 °C (UR W11)', r'\bA/B/D/E\b|gradi A|A, B, D'),
    ('AH, DH, EH, FH', 'Acciai ad alta resistenza (High tensile)', 'La H indica alta resistenza; la lettera dà la temperatura della prova Charpy (0, −20, −40, −60 °C)', r'\bAH\b|\bDH\b|\bEH\b'),
    ('32, 36, 40', 'Livelli di resistenza', 'Numeri dopo la sigla: snervamento minimo 315, 355, 390 N/mm² (es. AH36)', r'AH36|EH36'),
    ('HT', 'High Tensile (steel)', 'Acciaio ad alta resistenza', r'\bHT\b'),
    ('YP47', 'Yield Point 47', 'Acciaio con snervamento minimo 460 N/mm² per le portacontainer (UR W31)', r'YP47'),
    ('BCA1, BCA2', 'Brittle Crack Arrest', 'Acciai che arrestano una cricca fragile (Kca ≥ 6 000 e 8 000 N/mm^1,5 a −10 °C, UR W31)', r'BCA'),
    ('Z25, Z35', 'Classi di proprietà nello spessore', 'Strizione minima nella prova nello spessore (25 % e 35 %) contro lo strappo lamellare (UR W14)', r'Z25|Z35'),
    ('RCU, RCB, RCW', 'Resistance to Corrosion (upper deck, bottom, whole)', 'Acciai resistenti alla corrosione per le cisterne del carico delle petroliere (UR W11, SOLAS II-1/3-11)', r'\bRCB\b'),
    ('AR, N, CR, TM, QT', 'As Rolled, Normalized, Controlled Rolled, Thermo-Mechanical, Quenched and Tempered', 'Condizioni di fornitura: laminato, normalizzato, a laminazione controllata, termomeccanico, bonificato', r'\bTM\b'),
    ('TMCP', 'Thermo-Mechanical Controlled Process', 'Laminazione termomeccanica: grano fine, basso Ceq, buona saldabilità', r'\bTMCP\b'),
    ('CU1–CU4', 'Leghe di rame per eliche', 'Bronzi al manganese (CU1, CU2) e al nichel-alluminio (CU3, CU4) della UR W24', r'CU1'),
    ('PREN', 'Pitting Resistance Equivalent Number', 'Indice di resistenza al pitting degli inox: Cr + 3,3 Mo + 16 N', r'\bPREN\b'),
])

d.add_heading('Proprietà, prove e controlli', 2)
T([
    ('ReH', 'Upper yield strength', 'Snervamento superiore, in N/mm²', r'\bReH\b'),
    ('Rm', 'Tensile strength', 'Resistenza a trazione, in N/mm²', r'\bRm\b'),
    ('Rp0,2', 'Proof strength 0,2 %', 'Carico unitario allo 0,2 % di deformazione permanente, quando lo snervamento non è netto', r'Rp0,2'),
    ('A (%)', 'Allungamento percentuale dopo rottura', 'Misura la duttilità sulla lunghezza L0 = 5,65 √S0', r'L0'),
    ('KV', 'Energia Charpy con intaglio a V', 'Energia assorbita nella prova di resilienza, in joule', r'\bKV\b'),
    ('Kca', 'Crack arrest toughness', 'Tenacità all\'arresto della cricca (UR W31)', r'\bKca\b'),
    ('Ceq', 'Carbon equivalent', 'Carbonio equivalente: misura della saldabilità (C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15)', r'\bCeq\b'),
    ('Pcm', 'Crack parameter (Ito-Bessyo)', 'Indice alternativo di suscettibilità alle cricche a freddo', r'\bPcm\b'),
    ('k', 'Fattore del materiale', 'Coefficiente CSR che riduce lo spessore richiesto per gli acciai ad alta resistenza (1 / 0,78 / 0,72 / 0,68)', r'fattore k|\bk = 1|k = 0'),
    ('HV10, HRC', 'Durezza Vickers (carico 10 kgf), Rockwell C', 'Prove di durezza; nella saldatura limiti di 350 o 420 HV10 (UR W28)', r'HV10'),
    ('VT', 'Visual Testing', 'Esame visivo', r'\bVT\b'),
    ('PT', 'Penetrant Testing', 'Liquidi penetranti: cricche aperte in superficie', r'\bPT\b'),
    ('MT', 'Magnetic particle Testing', 'Magnetoscopia: cricche superficiali e subsuperficiali negli acciai ferromagnetici', r'\bMT\b'),
    ('UT', 'Ultrasonic Testing', 'Ultrasuoni: difetti interni e misure di spessore', r'\bUT\b'),
    ('RT', 'Radiographic Testing', 'Radiografia: difetti volumetrici interni', r'\bRT\b'),
    ('TOFD', 'Time Of Flight Diffraction', 'Tecnica ultrasonora per misurare l\'altezza dei difetti', r'\bTOFD\b'),
    ('CND', 'Controlli non distruttivi', 'Insieme di VT, PT, MT, UT, RT (in inglese NDT)', r'\bCND\b'),
    ('GOOD / FAIR / POOR', 'Stato del rivestimento', 'Giudizi definiti nella UR Z10.2, 1.2.13; POOR in zavorra porta a visite annuali', r'\bPOOR\b'),
])

d.add_heading('Saldatura', 2)
T([
    ('SMAW', 'Shielded Metal Arc Welding', 'Saldatura ad arco con elettrodo rivestito', r'\bSMAW\b'),
    ('GMAW / MIG / MAG', 'Gas Metal Arc Welding / Metal Inert Gas / Metal Active Gas', 'Saldatura a filo continuo sotto gas inerte (MIG) o attivo (MAG)', r'\bGMAW\b|\bMAG\b'),
    ('FCAW', 'Flux Cored Arc Welding', 'Saldatura con filo animato', r'\bFCAW\b'),
    ('SAW', 'Submerged Arc Welding', 'Saldatura ad arco sommerso, automatica, per giunti lunghi in cantiere', r'\bSAW\b'),
    ('TIG', 'Tungsten Inert Gas', 'Saldatura con elettrodo di tungsteno e gas inerte; tubi e inox', r'\bTIG\b'),
    ('WPS', 'Welding Procedure Specification', 'Specifica del procedimento di saldatura', r'\bWPS\b'),
    ('WPQR', 'Welding Procedure Qualification Record', 'Verbale di qualifica del procedimento (UR W28)', r'\bWPQR\b'),
    ('H5, H10, H15', 'Classi di idrogeno diffusibile', 'ml di idrogeno per 100 g di metallo depositato; più basso = meno cricche a freddo (UR W17)', r'\bH5\b|\bH10\b'),
    ('ZTA', 'Zona termicamente alterata', 'Metallo base modificato dal calore della saldatura (in inglese HAZ)', r'\bZTA\b'),
])

d.add_heading('Corrosione e impianti', 2)
T([
    ('MIC', 'Microbiologically Influenced Corrosion', 'Corrosione favorita da batteri (es. solfato-riduttori) sotto fanghi e depositi', r'\bMIC\b'),
    ('SCC', 'Stress Corrosion Cracking', 'Tensocorrosione: cricche per sforzo e ambiente specifico insieme', r'\bSCC\b'),
    ('ICCP', 'Impressed Current Cathodic Protection', 'Protezione catodica a corrente impressa', r'\bICCP\b'),
    ('TBT', 'Tributilstagno', 'Biocida organostannico delle antivegetative, vietato dalla Convenzione AFS', r'\bTBT\b'),
    ('BN / TBN', '(Total) Base Number', 'Riserva alcalina dell\'olio, in mg KOH/g: neutralizza gli acidi dello zolfo (corrosione a freddo)', r'\bBN\b|\bTBN\b'),
    ('NPSH', 'Net Positive Suction Head', 'Margine di pressione all\'aspirazione di una pompa; se insufficiente, cavitazione', r'\bNPSH\b'),
    ('EAL', 'Environmentally Acceptable Lubricant', 'Lubrificante a basso impatto ambientale per astucci e timoni', r'\bEAL\b'),
    ('GM', 'Altezza metacentrica', 'Distanza tra baricentro G e metacentro M; in bacino si riduce per la reazione delle taccate', r'\bGM\b'),
    ('KM', 'Altezza del metacentro sulla chiglia', 'Usata nella formula della perdita di GM all\'appoggio (P · KM / Δ)', r'\bKM\b'),
    ('LFL / OEL', 'Lower Flammable Limit / Occupational Exposure Limit', 'Limite inferiore di infiammabilità e limite di esposizione professionale (ingresso negli spazi chiusi)', r'\bLFL\b'),
])

d.add_heading('Materiali non metallici', 2)
T([
    ('GRP', 'Glass Reinforced Plastic', 'Vetroresina', r'\bGRP\b'),
    ('PVC', 'Polivinilcloruro', 'Materia plastica per tubi di servizi non critici', r'\bPVC\b'),
    ('PTFE', 'Politetrafluoroetilene', 'Materiale per guarnizioni resistente a chimici e temperatura', r'\bPTFE\b'),
    ('EPDM', 'Etilene-propilene-diene', 'Elastomero per tenute in acqua e vapore', r'\bEPDM\b'),
])

d.add_heading('Unità di misura', 2)
T([
    ('N/mm²', 'Newton al millimetro quadro', 'Unità delle tensioni (uguale a MPa)', r'N/mm²'),
    ('J', 'Joule', 'Unità dell\'energia della prova Charpy', r'\d J\b'),
    ('µm', 'Micrometro', 'Millesimo di millimetro: spessore delle pitture (PSPC: 320 µm nominali in zavorra)', r'µm'),
    ('mg/m²', 'Milligrammi al metro quadro', 'Sali solubili ammessi sulla superficie prima di pitturare', r'mg/m²'),
    ('GT', 'Gross Tonnage', 'Stazza lorda, usata per le soglie di applicazione', r'\bGT\b'),
])

finish(d, 'out/Sigle_e_acronimi_UD_4.1.1A_Materiali.docx')
