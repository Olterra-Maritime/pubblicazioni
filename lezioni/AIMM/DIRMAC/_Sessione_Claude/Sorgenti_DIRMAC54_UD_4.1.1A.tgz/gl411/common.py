import json, re
from docx import Document
from docx.shared import Pt, Twips, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
P_ = {k: json.load(open(f'L{k}.json')) for k in (1, 2, 3)}
def sn(i): return None if i == 22 else (i + 1 if i < 22 else i)
def rng(out):
    r = []; a = b = out[0]
    for x in out[1:]:
        if x == b + 1: b = x
        else: r.append((a, b)); a = b = x
    r.append((a, b)); return ', '.join(f'{a}' if a == b else f'{a}–{b}' for a, b in r)
def where(pat, slides=True):
    rx = re.compile(pat); parts = []
    for k in (1, 2, 3):
        out = sorted(set(x for x in (sn(i) for i, p in enumerate(P_[k]) if rx.search(p)) if x))
        if out: parts.append(f'L{k}: ' + ('tutte' if len(out) == 45 else rng(out)) if slides else f'L{k}')
    if not parts: raise SystemExit('nessuna occorrenza: ' + pat)
    return (' · ' if slides else ', ').join(parts)
def newdoc():
    d = Document()
    st = d.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(10.5)
    for s in ('Heading 1', 'Heading 2'): d.styles[s].font.color.rgb = RGBColor(0x0F, 0x2A, 0x3D)
    return d
def table(d, head, rows, wid, bold0=True):
    t = d.add_table(rows=1, cols=len(head)); t.style = d.styles['Table Grid']; t.autofit = False
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); t._tbl.tblPr.append(lay)
    for gc, w in zip(t._tbl.tblGrid.findall(qn('w:gridCol')), wid): gc.set(qn('w:w'), str(w))
    for i, h in enumerate(head):
        c = t.rows[0].cells[i]; c.text = h; c.paragraphs[0].runs[0].bold = True
        shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), 'F2F2F2'); c._tc.get_or_add_tcPr().append(shd)
    t.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    for r in rows:
        cs = t.add_row().cells
        for i, v in enumerate(r): cs[i].text = v
        if bold0: cs[0].paragraphs[0].runs[0].bold = True
    for row in t.rows:
        for i, w in enumerate(wid): row.cells[i].width = Twips(w)
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
    d.add_paragraph('')
COPY = "© 2026 ing. Pietro Lauro 6497A-GE. Quest'opera è distribuita con licenza CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/deed.it)."
def finish(d, path):
    fp = d.sections[0].footer.paragraphs[0]; fp.text = COPY; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in fp.runs: r.font.size = Pt(8); r.font.color.rgb = RGBColor(0x5E, 0x6B, 0x73)
    d.save(path); print('ok', path)
HEAD = 'Accademia Italiana della Marina Mercantile · Corso Direttivo Macchina 54 · U.D. 4.1.1 A · lezioni del 13, 20 e 27 novembre 2026 (L1, L2, L3)'
TIT = 'U.D. 4.1.1 A — Materiali impiegati nella costruzione navale'
