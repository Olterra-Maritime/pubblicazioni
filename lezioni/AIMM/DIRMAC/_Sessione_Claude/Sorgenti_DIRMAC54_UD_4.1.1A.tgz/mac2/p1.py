"""Lezione 2 (20/11/2026) · U.D. 4.1.1 A · Altri materiali · parte 1 (slide 2-22)."""
from lib import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes))

E1 = 'PARTE 1 · INTRODUZIONE'
E2 = 'PARTE 1 · ACCIAI INOSSIDABILI E GHISE'
E3 = 'PARTE 1 · ALLUMINIO'
E4 = 'PARTE 1 · LEGHE DI RAME'
E5 = 'PARTE 1 · NON METALLICI'
E6 = 'PARTE 1 · CONFRONTO'

def d2():
    return programma_fonti(['08:30', '10:20', '10:40', '12:30'], [
        ('IACS UR W9 · W10', 'Rev.2 mag 2004 (Rev.3 dal 1/1/2027)'),
        ('IACS UR W24 · W27', 'Rev.5 Corr.1 · Rev.3 Corr.1 dic 2024'),
        ('IACS UR W25 · W26', 'Rev.6 · Rev.2 set 2021'),
        ('IACS UR W17 · W28 · W32', 'Rev.6 2021 · Rev.2 2012 · Rev.1 2020'),
        ('IACS UR W33 · W34', 'Rev.1 Corr.1 2021 · dic 2019 (Rev. dal 2028)'),
        ('IACS Rec. 47', 'Rev.10 Corr.1 ott 2025'),
        ('SOLAS II-1/3-5, II-2', 'testo consolidato + emendamenti MSC'),
        ('IMO MSC.581(110)', 'spazi chiusi, sostituisce A.1050(27)')])
add(E1, 'Obiettivi, orario e fonti',
    ['Conoscere i **materiali diversi** dall\'acciaio da scafo',
     'Sapere dove stanno a bordo e **perché**',
     'Capire **saldatura**, difetti e qualifiche',
     'Scegliere il **controllo non distruttivo** giusto'],
    'scansione oraria e fonti con la revisione usata', d2(),
    "Min 08:35. Seconda lezione della U.D. 4.1.1 A. Prima parte: acciai inossidabili, ghise, leghe di alluminio, leghe di rame, materiali non metallici. Seconda parte: saldatura, qualifica di procedimenti e saldatori, difetti, controlli non distruttivi, saldatura a bordo e in una cassa combustibile (domanda d'esame C.14), riparazioni. Fonti e revisioni usate, verificate il 30/10/2026 sul sito IACS (copie in DIR MAC 54/Fonti/IACS_UR_W): UR W9 e W10 Rev.2 (2004), ghise grigia e sferoidale, con Rev.3 dal 1° gennaio 2027; UR W24 Rev.5 Corr.1 (dicembre 2024) eliche in lega di rame; UR W27 Rev.3 Corr.1 (dicembre 2024) eliche in acciaio fuso; UR W25 Rev.6 e W26 Rev.2 (settembre 2021) leghe di alluminio e loro materiali d'apporto; UR W17 Rev.6 (2021) materiali d'apporto; UR W28 Rev.2 (2012) qualifica dei procedimenti, Rev.3 dal 1° gennaio 2027; UR W32 Rev.1 (2020) qualifica dei saldatori; UR W33 Rev.1 Corr.1 (2021) controlli non distruttivi delle saldature di scafo, Rev.2 dal 1° gennaio 2028; UR W34 (2019) controlli avanzati; IACS Rec. 47 Rev.10 Corr.1 (ottobre 2025) qualità di costruzione e riparazione; SOLAS II-1/3-5 (amianto) e II-2 (protezione strutturale); MSC.581(110) per l'ingresso negli spazi chiusi.")

def d3():
    return grid('Mappa dei materiali di bordo', ['Materiale', 'Dove si trova', 'Perché'], [
        ('Acciaio da scafo', 'scafo, ponti, paratie', 'resistenza, saldabilità, costo'),
        ('Acciai fucinati e getti', 'assi, timone, alberi, mozzi', 'resistenza a fatica e torsione'),
        ('Ghise', 'basamenti, pompe, valvole', 'colabilità, smorzamento, costo'),
        ('Inossidabili', 'cisterne chimiche, scambiatori, valvole', 'resistenza alla corrosione'),
        ('Alluminio', 'sovrastrutture, unità veloci', 'leggerezza'),
        ('Leghe di rame', 'eliche, tubi d\'acqua di mare, cuscinetti', 'corrosione in mare, antifrizione'),
        ('Non metallici', 'tubi in plastica, guarnizioni, isolanti', 'leggerezza, isolamento, tenuta')],
        [28, 200, 432], y0=58, rh=48, size=14)
add(E1, 'Mappa dei materiali di bordo',
    ['L\'acciaio da scafo è **la maggior parte** del peso',
     'In macchina c\'è **molta varietà**',
     'Ogni materiale ha un **perché**',
     'Ognuno ha i suoi **requisiti di classe**'],
    'materiali principali, impieghi e motivi della scelta', d3(),
    "Panoramica da usare anche come traccia per la domanda d'esame C.5. L'acciaio da scafo (lezione 1) è la maggior parte del peso della nave. In macchina e negli impianti la varietà è grande: acciai fucinati e getti per assi, timone, alberi a gomiti e mozzi; ghise per basamenti, corpi di pompe e valvole; acciai inossidabili per cisterne di chimichiere, scambiatori, valvole e alberi di pompe; leghe di alluminio per sovrastrutture e unità veloci; leghe di rame (bronzi, ottoni, cupronichel) per eliche, tubolature d'acqua di mare, cuscinetti e valvole; materiali non metallici per tubi, guarnizioni, isolamenti, rivestimenti. La regola da far ricordare: ogni scelta nasce da una proprietà (resistenza, corrosione, peso, colabilità, attrito) e ha i suoi requisiti di classe (UR serie W e regolamenti delle società).")

def d4():
    return grid('Acciai inossidabili: le famiglie', ['Famiglia', 'Composizione tipica', 'Uso a bordo'], [
        ('Austenitici', 'Cr 18 · Ni 8–10 (304, 316 con Mo)', 'cisterne chimiche, tubi, valvole'),
        ('Duplex', 'Cr 22–25 · Ni 5–7 · Mo 3', 'cisterne chimiche, acqua di mare'),
        ('Martensitici', 'Cr 12–17 · Ni basso', 'eliche fuse, alberi'),
        ('Ferritici', 'Cr 11–17 · senza Ni', 'scarichi, rivestimenti, impieghi minori')],
        [28, 190, 420], y0=62, rh=66, size=14)
add(E2, 'Acciai inossidabili',
    ['Almeno **10,5 % di cromo**: film passivo',
     '**Austenitici** (304, 316): duttili, non magnetici',
     '**Duplex**: più resistenti, meno pitting',
     '**Martensitici**: temprabili, per eliche e alberi'],
    'famiglie di acciai inossidabili e impieghi', d4(),
    "L'acciaio inossidabile contiene almeno il 10,5 % circa di cromo, che forma sulla superficie un sottile film di ossido protettivo (passivazione). Famiglie: austenitici (tipo 304 con circa 18 % Cr e 8 % Ni; 316 con aggiunta di 2–3 % di molibdeno, migliore in ambiente con cloruri): duttili, tenaci anche a bassissima temperatura, non magnetici, usati nelle cisterne delle chimichiere (Codice IBC), nei tubi e nelle valvole; duplex (austenite + ferrite, circa 22 % Cr, 5 % Ni, 3 % Mo): resistenza meccanica circa doppia e migliore resistenza al pitting e alla corrosione sotto sforzo; martensitici (12–17 % Cr, poco Ni, temprabili): eliche in acciaio fuso secondo UR W27 (tipi 12Cr1Ni, 13Cr4Ni, 16Cr5Ni; austenitico 19Cr11Ni) e alberi di pompe; ferritici, poco usati in campo navale. Composizioni indicative, non requisiti.")

def d5():
    o = [head('Inox in acqua di mare: il pitting')]
    o.append(R(28, 62, 610, 64, SOFTB, BLUE, 2, 10))
    o.append(T(333, 102, 'PREN = %Cr + 3,3 × %Mo + 16 × %N', 19, True, BLUE, 'middle', maxw=590))
    items = [('304 (18Cr-8Ni)', 19, RUST, '≈ 18–20'), ('316L (+2,5 Mo)', 24, YEL, '≈ 24–26'), ('duplex 2205', 35, BLUE, '≈ 34–36'), ('superduplex', 41, GREEN, '> 40')]
    o.append(hbars('', items, y0=150, maxv=45, vw=280, bh=34, gap=18, lw=190, size=15))
    o.append(T(28, 380, 'più alto il PREN, migliore la resistenza al pitting', 15, True, INK, maxw=610))
    o.append(T(28, 404, 'con acqua di mare ferma e calda anche il 316 può fare pitting', 14, False, GRAY, maxw=610))
    o.append(T(28, 428, 'valori indicativi', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(E2, 'Inossidabili e cloruri',
    ['I **cloruri** rompono il film passivo',
     'Pitting e corrosione **interstiziale**',
     'Indice **PREN**: cromo, molibdeno, azoto',
     'Acqua di mare **ferma**: il caso peggiore'],
    'indice PREN e resistenza al pitting', d5(),
    "Gli inossidabili non sono immuni dalla corrosione: in presenza di cloruri il film passivo si rompe localmente e si formano crateri (pitting) o attacchi nelle fessure (sotto guarnizioni, flange, depositi). L'indice PREN (Pitting Resistance Equivalent Number) = %Cr + 3,3 %Mo + 16 %N confronta la resistenza al pitting: circa 18–20 per il 304, 24–26 per il 316L, 34–36 per un duplex 2205, oltre 40 per i superduplex (valori indicativi da composizioni tipiche). Per l'acqua di mare servono PREN alti; il 316 può fare pitting in acqua di mare ferma e calda (tubi in sosta, casse di presa). Sotto sforzo e in ambiente con cloruri caldi gli austenitici possono criccare (corrosione sotto sforzo): ripreso nella lezione 3.")

def d6():
    return rows('Ghise (UR W9 e W10)', [
        ('Grigia · W9', 'Rm ≥ 200 N/mm²; fragile; smorza le vibrazioni', 'n'),
        ('Usi', 'basamenti, blocchi motore, corpi di pompe', 'n'),
        ('Sferoidale · W10', 'Rm 350–800 N/mm²; allungamento fino al 22 %', 'b'),
        ('Usi', 'valvole, carter, componenti più sollecitati', 'b'),
        ('Limiti', 'grigia: niente urti né saldature affidabili', 'r')], y0=62, lw=170, size=15)
add(E2, 'Ghisa grigia e sferoidale',
    ['Ghisa: ferro con **più del 2 % di carbonio**',
     '**Grigia**: grafite in lamelle, fragile, economica',
     '**Sferoidale**: grafite a noduli, duttile',
     'Ottima **colabilità**: getti complessi'],
    'tipi di ghisa, requisiti e impieghi', d6(),
    "La ghisa è una lega ferro-carbonio con oltre il 2 % circa di carbonio, ottima colabilità e buona lavorabilità. Grigia (lamellare, UR W9 Rev.2): la grafite in lamelle la rende fragile e poco resistente a trazione ma ottima nello smorzare vibrazioni e a compressione; la UR chiede solo la prova di trazione con resistenza minima specificata non inferiore a 200 N/mm². Sferoidale o nodulare (UR W10 Rev.2): la grafite a noduli dà resistenza da 350 a 800 N/mm² e allungamento fino al 22 % per le qualità speciali con prova di resilienza. Usi: basamenti e blocchi motore, corpi di pompe, valvole, carter. Limiti: la ghisa grigia non sopporta urti e non si salda in modo affidabile; i regolamenti di classe limitano l'uso della ghisa grigia in componenti soggetti a urti o in valvole sul fasciame esterno e su sistemi in pressione: verificare caso per caso. Le Rev.3 di W9 e W10 si applicano dal 1° gennaio 2027.")

def d7():
    return rows('Leghe di alluminio da scafo (UR W25)', [
        ('Serie 5000', 'lamiere 5083, 5086, 5383, 5059, 5754, 5456', 'b'),
        ('Stati 5000', 'O, H111, H112, H116, H321: adatte all\'acqua di mare', 'b'),
        ('Serie 6000', 'profilati estrusi 6005A, 6061, 6082 · stati T5, T6', 'y'),
        ('Attenzione', '6005A e 6061: non a contatto con l\'acqua di mare senza protezione', 'r'),
        ('Dati', 'densità 2,7 t/m³ · modulo elastico circa 70 GPa', 'n')], y0=62, lw=140, size=14)
add(E3, 'Leghe di alluminio',
    ['Un terzo del **peso** dell\'acciaio',
     'Serie **5000**: lamiere resistenti all\'acqua di mare',
     'Serie **6000**: profilati estrusi',
     'Unità veloci e **sovrastrutture**'],
    'leghe e stati di fornitura della UR W25', d7(),
    "IACS UR W25 Rev.6 (settembre 2021), leghe di alluminio per costruzione navale e strutture marine, da stabilimenti approvati. Laminati (lamiere): leghe 5083, 5086, 5383, 5059, 5754, 5456 negli stati O, H111, H112, H116, H321. Estrusi (profilati, barre, profili chiusi): 5083, 5383, 5059, 5086 negli stati O, H111, H112, e 6005A, 6061, 6082 negli stati T5 o T6. Nota della UR: le leghe 6005A e 6061 non vanno usate a contatto diretto con l'acqua di mare senza anodi o pitture. Le leghe 5000 (alluminio-magnesio) non sono trattabili termicamente e prendono resistenza dall'incrudimento (stati H); gli stati H116 e H321 sono controllati contro la corrosione esfoliante e intergranulare (prove metallografiche per lotto). Densità circa 2,7 t/m³ contro 7,85 dell'acciaio; modulo elastico circa un terzo. Il materiale d'apporto ha la sua UR (W26).")

def d8():
    o = [head('Alluminio e acciaio: il giunto bimetallico')]
    o.append(R(60, 70, 230, 40, '#D9DEE2', GRAY, 2, 0)); o.append(T(175, 96, 'sovrastruttura in alluminio', 13, True, INK, 'middle'))
    o.append(R(60, 110, 230, 26, '#BFD9C5', GREEN, 2, 0)); o.append(T(175, 128, 'giunto bimetallico (esplosione)', 12, True, GREEN, 'middle'))
    o.append(R(60, 136, 230, 40, '#C9D6DE', HULL, 2, 0)); o.append(T(175, 162, 'ponte in acciaio', 13, True, INK, 'middle'))
    o.append(T(330, 92, 'Saldato alluminio su alluminio', 14, True, INK)); o.append(T(330, 162, 'Saldato acciaio su acciaio', 14, True, INK))
    o.append(rows('', [('Corrosione galvanica', 'l\'alluminio è anodico rispetto all\'acciaio', 'r'), ('Soluzioni', 'giunto bimetallico, isolamento, pittura', 'g'),
                       ('Bulloni', 'rondelle e boccole isolanti, sigillante', 'y')], y0=210, lw=180, size=14))
    return ''.join(o)
add(E3, 'Alluminio e acciaio insieme',
    ['Contatto diretto in acqua: **corrosione galvanica**',
     'L\'alluminio è il metallo che **si consuma**',
     'Si usa un **giunto bimetallico** saldato',
     'Unioni bullonate: **isolamento** elettrico'],
    'unione tra sovrastruttura in alluminio e ponte in acciaio', d8(),
    "Le sovrastrutture in lega di alluminio su navi in acciaio (traghetti, navi da crociera, yacht) pongono il problema del contatto tra metalli diversi: in presenza di acqua (elettrolita) l'alluminio, anodico rispetto all'acciaio, si corrode (corrosione galvanica, lezione 3). Soluzione corrente: giunti di transizione bimetallici (strisce alluminio-acciaio ottenute per saldatura per esplosione), saldati all'acciaio da un lato e all'alluminio dall'altro, senza contatto diretto dei due metalli esposti. Nelle unioni bullonate si usano rondelle e boccole isolanti e sigillanti; si evita che l'acqua ristagni nel giunto. Anche fissaggi in acciaio inossidabile su alluminio richiedono isolamento.")

def d9():
    o = [head('Alluminio e incendio')]
    items = [('acciaio da scafo', 100, STEEL, 'resistenza fino a ~400 °C'), ('lega di alluminio', 45, RUST, 'cala già oltre ~200 °C')]
    o.append(hbars('', items, y0=70, maxv=100, vw=260, bh=40, gap=26, lw=170, size=14))
    o.append(R(28, 210, 610, 96, SOFTR, RUST, 2, 10))
    o.append(T(44, 240, 'SOLAS II-2: strutture in lega di alluminio isolate', 15, True, RUST, maxw=580))
    o.append(T(44, 266, 'il cuore della struttura non deve superare la temperatura', 14, False, INK, maxw=580))
    o.append(T(44, 290, 'ambiente di oltre 200 °C nella prova standard', 14, False, INK, maxw=580))
    o.append(T(28, 340, 'fusione: alluminio ~ 600–650 °C · acciaio ~ 1 500 °C', 15, True, INK, maxw=610))
    o.append(T(28, 368, 'barre schematiche: temperature indicative', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(E3, 'Alluminio e incendio',
    ['Perde resistenza **molto prima** dell\'acciaio',
     'Fonde a circa **600–650 °C**',
     'Strutture in alluminio **isolate** (SOLAS II-2)',
     'Rischio per la **stabilità** della struttura'],
    'comportamento al fuoco dell\'alluminio rispetto all\'acciaio', d9(),
    "Le leghe di alluminio perdono gran parte della resistenza già tra 200 e 300 °C e fondono intorno a 600–650 °C, mentre l'acciaio da costruzione mantiene buona parte della resistenza fino a circa 400 °C e fonde intorno a 1 500 °C (valori indicativi). Per questo la SOLAS, capitolo II-2, considera le strutture in lega di alluminio equivalenti all'acciaio solo se isolate in modo che la temperatura del cuore della struttura non superi di oltre 200 °C la temperatura ambiente durante l'esposizione alla prova standard al fuoco; l'isolamento delle sovrastrutture in alluminio è quindi parte della protezione strutturale antincendio. Per l'ufficiale di macchina: in un incendio vicino a strutture in alluminio il raffreddamento con acqua e la sorveglianza delle deformazioni sono prioritari. Verificare la regola esatta (II-2/11 e definizioni di 'acciaio o altro materiale equivalente') sul testo SOLAS in uso.")

def d10():
    return grid('Leghe di rame a bordo', ['Lega', 'Composizione tipica', 'Uso'], [
        ('Bronzo al manganese', 'Cu-Zn con Mn, Al, Fe (CU1)', 'eliche'), ('Bronzo Ni-Al', 'Cu 80 · Al 9 · Ni 5 · Fe 4 (CU3)', 'eliche, valvole, pompe'),
        ('Cupronichel 90/10', 'Cu 90 · Ni 10 · Fe', 'tubi d\'acqua di mare, condensatori'), ('Cupronichel 70/30', 'Cu 70 · Ni 30', 'scambiatori più sollecitati'),
        ('Ottone all\'alluminio', 'Cu 76 · Zn 22 · Al 2', 'tubi di condensatori'), ('Bronzo allo stagno', 'Cu-Sn', 'boccole, cuscinetti, valvole')],
        [28, 200, 420], y0=62, rh=52, size=14)
add(E4, 'Leghe di rame',
    ['Resistono bene all\'**acqua di mare**',
     'Effetto **antivegetativo**: niente incrostazioni',
     '**Cupronichel** per tubi e scambiatori',
     '**Bronzi** per eliche, cuscinetti, valvole'],
    'principali leghe di rame e impieghi', d10(),
    "Le leghe di rame resistono bene all'acqua di mare e gli ioni di rame scoraggiano le incrostazioni biologiche. Cupronichel 90/10 e 70/30 per tubolature d'acqua di mare, refrigeranti e condensatori; ottone all'alluminio per tubi di condensatori; bronzi allo stagno e ai piombi per boccole e cuscinetti; bronzi al nichel-alluminio per eliche, corpi di pompe e valvole. Le eliche usano i tipi CU1–CU4 della UR W24 (slide seguente). Limiti: velocità dell'acqua troppo alta (erosione-corrosione), acqua inquinata con solfuri, contatto con metalli meno nobili. Gli ottoni con molto zinco possono subire dezincificazione: il rame resta poroso e la parete perde resistenza. Composizioni indicative.")

def d11():
    o = [grid('Eliche (UR W24 e W27)', ['Tipo', 'Lega', 'Rp0,2 min', 'Rm min'], [
        ('CU1', 'bronzo al Mn (Cu-Zn)', '175', '440'), ('CU2', 'bronzo Ni-Mn', '175', '440'),
        ('CU3', 'bronzo Ni-Al', '245', '590'), ('CU4', 'bronzo Mn-Al', '275', '630')], [28, 120, 360, 500], y0=58, rh=44, size=15)]
    o.append(R(28, 290, 610, 140, SOFTB, BLUE, 2, 10))
    o.append(T(44, 318, 'Acciaio fuso (W27): martensitici 12Cr1Ni, 13Cr4Ni,', 14, True, BLUE, maxw=580))
    o.append(T(44, 340, '16Cr5Ni e austenitico 19Cr11Ni', 14, True, BLUE, maxw=580))
    o.append(T(44, 368, 'tutte: produttore approvato, prove sul getto,', 14, False, INK, maxw=580))
    o.append(T(44, 390, 'controlli non distruttivi per zone di severità', 14, False, INK, maxw=580))
    o.append(T(44, 414, 'N/mm² · valori della UR W24, tabella dei requisiti meccanici', 13, False, GRAY, maxw=580))
    return ''.join(o)
add(E4, 'Le eliche',
    ['Quasi sempre in **lega di rame** fusa',
     'Quattro tipi: **CU1–CU4** (UR W24)',
     'Il **nichel-alluminio** è il più resistente',
     'In alternativa **acciaio fuso** (UR W27)'],
    'materiali delle eliche e requisiti meccanici', d11(),
    "IACS UR W24 Rev.5 Corr.1 (dicembre 2024), eliche in lega di rame fusa: quattro tipi tipici secondo la composizione. CU1 bronzo ad alta resistenza al manganese (Cu 52–62 %, Zn 35–40 %), CU2 bronzo al nichel-manganese, CU3 bronzo al nichel-alluminio (Cu 77–82 %, Al 7–11 %, Ni 3–6 %, Fe 2–6 %), CU4 bronzo al manganese-alluminio. Requisiti meccanici sui provini colati separatamente: carico di 0,2 % e resistenza minimi 175 e 440 N/mm² per CU1 e CU2, 245 e 590 per CU3, 275 e 630 per CU4. IACS UR W27 Rev.3 Corr.1 (dicembre 2024), eliche in acciaio fuso: martensitici 12Cr1Ni, 13Cr4Ni, 16Cr5Ni e austenitico 19Cr11Ni. Per entrambe: produttore approvato, prove, controllo visivo, liquidi penetranti e altri controlli per zone di severità, regole per le riparazioni con saldatura. A bordo: i danni alle pale (cavitazione, urti) si riparano solo con procedura approvata.")

def d12():
    return rows('Metalli antifrizione e cuscinetti', [
        ('Metallo bianco', 'stagno o piombo con antimonio e rame: cuscinetti di banco, di biella, assi', 'b'),
        ('Bronzi', 'boccole, agugliotti del timone, cuscinetti a basso numero di giri', 'y'),
        ('Non metallici', 'resine e compositi negli astucci lubrificati ad acqua', 'g'),
        ('Perché', 'materiale tenero che si adatta e protegge l\'albero', 'n')], y0=62, lw=150, size=14)
add(E4, 'Metalli antifrizione',
    ['**Metallo bianco**: tenero, si adatta all\'albero',
     'Strato sottile su un **guscio** di acciaio',
     '**Bronzi** per boccole e timoni',
     'Danno tipico: **fusione** del metallo bianco'],
    'materiali per cuscinetti e boccole', d12(),
    "I cuscinetti a strisciamento usano materiali più teneri dell'albero, che si adattano alla sua forma, incorporano piccole particelle e proteggono l'albero in caso di mancanza di olio. Metallo bianco (babbitt): leghe di stagno o piombo con antimonio e rame, colate in strato sottile su un guscio di acciaio o bronzo, per cuscinetti di banco e di biella, reggispinta e cuscinetti dell'astuccio lubrificati a olio. Bronzi allo stagno e al piombo per boccole, agugliotti e cuscinetti del timone. Materiali non metallici (resine, compositi) per gli astucci lubrificati ad acqua. Il danno tipico è la fusione del metallo bianco per surriscaldamento o mancanza di lubrificazione: collegamento con le unità di manutenzione e con la domanda d'esame sui cuscinetti (Meccanica C.7).")

def d13():
    return rows('Materiali compositi', [
        ('Vetroresina', 'resina poliestere o vinilestere con fibra di vetro', 'b'),
        ('Dove', 'diporto, unità veloci, lance di salvataggio, tubi, grigliati', 'b'),
        ('Pregi', 'leggerezza, niente corrosione, forme complesse', 'g'),
        ('Limiti', 'incendio: brucia e produce fumo; rigidezza bassa', 'r'),
        ('Regole', 'Codice HSC; navi SOLAS: progetto alternativo (II-2/17)', 'y')], y0=62, lw=150, size=14)
add(E5, 'Materiali compositi',
    ['**Fibra** di vetro o carbonio in **resina**',
     'Leggeri e **non corrodono**',
     'Problema principale: **incendio**',
     'Su navi SOLAS: solo con **progetto alternativo**'],
    'compositi a bordo: pregi, limiti e regole', d13(),
    "Materiali compositi: fibre (vetro, carbonio, aramide) in matrice di resina (poliestere, vinilestere, epossidica), spesso con anima in schiuma o legno (sandwich). Usi: scafi di unità da diporto e di unità veloci (Codice HSC), lance di salvataggio, grigliati, tubi in vetroresina per acqua di mare e zavorra, coperture. Pregi: leggerezza, nessuna corrosione, forme complesse. Limiti: comportamento al fuoco (la resina brucia, produce fumo e perde resistenza a temperature basse), rigidezza minore, controllo di qualità della laminazione. Sulle navi SOLAS i compositi strutturali non sono 'acciaio o materiale equivalente' e sono ammessi solo con un progetto alternativo secondo SOLAS II-2/17, per il quale l'IMO ha pubblicato linee guida provvisorie (MSC.1/Circ.1574, 2017). Verificare il riferimento della circolare prima di citarla all'esame.")

def d14():
    return rows('Materiali non metallici', [
        ('Tubi in plastica', 'ammessi secondo le linee guida IMO A.753(18) e emendamenti', 'b'),
        ('Prova al fuoco', 'livelli L1, L2, L3 secondo il servizio del tubo', 'r'),
        ('Guarnizioni', 'elastomeri, grafite, PTFE: scelta per fluido e temperatura', 'y'),
        ('Rivestimenti', 'pitture, resine per supporti di macchine (chocking)', 'g'),
        ('Isolanti', 'lana minerale, materiali approvati, mai amianto', 'n')], y0=62, lw=160, size=14)
add(E5, 'Materiali non metallici',
    ['**Tubi in plastica** con prove al fuoco',
     '**Guarnizioni** scelte per fluido e temperatura',
     '**Resine** per i basamenti delle macchine',
     '**Isolanti** approvati'],
    'principali materiali non metallici a bordo', d14(),
    "Tubi in plastica (vetroresina, PVC, polietilene) ammessi secondo le linee guida IMO per l'uso di tubi in plastica sulle navi, risoluzione A.753(18), emendata più volte (per esempio MSC.313(88) e MSC.399(95)): livelli di resistenza al fuoco L1, L2, L3 secondo il sistema e lo spazio, requisiti di propagazione della fiamma e conduttività elettrica dove serve. Guarnizioni e tenute: elastomeri (nitrilica, EPDM, Viton), grafite, PTFE, scelti per fluido, pressione e temperatura. Resine per i supporti di macchine e assi (chocking) che sostituiscono gli spessori in acciaio. Isolanti termici e acustici: lana minerale e materiali approvati; mai amianto (slide seguente). Verificare i riferimenti degli emendamenti di A.753(18) sul testo IMO.")

def d15():
    o = [head('Amianto: vietato a bordo')]
    o.append(R(28, 62, 610, 96, SOFTR, RUST, 2, 10))
    o.append(T(44, 94, 'SOLAS II-1/3-5: vietata ogni nuova installazione', 16, True, RUST, maxw=580))
    o.append(T(44, 120, 'di materiali contenenti amianto, su tutte le navi', 15, False, INK, maxw=580))
    o.append(T(44, 144, 'dal 1° gennaio 2011 (MSC.282(86))', 14, False, GRAY, maxw=580))
    o.append(rows('', [('Dove si trovava', 'guarnizioni, coibentazioni, freni, pannelli, tubi', 'n'),
                       ('Ricambi', 'certificato "asbestos free" del fornitore', 'y'),
                       ('Riciclaggio', 'inventario dei materiali pericolosi (IHM)', 'b')], y0=178, lw=170, size=14))
    return ''.join(o)
add(E5, 'Amianto e materiali pericolosi',
    ['**Nessuna nuova installazione** di amianto',
     'Attenzione ai **ricambi**: guarnizioni, isolanti',
     'Dichiarazione del fornitore **senza amianto**',
     '**Inventario** dei materiali pericolosi (IHM)'],
    'regola SOLAS sull\'amianto e controlli a bordo', d15(),
    "SOLAS II-1/3-5, come emendata con la risoluzione MSC.282(86): dal 1° gennaio 2011 è vietata su tutte le navi la nuova installazione di materiali contenenti amianto (prima erano ammesse eccezioni). In passato l'amianto era nelle guarnizioni, nelle coibentazioni di tubi e caldaie, nei freni, nei pannelli antincendio. Per l'ufficiale di macchina il rischio maggiore oggi sono i ricambi: guarnizioni e materiali isolanti forniti da produttori non controllati; si chiede la dichiarazione del fornitore che il materiale è privo di amianto. Collegamento: la Convenzione di Hong Kong sul riciclaggio delle navi (in vigore dal 26 giugno 2025) e il Regolamento UE 1257/2013 richiedono l'inventario dei materiali pericolosi (IHM), che comprende l'amianto. Verificare date e riferimenti sul testo aggiornato.")

def d16():
    return grid('Confronto tra materiali (valori tipici)', ['Materiale', 'Densità t/m³', 'E (GPa)', 'Rm (N/mm²)'], [
        ('Acciaio da scafo', '7,85', '206', '400–660'), ('Inox austenitico', '7,9', '195', '500–700'), ('Ghisa sferoidale', '7,1', '170', '350–800'),
        ('Alluminio 5083', '2,66', '70', '270–350'), ('Bronzo Ni-Al (CU3)', '7,6', '120', '≥ 590'), ('Vetroresina', '1,5–1,9', '10–25', '100–300')],
        [28, 230, 380, 500], y0=58, rh=52, size=15)
add(E6, 'Tabella di confronto',
    ['L\'alluminio pesa **un terzo** dell\'acciaio',
     'Ma è anche **tre volte** meno rigido',
     'I compositi: **leggerissimi**, poco rigidi',
     'Valori **indicativi**, non di progetto'],
    'densità, modulo elastico e resistenza di alcuni materiali', d16(),
    "Valori tipici di letteratura tecnica, arrotondati, utili per confrontare gli ordini di grandezza; non sono requisiti di classe. Acciaio da scafo: densità 7,85 t/m³, modulo elastico circa 206 GPa, resistenza 400–660 N/mm² secondo il grado. Inox austenitico: densità circa 7,9, modulo circa 195 GPa. Ghisa sferoidale: densità circa 7,1, modulo 160–175 GPa, resistenza 350–800 (UR W10). Lega di alluminio 5083: densità 2,66, modulo circa 70 GPa, resistenza 270–350 N/mm² secondo lo stato. Bronzo nichel-alluminio CU3: densità circa 7,6, resistenza minima 590 (UR W24). Vetroresina: densità 1,5–1,9, modulo 10–25 GPa secondo fibra e laminazione. Domanda da porre: a parità di rigidezza, quanto si risparmia davvero con l'alluminio? Meno di quanto suggerisce la densità, perché servono spessori e altezze maggiori.")

def d17():
    o = [head('Esercizio: quale materiale?')]
    qs = ['Tubo dell\'acqua di mare di raffreddamento', 'Elica di una portarinfuse', 'Cisterna di una chimichiera per acidi',
          'Sovrastruttura di un traghetto veloce', 'Cuscinetto di banco di un motore a 4 tempi']
    for i, q in enumerate(qs):
        y = 62 + i * 74
        o.append(R(28, y, 610, 62, SOFTY, YEL, 2, 9)); o.append(T(46, y + 38, str(i + 1), 20, True, '#7A5200'))
        o.append(T(76, y + 37, q, 16, True, INK, maxw=548))
    return ''.join(o)
add(E6, 'Esercizio: scegliere il materiale',
    ['Cinque componenti di bordo',
     'Per ognuno: **materiale** e **perché**',
     'A coppie, **5 minuti**',
     'Soluzione nella **slide seguente**'],
    'cinque componenti per cui scegliere il materiale', d17(),
    "Far lavorare a coppie; chiedere per ogni componente il materiale e la proprietà che giustifica la scelta. Soluzione nella slide seguente.")

def d18():
    return grid('Soluzione', ['Componente', 'Materiale', 'Perché'], [
        ('Tubo acqua di mare', 'cupronichel 90/10 (o GRP)', 'corrosione, incrostazioni'), ('Elica portarinfuse', 'bronzo Ni-Al (CU3) o CU1', 'corrosione, colabilità'),
        ('Cisterna chimichiera', 'inox 316L o duplex', 'resistenza chimica'), ('Sovrastruttura veloce', 'alluminio 5083 / 6082', 'leggerezza'),
        ('Cuscinetto di banco', 'metallo bianco su acciaio', 'antifrizione, adattabilità')], [28, 230, 450], y0=62, rh=62, size=14)
add(E6, 'Soluzione dell\'esercizio',
    ['**Cupronichel** per l\'acqua di mare',
     '**Bronzo** per l\'elica',
     '**Inox o duplex** per i chimici',
     '**Alluminio** e **metallo bianco**'],
    'materiali consigliati e motivazioni', d18(),
    "Soluzione commentata. 1) Tubo dell'acqua di mare: cupronichel 90/10 (resistenza alla corrosione, effetto antivegetativo); in alternativa vetroresina dove le regole lo ammettono, o acciaio zincato o rivestito con vita più breve. 2) Elica: bronzo al nichel-alluminio CU3 o bronzo al manganese CU1 (UR W24). 3) Cisterna per acidi: acciaio inossidabile 316L o duplex secondo il prodotto (Codice IBC e lista di compatibilità del carico). 4) Sovrastruttura di un traghetto veloce: leghe di alluminio 5083 per le lamiere e 6082 per i profilati, isolate per il fuoco. 5) Cuscinetto di banco: guscio di acciaio con metallo bianco (o leghe al rame-piombo e alluminio-stagno nei motori veloci).")

def d19():
    return rows('Domanda C.5: completare la risposta', [
        ('Lezione 1', 'acciai da scafo: gradi, k, classi, certificati', 'b'),
        ('Oggi', 'inox, ghise, alluminio, leghe di rame, non metallici', 'b'),
        ('Per ognuno', 'dove si usa, proprietà meccaniche, proprietà tecnologiche', 'r'),
        ('Esempio', 'ghisa: colabilità e smorzamento; non si salda', 'y'),
        ('Esempio', 'cupronichel: resiste all\'acqua di mare; erosione se l\'acqua è veloce', 'y')], y0=62, lw=140, size=14)
add(E6, 'Domanda C.5: la risposta completa',
    ['Partire dall\'**acciaio** (lezione 1)',
     'Aggiungere i **materiali di macchina**',
     'Per ognuno una proprietà **tecnologica**',
     'Chiudere con un **limite** d\'uso'],
    'come completare la risposta alla domanda C.5', d19(),
    "Riprendere la traccia della lezione 1 (slide 41) e completarla con i materiali di oggi. Per ogni materiale: impiego, proprietà che giustifica l'impiego, una proprietà tecnologica e un limite. Esempi: ghisa grigia (colabilità, smorzamento delle vibrazioni; fragile, non si salda in modo affidabile); acciaio inossidabile (resistenza alla corrosione; pitting con cloruri, costo); alluminio (leggerezza, buona saldabilità delle leghe 5000; perdita di resistenza al fuoco, corrosione galvanica); cupronichel (resistenza all'acqua di mare; erosione-corrosione ad alta velocità); metallo bianco (antifrizione; fonde in caso di surriscaldamento).")

def d20():
    o = [grid('Riepilogo della prima parte', ['Materiale', 'Pregio', 'Attenzione a'], [
        ('Inox', 'corrosione', 'cloruri, fessure'), ('Ghisa', 'colabilità', 'urti, saldatura'), ('Alluminio', 'leggerezza', 'fuoco, galvanica'),
        ('Leghe di rame', 'acqua di mare', 'velocità, solfuri'), ('Compositi', 'peso, forme', 'fuoco'), ('Non metallici', 'tenuta, isolamento', 'fuoco, amianto')],
        [28, 230, 430], y0=62, rh=56, size=15)]
    return ''.join(o)
add(E6, 'Pregi e punti deboli',
    ['Ogni materiale ha un **punto debole**',
     'La scelta è sempre un **compromesso**',
     'Conta l\'**ambiente**: acqua, fuoco, temperatura',
     'E il **contatto** con altri metalli'],
    'pregio principale e punto debole di ogni famiglia', d20(),
    "Tabella di sintesi: per ogni famiglia di materiali il pregio che ne giustifica l'uso e il punto debole che l'ufficiale di macchina deve sorvegliare. Fa da ponte verso la lezione 3, in cui l'ambiente (acqua di mare, cloruri, contatto tra metalli) diventa il tema principale.")

def d21():
    o = [head('Saldatura e prove: che cosa viene dopo la pausa')]
    for i, (t, s, k) in enumerate([('Saldatura', 'processi, giunti, materiali d\'apporto', 'b'), ('Qualifiche', 'procedure (W28) e saldatori (W32)', 'b'),
                                   ('Difetti', 'zona termicamente alterata, cricche', 'r'), ('Controlli', 'VT, PT, MT, UT, RT (W33)', 'r'),
                                   ('A bordo', 'lavori a caldo, cassa combustibile', 'y'), ('Riparazioni', 'qualità secondo Rec. 47', 'g')]):
        o.append(tile(28 + (i % 2) * 312, 62 + (i // 2) * 124, 298, 108, t, s, k))
    return ''.join(o)
add(E6, 'Dopo la pausa',
    ['**Saldatura**: come si unisce l\'acciaio',
     '**Qualifiche** e materiali d\'apporto',
     '**Controlli non distruttivi**',
     'Saldare **a bordo** in sicurezza'],
    'programma della seconda parte', d21(),
    "Presentare la seconda parte prima della pausa, così i corsisti vedono il collegamento: i materiali della prima parte si uniscono quasi sempre per saldatura; la qualità del giunto dipende dalla procedura, dal saldatore e dai controlli.")

def d22():
    o = [head('Tre domande per la pausa')]
    qs = ['Perché la ghisa grigia non si usa per parti soggette a urti?', 'Che cosa misura l\'indice PREN?', 'Come si unisce una sovrastruttura in alluminio a un ponte in acciaio?']
    for i, q in enumerate(qs):
        y = 80 + i * 110
        o.append(R(28, y, 610, 88, SOFTY, YEL, 2, 9)); o.append(T(46, y + 52, f'{i + 1}', 24, True, '#7A5200'))
        o.append(TW(84, y + 40, q, 17, 530, bold=True))
    return ''.join(o)
add('PARTE 1 · SINTESI', 'Sintesi della prima parte',
    ['**Inox**: cromo, film passivo, attenzione ai cloruri',
     '**Ghise**: colabilità; la grigia è fragile',
     '**Alluminio**: leggero, isolato, giunti bimetallici',
     '**Rame**: eliche, tubi, cuscinetti'],
    'domande di richiamo per la pausa', d22(),
    "Domande per la pausa, risposte alla ripresa (slide 23). Risposte attese: 1) perché la grafite in lamelle agisce come tante piccole cricche: la ghisa grigia è fragile, ha allungamento quasi nullo e non sopporta urti; 2) la resistenza al pitting di un acciaio inossidabile in funzione di cromo, molibdeno e azoto (PREN = Cr + 3,3 Mo + 16 N); 3) con un giunto di transizione bimetallico saldato all'acciaio da un lato e all'alluminio dall'altro, o con unioni bullonate isolate, per evitare la corrosione galvanica.")
