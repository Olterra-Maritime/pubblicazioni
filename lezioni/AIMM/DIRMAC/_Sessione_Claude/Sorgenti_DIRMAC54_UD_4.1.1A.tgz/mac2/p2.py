"""Lezione 2 (20/11/2026) · U.D. 4.1.1 A · saldatura e prove · parte 2 (slide 23-45)."""
from lib import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes, dur=5):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes, dur=dur))

E7 = 'PARTE 2 · SALDATURA'
E8 = 'PARTE 2 · DIFETTI'
E9 = 'PARTE 2 · CONTROLLI NON DISTRUTTIVI'
E10 = 'PARTE 2 · A BORDO'
E11 = 'PARTE 2 · VERIFICA'

def d23():
    o = [head('Risposte e programma della seconda parte')]
    ans = [('1', 'fragile: lamelle di grafite'), ('2', 'resistenza al pitting'), ('3', 'giunto bimetallico')]
    for i, (n, a) in enumerate(ans):
        x = 28 + i * 206
        o.append(R(x, 62, 196, 70, SOFTG, GREEN, 2, 9)); o.append(T(x + 14, 90, f'Domanda {n}', 14, True, GRAY))
        o.append(T(x + 14, 116, a, 15, True, GREEN, maxw=170))
    blocks = [('Saldatura', 'processi, giunti, qualifiche', 'b'), ('Difetti', 'ZTA, cricche, deformazioni', 'b'),
              ('Controlli', 'VT, PT, MT, UT, RT', 'r'), ('A bordo', 'lavori a caldo, cassa combustibile, riparazioni', 'r')]
    for i, (t, s, k) in enumerate(blocks):
        x = 28 + (i % 2) * 312; y = 160 + (i // 2) * 130
        o.append(tile(x, y, 298, 112, t, s, k))
    return ''.join(o)
add('PARTE 2 · RIPRESA', 'Ripresa: risposte e programma',
    ['Risposte alle **tre domande** della pausa',
     '**Saldatura** e qualifiche',
     '**Difetti** e **controlli** non distruttivi',
     'Saldare **a bordo** in sicurezza'],
    'risposte di richiamo e blocchi della seconda parte', d23(),
    "Verificare le risposte della pausa: 1) la ghisa grigia è fragile perché la grafite in lamelle agisce come un insieme di microcricche; 2) il PREN misura la resistenza al pitting di un inossidabile (Cr + 3,3 Mo + 16 N); 3) giunto bimetallico o unioni bullonate isolate. Seconda parte: saldatura e qualifiche, difetti, controlli non distruttivi, saldatura a bordo e in una cassa combustibile, riparazioni.", dur=4)

def d24():
    return grid('Processi di saldatura ad arco', ['Sigla', 'Processo', 'Dove si usa'], [
        ('SMAW (111)', 'elettrodo rivestito', 'riparazioni, bordo, posizioni difficili'), ('GMAW/MAG (135)', 'filo pieno con gas attivo', 'cantiere, semiautomatica'),
        ('FCAW (136)', 'filo animato', 'cantiere, tutte le posizioni'), ('SAW (12)', 'arco sommerso', 'lamiere in piano, pannelli'),
        ('TIG (141)', 'tungsteno, gas inerte', 'tubi, inox, alluminio')],
        [28, 200, 380], y0=62, rh=62, size=14)
add(E7, 'La saldatura in costruzione navale',
    ['La nave moderna è **tutta saldata**',
     'In cantiere: **filo** e **arco sommerso**',
     'A bordo: soprattutto **elettrodo** e TIG',
     'Ogni processo ha la sua **qualifica**'],
    'processi di saldatura e impieghi tipici', d24(),
    "Processi ad arco più usati (con il numero ISO 4063 tra parentesi): elettrodo rivestito SMAW (111), il più usato nelle riparazioni a bordo per semplicità e per tutte le posizioni; saldatura a filo pieno con gas attivo MAG (135) e a filo animato FCAW (136), semiautomatiche, molto usate in cantiere; arco sommerso SAW (12), automatico, per lamiere in piano e pannelli dei blocchi; TIG (141) con elettrodo di tungsteno e gas inerte, per tubi, acciai inossidabili, alluminio e prime passate. Nei materiali d'apporto della UR W17 i suffissi indicano il processo (S arco sommerso, M e TM filo, T tecnica a due passate, V elettrogas ed elettroscoria). Per l'alluminio si usano MIG e TIG con apporto secondo UR W26.")

def d25():
    o = [head('Giunti e posizioni')]
    # testa a testa
    o.append(P([(40, 120), (150, 120), (160, 100), (40, 100)], '#C9D6DE', HULL, 2)); o.append(P([(290, 120), (180, 120), (170, 100), (290, 100)], '#C9D6DE', HULL, 2))
    o.append(P([(150, 120), (180, 120), (176, 96), (154, 96)], ORANGE, RUST, 2)); o.append(T(165, 150, 'testa a testa', 14, True, INK, 'middle'))
    # a T con cordoni d'angolo
    o.append(R(380, 112, 240, 20, '#C9D6DE', HULL, 2, 0)); o.append(R(492, 50, 16, 62, '#C9D6DE', HULL, 2, 0))
    o.append(P([(476, 112), (492, 96), (492, 112)], ORANGE, RUST, 2)); o.append(P([(508, 112), (508, 96), (524, 112)], ORANGE, RUST, 2))
    o.append(T(500, 150, 'a T con cordoni d\'angolo', 14, True, INK, 'middle'))
    o.append(grid(None, ['Posizione (ISO 6947)', 'Sigla', 'Difficoltà'], [('in piano', 'PA', 'bassa'), ('orizzontale', 'PC', 'media'), ('verticale ascendente', 'PF', 'alta'), ('sopratesta', 'PE', 'massima')],
                  [28, 330, 460], y0=180, rh=50, size=15))
    return ''.join(o)
add(E7, 'Giunti e posizioni di saldatura',
    ['**Testa a testa**: lamiere in linea',
     '**A T** con cordoni d\'angolo: rinforzi',
     'Posizioni: **piano**, verticale, **sopratesta**',
     'A bordo si salda spesso **in posizione difficile**'],
    'giunti principali e posizioni di saldatura', d25(),
    "Giunti principali: testa a testa (lamiere in prosecuzione, con cianfrino e penetrazione completa; i giunti del fasciame e dei corsi), a T e a croce (rinforzi su lamiera, con cordoni d'angolo o a piena penetrazione nei punti più sollecitati), a sovrapposizione (raddoppi, da evitare nelle strutture primarie). Posizioni secondo ISO 6947: PA in piano, PB d'angolo in piano, PC orizzontale su parete verticale, PF verticale ascendente, PG verticale discendente, PE sopratesta. Le qualifiche di saldatori e procedure valgono per le posizioni provate (UR W32, 3.8). A bordo, nelle riparazioni, si salda spesso in verticale o sopratesta, in spazi ristretti: è un motivo in più per usare saldatori qualificati per quelle posizioni.")

def d26():
    return rows('Materiali d\'apporto: richiamo e alluminio', [
        ('Acciaio (W17)', 'gradi 1–3, 1Y–4Y, 2Y40–5Y40: tenacità e resistenza', 'b'),
        ('Idrogeno', 'marchi H15, H10, H5: basso idrogeno per gli HT', 'r'),
        ('Conservazione', 'elettrodi basici asciutti: forno di essiccazione', 'y'),
        ('Alluminio (W26)', 'fili e bacchette approvati per le leghe W25', 'b'),
        ('Inox e rame', 'apporto della stessa famiglia o superiore', 'n')], y0=62, lw=150, size=14)
add(E7, 'Materiali d\'apporto',
    ['Gradi e marchi: **lezione 1**',
     'Elettrodi basici: **asciutti**',
     'Alluminio: apporto approvato (**UR W26**)',
     'L\'apporto sbagliato **annulla** il materiale buono'],
    'materiali d\'apporto per acciaio e altri metalli', d26(),
    "Richiamo della lezione 1 (UR W17 Rev.6): i materiali d'apporto per acciai da scafo hanno gradi di resistenza e tenacità e marchi di idrogeno diffusibile (H15, H10, H5). Gli elettrodi basici a basso idrogeno assorbono umidità: vanno conservati e, se richiesto dal fabbricante, essiccati in forno e tenuti in fornetti portatili durante il lavoro; l'umidità porta idrogeno nella saldatura e cricche a freddo. Per le leghe di alluminio i materiali d'apporto sono approvati secondo UR W26 Rev.2 (2021). Per inossidabili e leghe di rame si usa un apporto della stessa famiglia o più legato. Messaggio: un materiale base certificato con un apporto non adatto dà un giunto non conforme.")

def d27():
    return vflow('Qualifica del procedimento (UR W28)', [('pWPS', 'procedura preliminare del cantiere o del fornitore'), ('Saggio', 'saldato con l\'ispettore della classe presente'),
                 ('Prove', 'controlli non distruttivi e prove distruttive'), ('WPQR', 'verbale con i risultati, firmato dalla classe'), ('WPS', 'procedura approvata, usata in produzione')],
                 colors=[STEEL, BLUE, RUST, GREEN, GREEN], note='Rev.2 (2012) in vigore; Rev.3 dal 1° gennaio 2027')
add(E7, 'Qualifica dei procedimenti',
    ['La **WPS** dice come si salda',
     'Si prova su un **saggio** davanti alla classe',
     'Prove: **trazione, piega, resilienza, durezza**',
     'Vale entro i **campi** provati'],
    'dalla procedura preliminare alla procedura approvata', d27(),
    "IACS UR W28 Rev.2 (marzo 2012), qualifica dei procedimenti di saldatura per acciai da scafo e strutture marine (la Rev.3, revisione completa, si applica dal 1° gennaio 2027). Il cantiere o il fabbricante prepara una specifica preliminare (pWPS) con tutte le variabili: materiale base, apporto, processo, posizione, preparazione, preriscaldo, energia, temperatura tra le passate (3.1). Il saggio si salda alla presenza dell'ispettore e si sottopone a controlli non distruttivi e a prove distruttive: trazione trasversale, piega, resilienza nel metallo depositato e nella zona termicamente alterata, macrografia e durezza (oltre 355 N/mm², massimo 350 HV10). I risultati sono raccolti nel verbale (WPQR) e la WPS approvata vale entro i campi definiti dalla UR (spessori, posizioni, gradi). A bordo: una riparazione strutturale si esegue con una WPS approvata, che il cantiere o la ditta deve poter esibire.")

def d28():
    return rows('Qualifica dei saldatori (UR W32)', [
        ('Campo', 'acciai da scafo; esclusi tubi, recipienti e ossiacetilene', 'n'),
        ('Prova', 'saggio nel processo, posizione e spessore da qualificare', 'b'),
        ('Firma', 'ogni 6 mesi dal responsabile della qualità', 'y'),
        ('Rinnovo', 'nuova prova ogni 3 anni, o due saldature controllate ogni 2', 'r'),
        ('Revoca', 'interruzione oltre 6 mesi o dubbi sulla capacità', 'r')], y0=62, lw=120, size=14)
add(E7, 'Qualifica dei saldatori',
    ['Il **saldatore** ha un certificato',
     'Vale per **processo, posizione, spessore**',
     'Va **firmato ogni sei mesi**',
     'Rinnovo ogni **2 o 3 anni**'],
    'come si qualifica e si mantiene un saldatore', d28(),
    "IACS UR W32 Rev.1 (settembre 2020), schema di qualifica dei saldatori di acciai da scafo; non copre la saldatura ossiacetilenica e quella di tubi e recipienti in pressione (che seguono altre norme, per esempio ISO 9606-1). Il saldatore esegue un saggio nel processo, tipo di giunto, posizione e campo di spessori da qualificare. Validità (paragrafo 6): il certificato è firmato ogni sei mesi dal responsabile della qualità di produzione, purché il saldatore abbia lavorato con continuità (interruzioni non oltre sei mesi) e non ci siano motivi di dubbio; il mantenimento si fa con una delle opzioni della UR: nuova prova ogni 3 anni, oppure ogni 2 anni due saldature degli ultimi sei mesi controllate con radiografia, ultrasuoni o prove distruttive, oppure validità continua con firme regolari e controlli di produzione. A bordo: chiedere i certificati dei saldatori della ditta di riparazione.")

def d29():
    o = [head('Zona termicamente alterata (ZTA)')]
    o.append(R(40, 130, 580, 60, '#C9D6DE', HULL, 2, 0))
    o.append(P([(300, 130), (360, 130), (350, 190), (310, 190)], ORANGE, RUST, 2))
    o.append(P([(286, 130), (300, 130), (310, 190), (296, 190)], '#E7B58F', None, 0)); o.append(P([(360, 130), (374, 130), (364, 190), (350, 190)], '#E7B58F', None, 0))
    o.append(T(330, 116, 'metallo fuso', 13, True, RUST, 'middle')); o.append(T(250, 216, 'ZTA', 14, True, '#A8450F')); o.append(T(390, 216, 'ZTA', 14, True, '#A8450F'))
    o.append(T(80, 116, 'materiale base', 13, True, INK))
    o.append(rows('', [('Durezza', 'raffreddamento rapido: ZTA dura e fragile', 'r'), ('Idrogeno', 'umidità, ruggine, grasso → cricche a freddo', 'r'),
                       ('Rimedi', 'preriscaldo, basso idrogeno, apporto termico corretto', 'g')], y0=246, lw=120, size=14))
    return ''.join(o)
add(E8, 'Zona termicamente alterata',
    ['Accanto al cordone l\'acciaio si **trasforma**',
     'Raffreddamento rapido: zona **dura**',
     '**Idrogeno** + durezza + tensioni = cricche',
     'Rimedi: **preriscaldo**, basso idrogeno'],
    'cordone, zona termicamente alterata e rischi', d29(),
    "Durante la saldatura il materiale base vicino al cordone si scalda oltre la temperatura di trasformazione senza fondere: è la zona termicamente alterata (ZTA). Se si raffredda rapidamente (lamiere spesse, freddo, apporto termico basso) può diventare dura e fragile. Le cricche a freddo (o da idrogeno) nascono dalla combinazione di tre fattori: struttura dura, idrogeno nel metallo (umidità dell'elettrodo, ruggine, grasso, vernice) e tensioni. Possono comparire anche ore dopo la saldatura: per questo la UR W33 fa attendere 48 o 72 ore prima dei controlli sugli acciai più resistenti (slide 37). Rimedi: preriscaldo secondo spessore e carbonio equivalente, elettrodi a basso idrogeno asciutti, pulizia dei lembi, apporto termico corretto, a volte post-riscaldo.", dur=4)

def d30():
    o = [head('Difetti di saldatura')]
    o.append(R(40, 150, 580, 50, '#C9D6DE', HULL, 2, 0))
    o.append(P([(250, 150), (410, 150), (395, 200), (265, 200)], ORANGE, RUST, 2))
    o.append(PATH('M 250 150 Q 330 120 410 150', ORANGE, RUST, 2))
    marks = [(300, 175, 'porosità', 'o'), (355, 168, 'inclusione', 'x'), (268, 192, 'mancata fusione', '|'), (330, 199, 'mancata penetrazione', '_'), (395, 150, 'incisione marginale', 'v'), (340, 185, 'cricca', '/')]
    for x, y, t, k in marks:
        if k == 'o':
            o.append(C(x, y, 4, 'none', INK, 1.5)); o.append(C(x + 10, y + 4, 3, 'none', INK, 1.5))
        elif k == 'x':
            o.append(R(x - 6, y - 3, 12, 6, INK, None, 0, 2))
        elif k == '/':
            o.append(L(x - 8, y + 8, x + 8, y - 8, RUST, 2.5))
        else:
            o.append(C(x, y, 4, RUST))
    labels = [('porosità', 300, 175), ('inclusioni di scoria', 355, 168), ('mancata fusione', 268, 192), ('mancata penetrazione', 330, 199), ('incisione marginale', 395, 150), ('cricca', 340, 185)]
    for i, (t, x, y) in enumerate(labels):
        ly = 236 + i * 34
        o.append(T(60, ly, t, 15, True, INK)); o.append(L(250, ly - 5, x, y, GRAY, 1))
    return ''.join(o)
add(E8, 'Difetti di saldatura',
    ['**Porosità** e **inclusioni** di scoria',
     '**Mancata fusione** o penetrazione',
     '**Incisioni marginali**: intagli in superficie',
     '**Cricche**: il difetto più grave'],
    'difetti tipici in un giunto testa a testa, schema', d30(),
    "Difetti principali (classificazione ISO 6520): porosità (gas intrappolato: umidità, protezione gassosa insufficiente, vento), inclusioni di scoria (pulizia insufficiente tra le passate), mancata fusione con i lembi o tra le passate e mancata penetrazione alla radice (energia insufficiente, cianfrino sbagliato), incisioni marginali (solchi al bordo del cordone, intagli superficiali pericolosi a fatica), eccesso di sovrametallo, cricche (a freddo da idrogeno, a caldo di solidificazione, da strappo lamellare). Le cricche non sono mai accettabili; gli altri difetti hanno livelli di accettabilità (ISO 5817, richiamata dalla UR W33). Collegamento con la fatica: incisioni marginali e sovrametallo eccessivo concentrano la tensione al piede del cordone, dove nascono le cricche di fatica.")

def d31():
    return rows('Deformazioni e tensioni residue', [
        ('Perché', 'il cordone si ritira raffreddandosi', 'n'),
        ('Effetti', 'lamiere imbarcate, ritiro, tensioni fino allo snervamento', 'r'),
        ('Sequenza', 'saldare dal centro verso i bordi, a passo del pellegrino', 'g'),
        ('Vincoli', 'imbastiture, contrappesi, pre-deformazione', 'g'),
        ('Correzione', 'raddrizzatura a fiamma con temperature controllate', 'y')], y0=62, lw=140, size=14)
add(E8, 'Deformazioni e tensioni residue',
    ['Il cordone **si ritira** raffreddandosi',
     'Lamiere **imbarcate** e tensioni residue',
     'Contano **sequenza** e vincoli',
     'Raddrizzare a fiamma con **cautela**'],
    'cause e rimedi delle deformazioni di saldatura', d31(),
    "Il metallo fuso e la zona vicina si dilatano e poi si ritirano raffreddandosi, contrastati dal materiale freddo intorno: ne derivano deformazioni (lamiere imbarcate tra i rinforzi, ritiri longitudinali e trasversali, rotazioni) e tensioni residue che possono arrivare allo snervamento. Si limitano con la sequenza di saldatura (dal centro verso l'esterno, saldature simmetriche, tecnica a passo del pellegrino), con vincoli e imbastiture, con un apporto termico controllato. Le deformazioni si correggono con raddrizzatura a fiamma: sugli acciai TM e bonificati la temperatura va controllata (nella lezione 1: non oltre circa 580 °C per i TM senza accordo con la classe). In riparazione a bordo: inserti di lamiera grandi saldati senza sequenza producono imbarcamenti visibili e tensioni residue.")

def d32():
    return grid('Controlli non distruttivi (UR W33)', ['Metodo', 'Trova', 'Materiali'], [
        ('VT · visivo', 'difetti superficiali, forma del cordone', 'tutti'), ('PT · liquidi penetranti', 'difetti aperti in superficie', 'tutti i non porosi'),
        ('MT · magnetoscopia', 'difetti superficiali e subito sotto', 'solo ferromagnetici'), ('UT · ultrasuoni', 'difetti interni, spessori', 'spessore ≥ 8 mm per i giunti'),
        ('RT · radiografia', 'difetti interni volumetrici', 'tutti, con limiti di accesso')], [28, 220, 440], y0=62, rh=66, size=14)
add(E9, 'I metodi di controllo',
    ['**Superficie**: VT, PT, MT',
     '**Interno**: UT, RT',
     'Ogni metodo ha i suoi **limiti**',
     'Operatori **certificati** (ISO 9712)'],
    'metodi di controllo non distruttivo e campi d\'impiego', d32(),
    "IACS UR W33 Rev.1 Corr.1 (2021), controlli non distruttivi delle saldature di scafo in acciaio (la Rev.2 si applica dal 1° gennaio 2028; la UR W34 riguarda i metodi avanzati come phased array, TOFD e radiografia digitale). Metodi convenzionali: per i difetti superficiali VT (visivo), PT (liquidi penetranti), MT (magnetoscopia); per i difetti interni UT (ultrasuoni) e RT (radiografia) (2.5.1). Tabella 1 della UR: per i giunti testa a testa a piena penetrazione sotto 8 mm VT, PT, MT, RT; da 8 mm in su anche UT; per i giunti a T e d'angolo senza piena penetrazione VT, PT, MT e UT per controllare la penetrazione. La magnetoscopia funziona solo sugli acciai ferromagnetici (non sugli austenitici, sull'alluminio, sulle leghe di rame). Il personale è certificato secondo ISO 9712 (livelli 1, 2, 3).")

def d33():
    return vflow('Liquidi penetranti (PT)', [('Pulizia', 'superficie sgrassata e asciutta'), ('Penetrante', 'liquido rosso o fluorescente, tempo di contatto'),
                 ('Rimozione', 'eccesso tolto senza svuotare i difetti'), ('Rivelatore', 'polvere bianca che richiama il liquido'), ('Lettura', 'segni rossi: difetti aperti in superficie')],
                 colors=[STEEL, RUST, STEEL, BLUE, GREEN], note='Visivo (VT) prima di tutto: buona luce, distanza, specchi')
add(E9, 'Visivo e liquidi penetranti',
    ['Il **visivo** viene sempre prima',
     'PT: il liquido entra nei difetti **aperti**',
     'Funziona su **tutti** i metalli non porosi',
     'Semplice: si fa anche **a bordo**'],
    'sequenza della prova con liquidi penetranti', d33(),
    "Esame visivo (VT): il primo controllo, sempre; richiede buona illuminazione, accesso, eventualmente lenti e specchi; verifica forma del cordone, incisioni, cricche visibili, porosità superficiali. Liquidi penetranti (PT): la superficie pulita e asciutta riceve un liquido colorato (rosso) o fluorescente che per capillarità entra nei difetti aperti in superficie; dopo il tempo di contatto si rimuove l'eccesso, si applica un rivelatore bianco che richiama il liquido dai difetti, che appaiono come segni rossi su fondo bianco. Pregi: semplice, economico, adatto a tutti i metalli non porosi, anche inox, alluminio e bronzi (per esempio cricche sulle pale delle eliche). Limiti: trova solo difetti aperti in superficie, richiede superfici pulite. A bordo si usa per controllare una riparazione o una cricca sospetta.")

def d34():
    o = [head('Magnetoscopia (MT)')]
    o.append(R(60, 150, 520, 40, '#C9D6DE', HULL, 2, 0))
    o.append(PATH('M 160 150 L 160 100 L 260 100 L 260 150', 'none', INK, 6)); o.append(T(210, 90, 'giogo', 14, True, INK, 'middle'))
    for i in range(6):
        o.append(PATH(f'M {170 + i * 15} 152 q 10 14 20 0', 'none', BLUE, 1.5))
    o.append(L(330, 150, 345, 170, RUST, 3)); o.append(T(352, 140, 'cricca: le particelle si accumulano', 13, True, RUST))
    for i in range(8):
        o.append(C(326 + (i % 4) * 6, 146 + (i // 4) * 4, 2, INK))
    o.append(rows('', [('Principio', 'campo magnetico: un difetto crea una dispersione', 'b'), ('Rivela', 'difetti superficiali e poco sotto la superficie', 'b'),
                       ('Limite', 'solo materiali ferromagnetici; orientare il campo in due direzioni', 'r')], y0=226, lw=120, size=14))
    return ''.join(o)
add(E9, 'Magnetoscopia',
    ['Si **magnetizza** il pezzo',
     'Un difetto **disperde** il campo',
     'Le **particelle** si accumulano sul difetto',
     'Solo acciai **ferromagnetici**'],
    'principio della magnetoscopia, schema', d34(),
    "Magnetoscopia (MT): il pezzo viene magnetizzato (giogo elettromagnetico, puntali, bobine); dove c'è una discontinuità superficiale o poco sotto la superficie il campo magnetico disperde all'esterno e le particelle ferromagnetiche (secche o in sospensione, colorate o fluorescenti) si accumulano disegnando il difetto. È più sensibile dei liquidi penetranti per le cricche fini e trova difetti chiusi poco sotto la superficie, ma funziona solo sui materiali ferromagnetici (acciai al carbonio e basso legati, non austenitici, alluminio, rame). Il campo deve essere orientato perpendicolarmente al difetto: si magnetizza in due direzioni. Uso tipico: cricche nei cordoni d'angolo, nei braccioli, negli alberi e nei fucinati (UR W7 e W8).", dur=4)

def d35():
    o = [head('Ultrasuoni (UT)')]
    o.append(R(60, 120, 520, 70, '#C9D6DE', HULL, 2, 0))
    o.append(R(150, 98, 60, 22, INK, None, 0, 3)); o.append(T(180, 90, 'sonda', 13, True, INK, 'middle'))
    o.append(L(180, 120, 180, 190, BLUE, 2, '5 4')); o.append(L(186, 190, 186, 120, BLUE, 2, '5 4'))
    o.append(R(380, 98, 60, 22, INK, None, 0, 3)); o.append(L(410, 120, 470, 165, BLUE, 2, '5 4')); o.append(R(462, 158, 18, 10, RUST, None, 0, 2))
    o.append(T(470, 150, 'difetto', 13, True, RUST))
    o.append(rows('', [('Spessimetria', 'tempo di andata e ritorno → spessore', 'g'), ('Difetti interni', 'eco riflessa da una discontinuità', 'b'),
                       ('Pregi', 'nessuna radiazione, risultati subito', 'g'), ('Limiti', 'operatore esperto; superficie e accoppiante', 'r')], y0=216, lw=130, size=14))
    return ''.join(o)
add(E9, 'Ultrasuoni',
    ['Onde sonore ad **alta frequenza** nel metallo',
     'Lo **spessore** dal tempo dell\'eco',
     'I **difetti interni** riflettono l\'onda',
     'È lo strumento della **spessimetria** ESP'],
    'ultrasuoni per spessori e difetti, schema', d35(),
    "Gli ultrasuoni (UT) inviano nel metallo onde sonore ad alta frequenza tramite una sonda e un accoppiante (gel, acqua). Con la sonda dritta, il tempo tra l'impulso e l'eco della parete opposta dà lo spessore: è il metodo della spessimetria usata nelle visite di classe e ESP (lezione 3), eseguita da ditte approvate. Con sonde angolate si cercano difetti interni nelle saldature: una discontinuità riflette parte dell'onda e la posizione dell'eco ne indica profondità e distanza. Pregi: nessun rischio da radiazioni, risultati immediati, rileva bene cricche e mancate fusioni. Limiti: richiede operatori qualificati (ISO 9712), superfici preparate, non adatto sotto 8 mm per i giunti secondo W33 (salvo metodi avanzati) e difficile negli austenitici a grano grosso. Versioni avanzate (phased array, TOFD) nella UR W34.")

def d36():
    return rows('Radiografia (RT)', [
        ('Principio', 'raggi X o gamma attraversano il pezzo e impressionano una pellicola', 'b'),
        ('Rivela', 'difetti volumetrici: porosità, inclusioni, mancata penetrazione', 'b'),
        ('Pregio', 'documento permanente del giunto', 'g'),
        ('Limiti', 'cricche parallele al fascio poco visibili; servono i due lati', 'r'),
        ('Sicurezza', 'radiazioni: area sgombra, personale autorizzato', 'r')], y0=62, lw=140, size=14)
add(E9, 'Radiografia',
    ['Raggi **X** o **gamma** attraverso il giunto',
     'Mostra difetti **volumetrici**',
     'Lascia un **documento** del controllo',
     'Richiede **sicurezza** per le radiazioni'],
    'principio, pregi e limiti della radiografia', d36(),
    "Radiografia (RT): una sorgente di raggi X o gamma attraversa il giunto e impressiona una pellicola o un rivelatore digitale posto dall'altro lato; i difetti che riducono lo spessore attraversato (porosità, inclusioni, mancata penetrazione) appaiono più scuri. Pregi: rileva bene i difetti volumetrici e lascia un documento permanente. Limiti: le cricche sottili orientate male si vedono poco; servono accesso ai due lati e spessori non eccessivi; nei giunti a T è poco efficace (W33, tabella 1, nota 3). Sicurezza: radiazioni ionizzanti, area delimitata e sgomberata, personale autorizzato: a bordo si coordina con il comandante e la guardia. Radiografia digitale e computerizzata sono metodi avanzati della UR W34.")

def d37():
    o = [head('Quanto e quando controllare (W33)')]
    o.append(rows('', [('Piano', 'il cantiere propone aree, estensione e livelli di qualità; la classe approva', 'b'),
                       ('Dove', 'zone molto sollecitate, a fatica, inaccessibili in servizio', 'r'),
                       ('Se trovo difetti', 'l\'estensione dei controlli aumenta', 'y')], y0=58, rh=62, lw=140, size=14))
    o.append(grid(None, ['Acciaio (ReH)', 'Attesa prima dei controlli'], [('420–690 N/mm²', '48 ore'), ('oltre 690 N/mm²', '72 ore')], [28, 330], y0=300, rh=44, size=15))
    o.append(T(28, 446, 'per le cricche ritardate da idrogeno', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(E9, 'Quanto e quando controllare',
    ['Un **piano** di controlli approvato',
     'Più controlli dove la **tensione** è alta',
     'Difetti trovati → **più** controlli',
     'Acciai molto resistenti: **attendere**'],
    'piano dei controlli e tempi di attesa', d37(),
    "IACS UR W33 Rev.1 Corr.1, paragrafo 5: estensione e livelli di qualità dei controlli sono pianificati dal cantiere secondo il progetto, il tipo di nave e i processi, e approvati dalla società di classifica (con riferimento alla UR Z23 per le visite di nuova costruzione). I punti di controllo privilegiano le saldature nelle zone molto sollecitate, quelle sensibili a fatica, gli elementi importanti, le saldature inaccessibili in servizio, quelle eseguite in opera e le zone sospette; se si trova un livello inaccettabile di indicazioni l'estensione aumenta. Paragrafo 2.4.2: per acciai con snervamento tra 420 e 690 N/mm² i controlli non si fanno prima di 48 ore dalla fine della saldatura, oltre 690 N/mm² non prima di 72 ore, per individuare le cricche ritardate da idrogeno. Per una riparazione a bordo il piano dei controlli si concorda con l'ispettore di classe.")

def d38():
    return rows('Chi esegue i controlli', [
        ('Livello 1', 'esegue il controllo secondo istruzioni', 'n'),
        ('Livello 2', 'imposta, esegue e interpreta; firma i risultati', 'b'),
        ('Livello 3', 'scrive le procedure, supervisiona, forma', 'b'),
        ('Norma', 'ISO 9712: certificazione per metodo', 'g'),
        ('Fornitori', 'ditte di controlli riconosciute (UR W35)', 'y')], y0=62, lw=140, size=14)
add(E9, 'Qualifica degli operatori',
    ['Operatori **certificati** per metodo',
     'Livelli **1, 2, 3** (ISO 9712)',
     'Il **livello 2** firma i risultati',
     'Ditte di controlli **riconosciute**'],
    'livelli di qualifica del personale per i controlli', d38(),
    "UR W33, paragrafo 3: il personale che esegue i controlli è qualificato e certificato secondo ISO 9712 (2012 nella revisione citata) per ogni metodo: livello 1 esegue i controlli secondo istruzioni scritte; livello 2 imposta l'apparecchiatura, esegue, interpreta e valuta secondo le norme e firma i rapporti; livello 3 redige procedure, supervisiona e forma; il fornitore deve avere almeno un supervisore di livello 3. Le ditte che eseguono controlli per conto di cantieri o armatori sono soggette ai requisiti della UR W35 (fornitori di servizi di controllo, Rev.1 2023; Rev.2 dal 2027 e Rev.3 dal 2028). Per le misure di spessore nelle visite ESP valgono i requisiti per le ditte approvate (Codice ESP e UR Z17). A bordo: verificare il certificato dell'operatore che firma un rapporto.")

def d39():
    return vflow('Lavori a caldo a bordo', [('Valutazione', 'rischio, alternative, area e spazi adiacenti'), ('Permesso', 'firmato secondo il SMS, valido per tempo e luogo'),
                 ('Preparazione', 'gas-free, rimozione dei combustibili, isolamento'), ('Durante', 'vigilanza antincendio, estintori, comunicazione'), ('Dopo', 'sorveglianza fino a raffreddamento')],
                 colors=[STEEL, RUST, BLUE, RUST, GREEN], note='Il permesso di lavoro a caldo è una procedura del sistema di gestione della sicurezza')
add(E10, 'Saldare a bordo',
    ['Ogni saldatura è un **lavoro a caldo**',
     'Serve un **permesso** del SMS',
     'Controllare anche gli **spazi adiacenti**',
     '**Vigilanza** antincendio prima, durante, dopo'],
    'fasi di un lavoro a caldo a bordo', d39(),
    "Ogni saldatura, taglio o molatura a bordo è un lavoro a caldo e segue la procedura del sistema di gestione della sicurezza (Codice ISM): valutazione del rischio e delle alternative (riparazione a freddo, rinvio al porto o al bacino); permesso di lavoro a caldo firmato dal responsabile, valido per un luogo e un tempo definiti; preparazione dell'area e degli spazi adiacenti (le scintille e il calore passano attraverso lamiere e paratie: casse di combustibile o di olio dall'altro lato, isolamenti, cavi); misura dell'atmosfera, rimozione dei combustibili, mezzi di estinzione pronti; vigilanza antincendio durante il lavoro e per un tempo stabilito dopo (le combustioni lente partono dopo). Sulle petroliere valgono anche le guide di settore (ISGOTT). Collegamento con l'antincendio del corso.", dur=4)

def d40():
    return rows('Domanda C.14: saldare in una cassa combustibile', [
        ('Prima', 'cassa vuota, isolata, pulita, ventilata, certificato gas-free', 'b'),
        ('Atmosfera', 'O₂ 20,9 %, infiammabili < 1 % LFL, tossici < 50 % OEL', 'r'),
        ('Permessi', 'spazio chiuso + lavoro a caldo, al massimo 8 ore', 'y'),
        ('Persone', 'mai da soli: sorvegliante all\'ingresso, comunicazione', 'y'),
        ('Durante', 'misura continua, ventilazione, vigilanza antincendio', 'g')], y0=62, lw=140, size=14)
add(E10, 'Saldare in una cassa combustibile',
    ['È uno **spazio chiuso** e un **lavoro a caldo**',
     'Cassa **pulita**, isolata e **gas-free**',
     'Soglie di **MSC.581(110)**',
     'Misura **continua** e sorveglianza'],
    'traccia di risposta alla domanda C.14', d40(),
    "Domanda d'esame C.14: 'procedure per entrare in uno spazio confinato, e in particolare se deve essere eseguita saldatura all'interno di una cassa combustibile'. Traccia: la cassa è uno spazio chiuso e il lavoro è a caldo, quindi servono entrambi i permessi del SMS. Preparazione: cassa svuotata, isolata (valvole chiuse e bloccate, tubolature scollegate o flangiate cieche), pulita da residui e fanghi, ventilata, con certificato gas-free rilasciato da persona competente (in porto spesso un chimico). Raccomandazioni IMO per l'ingresso negli spazi chiusi MSC.581(110), che sostituiscono la A.1050(27): ossigeno 20,9 % in volume, infiammabili sotto l'1 % del limite inferiore di infiammabilità, tossici sotto il 50 % del limite di esposizione; divieto di ingresso di una persona da sola; permessi validi al massimo 8 ore; registro degli spazi chiusi. Durante il lavoro: misura continua dell'atmosfera, ventilazione, vigilanza antincendio anche negli spazi adiacenti, mezzi di soccorso pronti. Soglie: verificarle sul testo della risoluzione e sul SMS della compagnia.")

def d41():
    return rows('Riparazioni dello scafo', [
        ('Inserto', 'si taglia la parte danneggiata e si salda una lamiera nuova', 'g'),
        ('Raccordi', 'angoli arrotondati, giunti sfalsati rispetto ai rinforzi', 'b'),
        ('Raddoppio', 'lamiera sovrapposta: di norma solo temporaneo', 'r'),
        ('Cricche', 'fori di arresto solo provvisori; poi taglio e riparazione', 'y'),
        ('Qualità', 'IACS Rec. 47, parte B: tolleranze e accettazione', 'n')], y0=62, lw=140, size=14)
add(E10, 'Riparazioni dello scafo',
    ['**Inserti** di lamiera nuova',
     '**Raddoppi** solo temporanei',
     'Cricche: **foro di arresto** e poi riparazione',
     'Qualità secondo **IACS Rec. 47**'],
    'tipi di riparazione strutturale', d41(),
    "Riparazione definitiva tipica: inserto, cioè taglio della lamiera danneggiata e saldatura di una nuova dello stesso grado e spessore (lezione 1), con angoli arrotondati, giunti sfalsati rispetto a quelli esistenti e ai rinforzi, saldature a piena penetrazione e controlli. Il raddoppio (lamiera sovrapposta saldata a cordone d'angolo) è in genere accettato solo come riparazione temporanea, perché nasconde la corrosione sotto e concentra le tensioni. Una cricca si può fermare provvisoriamente con fori di arresto alle estremità, ma va poi riparata. La qualità di esecuzione (allineamenti, tolleranze, preparazione dei lembi, inserti minimi) segue lo standard IACS Rec. 47 (Shipbuilding and Repair Quality Standard), parte B per le riparazioni; ogni riparazione strutturale è concordata con la società di classifica.")

def d42():
    o = [head('Esercizio: dalla cricca alla riparazione')]
    o.append(R(28, 62, 610, 120, SOFTB, BLUE, 2, 10))
    for i, t in enumerate(['In navigazione trovi una cricca di 150 mm sul piede', 'di un bracciolo in una cisterna di zavorra (acciaio AH36).', 'Ritorno in porto previsto tra 10 giorni.']):
        o.append(T(44, 96 + i * 26, t, 15, True if i == 0 else False, INK, maxw=580))
    qs = ['Che cosa fai subito?', 'Con quale controllo misuri la cricca?', 'Chi decide la riparazione e come?']
    for i, q in enumerate(qs):
        y = 206 + i * 74
        o.append(R(28, y, 610, 62, SOFTY, YEL, 2, 9)); o.append(T(46, y + 38, str(i + 1), 20, True, '#7A5200'))
        o.append(T(76, y + 37, q, 16, True, INK, maxw=548))
    return ''.join(o)
add(E11, 'Esercizio: dalla cricca alla riparazione',
    ['Un caso di **bordo**',
     'Usare **tutta** la lezione',
     'A coppie, **5 minuti**',
     'Soluzione nella **slide seguente**'],
    'caso pratico su una cricca in una cisterna di zavorra', d42(),
    "Caso inventato ma tipico (i punti caldi a fatica sono quelli della lezione 3). Far ragionare i corsisti con le competenze di oggi: materiali, controlli, saldatura a bordo, ruolo della classe. Soluzione nella slide seguente.")

def d43():
    return vflow('Soluzione', [('Subito', 'segnalare a comandante, compagnia e classe; documentare con foto'), ('Misura', 'pulire, VT e MT o PT per la lunghezza reale'),
                 ('Provvisorio', 'se la classe accetta: fori di arresto alle estremità'), ('Definitivo', 'in porto: inserto con WPS approvata e saldatori qualificati'),
                 ('Verifica', 'controlli dopo l\'attesa prevista, ispettore di classe')], colors=[RUST, BLUE, YEL, GREEN, GREEN])
add(E11, 'Soluzione del caso',
    ['**Segnalare** e documentare',
     '**Misurare** con MT o PT',
     'Provvisorio solo se la **classe** accetta',
     'Definitivo con **procedura** e controlli'],
    'sequenza di intervento sulla cricca', d43(),
    "Soluzione commentata. 1) Segnalare al comandante e alla compagnia (Codice ISM, sezione 9) e, trattandosi di un danno strutturale, alla società di classifica; documentare con foto e posizione (ossatura, cisterna). 2) Pulire la zona, esaminare a vista e con magnetoscopia o liquidi penetranti per trovare le estremità reali della cricca (spesso più lunga di quanto appare). 3) Eventuale misura provvisoria (fori di arresto) solo se accettata dalla classe, che può imporre condizioni o limitazioni. 4) Riparazione definitiva in porto: taglio e inserto o rifacimento del bracciolo, materiale AH36 certificato, WPS approvata, saldatori qualificati, preriscaldo se previsto. 5) Controlli non distruttivi dopo il tempo di attesa e approvazione dell'ispettore. Domanda finale: perché la cricca è nata lì? (fatica al piede del bracciolo, eventuale corrosione: lezione 3).")

def d44():
    return grid('Quale controllo per quale difetto', ['Difetto', 'VT', 'PT', 'MT', 'UT', 'RT'], [
        ('cricca superficiale', '±', '✓', '✓', '±', '±'), ('cricca interna', '–', '–', '–', '✓', '±'), ('porosità', '±', '±', '–', '±', '✓'),
        ('mancata fusione', '–', '–', '±', '✓', '±'), ('spessore residuo', '–', '–', '–', '✓', '–'), ('inox, alluminio', '✓', '✓', '–', '±', '✓')],
        [28, 260, 336, 412, 488, 564], y0=62, rh=52, size=15)
add(E11, 'Tabella dei controlli',
    ['**✓** adatto · **±** con limiti · **–** non adatto',
     'Superficie: **PT, MT**',
     'Interno: **UT, RT**',
     'Spessori: solo **UT**'],
    'adeguatezza dei metodi per i difetti più comuni', d44(),
    "Tabella di sintesi per la verifica e per l'esame, costruita sulle slide 32–36 e sulla UR W33 (tabelle 1–3). Le valutazioni sono indicative: la scelta effettiva dipende da spessore, geometria del giunto, accessibilità e materiale. Ricordare che la magnetoscopia non si usa su inossidabili austenitici, alluminio e leghe di rame, e che gli ultrasuoni sono lo strumento della spessimetria.", dur=4)

def d45():
    o = [head('Tre idee da portare a bordo')]
    ideas = [('Ogni materiale ha un punto debole', 'cloruri, urti, fuoco, contatto tra metalli'), ('Una saldatura vale quanto la sua procedura', 'WPS, saldatore qualificato, apporto giusto'),
             ('Controllare è un metodo', 'il controllo giusto per il difetto e il materiale')]
    for i, (t, s) in enumerate(ideas):
        y = 70 + i * 116
        o.append(C(60, y + 40, 22, RUST)); o.append(T(60, y + 47, str(i + 1), 20, True, '#fff', 'middle'))
        o.append(R(100, y, 538, 84, '#F6F4EE', LINE, 1.5, 10)); o.append(T(118, y + 34, t, 18, True, INK, maxw=500)); o.append(T(118, y + 62, s, 15, False, GRAY, maxw=500))
    o.append(T(333, 440, 'Prossima lezione, 27/11: corrosione, protezione e bacino', 14, True, BLUE, 'middle', maxw=600))
    return ''.join(o)
add('PARTE 2 · SINTESI', 'Sintesi della lezione',
    ['Inox, ghise, alluminio, rame, **non metallici**',
     'Saldatura: **procedura**, saldatore, apporto',
     'Controlli: **VT, PT, MT, UT, RT**',
     'Prossima volta: **corrosione e bacino**'],
    'le tre idee chiave della lezione', d45(),
    "Chiusura. Riprendere le tre idee e annunciare l'ultima lezione del 27 novembre: corrosione (meccanismi, forme, corrosione a caldo e a freddo dei motori), protezione con pitture e protezione catodica, visite di classe e lavori in bacino. Chiedere ai corsisti di ripassare la tabella della slide 44 e le domande d'esame C.1, C.3 e C.4.")
