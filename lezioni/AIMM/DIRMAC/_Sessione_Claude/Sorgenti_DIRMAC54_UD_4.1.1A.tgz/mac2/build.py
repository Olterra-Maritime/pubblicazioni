import json
from render import *
import p1, p2
total = 45
def hm(m): return f'{m//60:02d}:{m%60:02d}'
slides_html = []; notes = []
meta = dict(title='Altri materiali, saldatura e prove', tsize=76, tlh=86,
            sub='Lezione 2 di 3 · inox, ghise, alluminio, leghe di rame, non metallici; saldatura e controlli non distruttivi', sub_top=600)
t = 8*60+30
slides_html.append(title_slide(meta, total, hm(t), hm(t+5))); notes.append("Min 0:00–0:05. U.D. 4.1.1 A, Materiali impiegati nella costruzione navale, lezione 2 di 3 (Corso Direttivo Macchina 54). Oggi: altri materiali di bordo (acciai inossidabili, ghise, leghe di alluminio, leghe di rame, compositi e non metallici), saldatura, qualifiche, difetti e controlli non distruttivi, saldatura a bordo e in una cassa combustibile. Struttura: prima parte 08:30–10:20, intervallo 20 minuti, seconda parte 10:40–12:30. Fonti: IACS UR serie W vigenti al 30/10/2026, Rec. 47, SOLAS, MSC.581(110); elenco nella slide 2. Gli schemi sono disegni originali; i numeri sono indicativi salvo dove è citata la fonte.")
t += 5; n = 2
for sl in p1.S:
    slides_html.append(content(sl, n, total, hm(t), hm(t+5))); notes.append(sl['notes']); t += 5; n += 1
assert t == 10*60+20 and n == 23, (hm(t), n)
slides_html.append(pause_slide('10:20', '10:40', 'Si riprende con saldatura, difetti e controlli non distruttivi')); notes.append('Intervallo di 20 minuti. La lezione riprende alle 10:40 e chiude alle 12:30.')
t = 10*60+40
for sl in p2.S:
    d = sl['dur']
    slides_html.append(content(sl, n, total, hm(t), hm(t+d), dark=(n == total))); notes.append(sl['notes']); t += d; n += 1
assert t == 12*60+30 and n == total+1, (hm(t), n)
if __name__ == '__main__':
    warn = render_pngs(slides_html, 'png')
    print('WARN', len(warn)); [print(w) for w in warn]
    json.dump(notes, open('notes.json', 'w'))
