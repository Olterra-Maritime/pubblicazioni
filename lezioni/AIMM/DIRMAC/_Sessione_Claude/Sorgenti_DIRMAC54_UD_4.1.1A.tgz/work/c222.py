"""Blocco U.D. 2.2.2 · corrosione e fatica (09:20-10:20), 11 slide nuove + spessori (ex slide 18)."""
import math
from lib import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes))

EC = 'PARTE 1 · CORROSIONE E FATICA'

# ---------------- C1 la catena del danno ----------------
def c1():
    o = [head('La catena del danno nelle portarinfuse')]
    steps = [('Corrosione', 'lo spessore delle lamiere cala', BLUE),
             ('Tensioni più alte', 'a parità di carico e di onda', STEEL),
             ('Cricche di fatica', 'nei punti dove la tensione si concentra', RUST),
             ('Cedimento', 'ossature, fianco, stiva allagata', INK)]
    for i, (t, s, c) in enumerate(steps):
        y = 58 + i * 84
        o.append(box(28, y, 380, 66, t, s, fill=c, tsize=18, ssize=15))
        if i < 3:
            o.append(A(218, y + 68, 218, y + 82, INK, 2.5, 8))
    o.append(R(428, 58, 210, 318, SOFTR, RUST, 2, 10))
    o.append(T(533, 92, 'ACCELERANO', 16, True, RUST, 'middle'))
    o.append(T(533, 112, 'OGNI ANELLO', 16, True, RUST, 'middle'))
    for i, (t, s) in enumerate([('Carico scorretto', 'SF, BM, masse per stiva'), ('Urti allo scarico', 'benne, martelli, ruspe'), ('Rivestimenti rotti', 'acciaio esposto')]):
        y = 134 + i * 78
        o.append(R(442, y, 182, 66, '#fff', LINE, 1.5, 8))
        o.append(T(454, y + 26, t, 15, True, INK, maxw=164)); o.append(T(454, y + 48, s, 13, False, GRAY, maxw=164))
    o.append(callout(392, 'IACS Rec. 46: corrosione e cricche, principali cause delle perdite', 'y', h=48, size=15))
    return ''.join(o)
add(EC, 'Corrosione, fatica, carico',
    ['Perdite anni \'90: navi **oltre 15 anni**, carichi **pesanti**',
     'Cause principali: **corrosione e cricche** in stiva',
     'Concause: **carico scorretto** e **danni allo scarico**',
     'U.D. 2.2.2: i **metodi per evitarli**'],
    'come corrosione, fatica e carico si sommano', c1(),
    "Min 09:20. Inizia il blocco della U.D. 2.2.2: metodi per evitare gli effetti nocivi di corrosione, fatica e inadeguata movimentazione del carico sulle portarinfuse (competenza della tabella STCW A-II/2 richiamata dal programma D.D. 201/2024). Punto di partenza: IACS Rec. 46 Rev.2 (gennaio 2020), paragrafo 1.1. Dopo le perdite di portarinfuse a scafo singolo dei primi anni '90, le indagini IACS hanno mostrato che la maggior parte delle navi perse aveva più di 15 anni e trasportava carichi ad alta densità (minerale di ferro, prodotti siderurgici); i fattori principali erano la corrosione e le cricche della struttura nelle stive, con il contributo di sovrasollecitazioni da carico errato e di danni fisici al fianco durante lo scarico. Le contromisure IACS elencate nella stessa raccomandazione (paragrafo 1.2): dal 1991 rivestimenti obbligatori nelle cisterne di zavorra delle navi nuove; dal 1993 rivestimenti di fianco e paratie nelle stive (oggi UR Z9) e programma ESP; dal 1997 strumento di carico obbligatorio sulle navi esistenti di 150 m e oltre. La figura è la scaletta dell'ora: corrosione, fatica, poi carico e cosa fa il bordo.")

# ---------------- C2 tipi di corrosione ----------------
def c2():
    o = [head('Quattro forme di corrosione (UR Z10.2)')]
    pw, ph = 290, 150
    cells = [(28, 60, 'Generale', 'spessore ridotto in modo uniforme'), (348, 60, 'Pitting', 'crateri sparsi, più profondi della media'),
             (28, 250, 'Edge (bordi liberi)', 'flange, aperture, bordi di lamiere'), (348, 250, 'Grooving (solchi)', 'lungo le saldature, ai giunti')]
    for x, y, t, s in cells:
        o.append(R(x, y, pw, ph + 30, '#fff', LINE, 1.5, 9))
        o.append(T(x + 12, y + 24, t, 16, True, INK)); o.append(T(x + 12, y + 44, s, 13, False, GRAY, maxw=pw - 24))
    # generale: lamiera originale tratteggiata e lamiera assottigliata
    x, y = 48, 120
    o.append(R(x, y, 250, 40, 'none', STEEL, 1.5, 0, dash='6 4'))
    o.append(R(x, y + 14, 250, 26, '#C9D6DE', HULL, 2, 0))
    o.append(T(x + 125, y + 66, 'come costruita (tratteggio) e oggi', 13, False, GRAY, 'middle'))
    # pitting
    x, y = 368, 120
    pts = [(x, y + 6)]
    for i in range(10):
        cx = x + 14 + i * 24
        d = [10, 4, 16, 6, 12, 3, 18, 5, 9, 4][i]
        pts += [(cx - 6, y + 6), (cx - 2, y + 6 + d), (cx + 2, y + 6 + d), (cx + 6, y + 6)]
    pts += [(x + 250, y + 6), (x + 250, y + 40), (x, y + 40)]
    o.append(P(pts, '#C9D6DE', HULL, 2))
    o.append(T(x + 125, y + 66, 'intensità = % di area con crateri', 13, False, GRAY, 'middle'))
    # edge: profilo a T con flangia corrosa ai bordi
    x, y = 70, 300
    o.append(R(x + 95, y + 28, 12, 86, '#C9D6DE', HULL, 2, 0))
    o.append(P([(x + 20, y + 30), (x + 40, y + 18), (x + 162, y + 18), (x + 182, y + 30), (x + 182, y + 36), (x + 20, y + 36)], '#C9D6DE', HULL, 2))
    o.append(C(x + 30, y + 27, 12, 'none', RUST, 2.5)); o.append(C(x + 172, y + 27, 12, 'none', RUST, 2.5))
    o.append(T(x + 230, y + 70, 'bordi', 13, True, RUST))
    o.append(T(x + 230, y + 88, 'assottigliati', 13, True, RUST))
    # grooving: lamiera con rinforzo saldato e solco al piede
    x, y = 368, 330
    o.append(R(x, y + 46, 250, 22, '#C9D6DE', HULL, 2, 0))
    o.append(R(x + 118, y - 6, 12, 52, '#C9D6DE', HULL, 2, 0))
    o.append(P([(x + 104, y + 46), (x + 118, y + 32), (x + 118, y + 46)], STEEL, INK, 1.5))
    o.append(P([(x + 130, y + 46), (x + 130, y + 32), (x + 144, y + 46)], STEEL, INK, 1.5))
    o.append(P([(x + 146, y + 46), (x + 152, y + 56), (x + 162, y + 56), (x + 168, y + 46)], CREAM, RUST, 2.5))
    o.append(P([(x + 80, y + 46), (x + 86, y + 56), (x + 96, y + 56), (x + 102, y + 46)], CREAM, RUST, 2.5))
    o.append(T(x + 125, y + 90, 'solchi al piede delle saldature', 13, True, RUST, 'middle'))
    return ''.join(o)
add(EC, 'I tipi di corrosione',
    ['**Generale**: la lamiera si assottiglia in modo uniforme',
     '**Pitting**: crateri sparsi, più profondi della media',
     '**Edge** ai bordi liberi, **grooving** lungo le saldature',
     'Ogni forma ha i suoi **criteri di accettazione**'],
    'le quattro forme di corrosione definite da IACS', c2(),
    "Definizioni di IACS UR Z10.2 Rev.37 (febbraio 2023), paragrafi 1.2.17–1.2.19. Pitting: punti o aree di corrosione sparse con perdite locali maggiori della corrosione generale circostante; l'intensità del pitting è la percentuale di superficie interessata (figura 1 della UR). Edge corrosion: corrosione locale ai bordi liberi di lamiere, rinforzi, elementi primari e intorno alle aperture. Grooving: perdita locale di materiale vicino alle saldature, lungo i rinforzi saldati e ai giunti di testa o di lato delle lamiere. Criteri per le navi CSR (UR Z10.2, paragrafi 8.2–8.4): nelle strutture del fianco, se il pitting supera il 15 % si misurano i cinque crateri più profondi su un'area pulita di almeno 300 mm, e lo spessore residuo deve essere almeno il 75 % di quello di costruzione nelle anime e flange di ossature e braccioli e il 70 % nel fasciame attaccato a ciascuna ossatura (fianco, tramoggia, cisterna alta), senza superare lo spessore di rinnovo. Nelle altre strutture, con pitting sotto il 20 %, ogni misura deve rispettare il minore tra 0,7 (t costruzione − t aggiunta volontaria) e t rinnovo − 1 mm; per l'edge corrosion vale lo stesso criterio; per il grooving il minore tra 0,75 (t costruzione − t aggiunta volontaria) e t rinnovo − 0,5 mm. Messaggio per il bordo: la corrosione locale è insidiosa perché la media dello spessore può sembrare buona mentre un solco al piede di una saldatura riduce la sezione resistente proprio dove la tensione è più alta.")

# ---------------- C3 dove si corrode ----------------
def c3():
    items = [('Paratia: base (stool)', 5.2, RUST, '5,2'), ('Tramoggia e doppio fondo', 3.7, RUST, '3,7'),
             ('Paratia: altre parti', 3.0, RUST, '3,0'), ('Bracciolo inf. ossatura', 2.2, YEL, '2,2'),
             ('Zavorra, 3 m sotto il cielo', 1.7, BLUE, '1,7'), ('Ponte esposto', 1.7, STEEL, '1,7'),
             ('Zavorra, altrove', 1.2, BLUE, '1,2')]
    o = [hbars('Margine di corrosione per lato t c1 (mm)', items, y0=62, maxv=5.2, vw=270, bh=30, gap=17, lw=232, size=15)]
    o.append(T(28, 410, 'CSR, Pt 1 Ch 3 Sec 3, Table 1 · portarinfuse BC-A o BC-B di 150 m e oltre', 13, False, GRAY, maxw=610))
    o.append(T(28, 432, 'stiva in rosso e giallo, zavorra in blu', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(EC, 'Dove si corrode una portarinfuse',
    ['Stiva: **parte bassa**, **tramoggia**, **doppio fondo**',
     '**Base delle paratie**: residui, umidità, urti',
     'Zavorra: **sotto il ponte** nelle cisterne alte',
     'Le CSR danno **più margine** dove il rischio è maggiore'],
    'margini di corrosione delle CSR per zona', c3(),
    "I margini di corrosione delle CSR (edizione 1 luglio 2025, Pt 1 Ch 3 Sec 3, Table 1) sono una mappa ufficiale di dove una portarinfuse si corrode di più. Valori per lato (t c1) per navi con notazione BC-A o BC-B e lunghezza al bordo libero di 150 m e oltre: base della paratia trasversale (lamiere inclinata, verticale e superiore dello stool) 5,2 mm; lamiera inclinata della tramoggia e cielo del doppio fondo, lato stiva, 3,7 mm; altre parti della paratia 3,0 mm; anime e flange dei braccioli inferiori delle ossature di stiva 2,2 mm; cisterne di zavorra, elementi entro 3 m sotto il cielo 1,7 mm, altrove 1,2 mm; ponte esposto 1,7 mm. Per le altre portarinfuse i valori in stiva sono circa la metà (per esempio stool 2,6 mm, tramoggia e doppio fondo 2,4 mm). Il margine totale di un elemento è t c = arrotondamento al mezzo millimetro superiore di (t c1 + t c2) più una riserva di 0,5 mm, dove t c1 e t c2 sono i valori dei due lati. Esempio: lamiera della tramoggia, lato stiva 3,7 mm e lato zavorra 1,2 mm: 4,9 arrotondato a 5,0, più 0,5 = 5,5 mm. Perché la base delle paratie: si accumulano residui del carico e acqua di lavaggio, è colpita da benne e ruspe ed è difficile da ispezionare. Perché la zona sotto il ponte delle cisterne di zavorra: aria umida e salina, cicli termici giorno-notte, e il rivestimento si degrada prima.")

# ---------------- C4 cause ----------------
def c4():
    return rows('Che cosa attacca l\'acciaio', [
        ('Carbone', 'zolfo e umidità creano un ambiente acido sulle lamiere', 'r'),
        ('Zolfo, sale', 'con l\'acqua diventano fortemente corrosivi', 'r'),
        ('Residui', 'restano sul cielo e alla base delle ossature', 'y'),
        ('Condensa', 'il "sudore" di stiva con forti escursioni termiche', 'b'),
        ('Calore', 'cisterne di combustibile riscaldate vicino alla stiva', 'y'),
        ('Zavorra', 'acqua di mare, aria umida, bagnato e asciutto', 'b')], y0=62, lw=130, size=15)
add(EC, 'Le cause: carico, acqua, calore',
    ['**Carichi corrosivi**: carbone, zolfo, sale, carichi umidi',
     '**Condensa** e ventilazione insufficiente in stiva',
     '**Calore** da cisterne di combustibile riscaldate',
     'Zavorra: **acqua di mare**, aria umida, cicli termici'],
    'le cause più comuni di corrosione a bordo', c4(),
    "IACS Rec. 46 Rev.2, paragrafo 5.9: i rivestimenti delle stive si degradano per la natura corrosiva del carico, i carichi ad alta temperatura, l'assestamento del carico durante il viaggio e l'azione abrasiva; dove il rivestimento manca o è rotto la velocità di corrosione aumenta molto, specialmente con carichi corrosivi come il carbone. Il carbone contiene zolfo che con l'umidità forma acidi; lo zolfo alla rinfusa e i residui salini sono aggressivi in presenza di acqua (vedere le schede del Codice IMSBC del carico specifico per le precauzioni su pulizia e umidità). La condensa (sweat) si forma quando aria calda e umida incontra lamiere fredde: ventilazione corretta secondo il punto di rugiada, quando il carico lo permette. Le cisterne di combustibile riscaldate adiacenti alla stiva o alle cisterne di zavorra aumentano la temperatura e quindi la velocità di corrosione. Nelle cisterne di zavorra il nemico è l'alternanza bagnato-asciutto e la zona alta, dove l'aria è umida e salina. Collegamento con la slide precedente: le zone a margine più alto delle CSR sono quelle in cui queste cause agiscono insieme. Le osservazioni su carbone e zolfo sono indicazioni generali: per ogni carico fanno fede la scheda IMSBC e le istruzioni dell'armatore.")

# ---------------- C5 difese ----------------
def c5():
    o = [head('Le difese: rivestimenti e anodi')]
    x, y, w, h = 70, 92, 300, 300
    ds = h * 0.14; top_h = h * 0.30; top_w = w * 0.20; hop_h = h * 0.28; hop_w = w * 0.18
    xr, yb = x + w, y + h
    o.append(R(x, y, w, h, '#FFFFFF', INK, 3, 4))
    # zavorra (PSPC) in azzurro
    o.append(R(x, yb - ds, w, ds, '#BFDCEB', INK, 2, 0))
    o.append(P([(x, yb - ds - hop_h), (x + hop_w, yb - ds), (x, yb - ds)], '#BFDCEB', INK, 2))
    o.append(P([(xr, yb - ds - hop_h), (xr - hop_w, yb - ds), (xr, yb - ds)], '#BFDCEB', INK, 2))
    o.append(P([(x, y + 8), (x + top_w, y + 8), (x, y + 8 + top_h)], '#BFDCEB', INK, 2))
    o.append(P([(xr, y + 8), (xr - top_w, y + 8), (xr, y + 8 + top_h)], '#BFDCEB', INK, 2))
    o.append(R(x, y, w, 8, INK, INK, 0, 0))
    # rivestimento di stiva UR Z9: pareti, fino a circa 300 mm sotto i braccioli inferiori
    g = GREEN
    o.append(L(x + 5, y + 8 + top_h + 2, x + 5, yb - ds - hop_h - 2, g, 6))
    o.append(L(xr - 5, y + 8 + top_h + 2, xr - 5, yb - ds - hop_h - 2, g, 6))
    o.append(L(x + top_w + 4, y + 13, x + 6, y + 8 + top_h - 2, g, 6))
    o.append(L(xr - top_w - 4, y + 13, xr - 6, y + 8 + top_h - 2, g, 6))
    o.append(L(x + 6, yb - ds - hop_h + 4, x + 6 + hop_w * 0.25, yb - ds - hop_h * 0.75, g, 6))
    o.append(L(xr - 6, yb - ds - hop_h + 4, xr - 6 - hop_w * 0.25, yb - ds - hop_h * 0.75, g, 6))
    # mastre
    o.append(R(x + top_w, y - 22, 6, 22, g, None, 0, 0)); o.append(R(xr - top_w - 6, y - 22, 6, 22, g, None, 0, 0))
    o.append(R(x + top_w - 4, y - 28, w - 2 * top_w + 8, 7, g, INK, 1.5, 2))
    # zona non obbligatoria
    o.append(L(x + hop_w * 0.3, yb - ds - hop_h * 0.68, x + hop_w, yb - ds - 3, STEEL, 5, '6 5'))
    o.append(L(x + hop_w, yb - ds - 3, xr - hop_w, yb - ds - 3, STEEL, 5, '6 5'))
    o.append(L(xr - hop_w * 0.3, yb - ds - hop_h * 0.68, xr - hop_w, yb - ds - 3, STEEL, 5, '6 5'))
    # anodi
    for ax, ay in [(x + 30, yb - 20), (xr - 40, yb - 20), (x + 14, y + 40)]:
        o.append(R(ax, ay, 18, 8, ORANGE, RUST, 1.5, 2))
    lg = [(GREEN, 'stiva e mastre: rivestimento UR Z9', 'L'), ('#BFDCEB', 'zavorra: rivestimento PSPC', 'R'),
          (STEEL, 'cielo e tramoggia bassa: non obbligatorio', 'D'), (ORANGE, 'anodi sacrificali, dove previsti', 'R')]
    for i, (c, t, k) in enumerate(lg):
        yy = 74 + i * 52
        if k == 'L':
            o.append(L(398, yy, 426, yy, c, 6))
        elif k == 'D':
            o.append(L(398, yy, 426, yy, c, 5, '6 5'))
        else:
            o.append(R(398, yy - 9, 28, 18, c, INK, 1.5, 3))
        o.append(TW(436, yy + 5, t, 14, 200, bold=True))
    o.append(T(398, 300, 'Stato del rivestimento (ESP):', 14, True, INK))
    o.append(T(398, 322, 'GOOD · FAIR · POOR', 15, True, RUST))
    o.append(T(398, 344, 'vedi seconda parte', 13, False, GRAY))
    return ''.join(o)
add(EC, 'Difese contro la corrosione',
    ['**Rivestimento** epossidico in stiva (IACS **UR Z9**)',
     'Zavorra: **PSPC** (MSC.215(82)), vita utile **15 anni**',
     '**Anodi** sacrificali in zavorra, dove previsti',
     'Il rivestimento va **mantenuto**, non solo applicato'],
    'dove sono obbligatori i rivestimenti in una sezione di stiva', c5(),
    "IACS UR Z9 Rev.2 (1996), navi per cui la classe è richiesta dal 1° luglio 1998: in costruzione tutte le superfici interne ed esterne di mastre e coperchi delle stive e tutte le superfici interne delle stive, esclusi il cielo del doppio fondo e la lamiera inclinata delle tramogge fino a circa 300 mm sotto i braccioli delle ossature, hanno un rivestimento protettivo efficiente (epossidico o equivalente) applicato secondo il fabbricante; nella scelta l'armatore tiene conto dei carichi previsti. Le zone escluse sono quelle più colpite da benne e ruspe: lì il rivestimento durerebbe poco, e infatti le CSR danno margini di corrosione maggiori (slide precedente). Cisterne di zavorra: SOLAS II-1/3-2 rende obbligatorio il Performance Standard for Protective Coatings (risoluzione MSC.215(82)) per le cisterne di zavorra delle navi di 500 GT e oltre e per gli spazi a doppio fianco delle portarinfuse di 150 m e oltre (date di applicazione nel Ripasso), con vita utile di riferimento del rivestimento di 15 anni in condizione GOOD. Gli anodi sacrificali di zinco o alluminio integrano il rivestimento nelle cisterne che restano piene a lungo. Le CSR, nella verifica a fatica, assumono che il rivestimento delle cisterne di zavorra protegga per una parte della vita di progetto e che poi la struttura lavori in ambiente corrosivo (Pt 1 Ch 9 Sec 3, Table 5): il rivestimento conta anche per la fatica. Lo stato del rivestimento (GOOD, FAIR, POOR) è definito dalla UR Z10.2, paragrafo 1.2.13, e decide l'estensione delle visite ESP: lo vediamo nella seconda parte.")

# ---------------- C7 fatica ----------------
def c7():
    o = [head('Curva S-N: escursione di tensione e cicli')]
    X0, Y0, PW, PH = 92, 70, 520, 300
    nmin, nmax, smin, smax = 4, 9, math.log10(20), math.log10(400)
    def px(n): return X0 + (math.log10(n) - nmin) / (nmax - nmin) * PW
    def py(s): return Y0 + PH - (math.log10(s) - smin) / (smax - smin) * PH
    o.append(R(X0, Y0, PW, PH, '#FBFAF6', LINE, 1.5, 0))
    for e in range(4, 10):
        o.append(L(px(10 ** e), Y0, px(10 ** e), Y0 + PH, '#E3DDD2', 1))
        o.append(T(px(10 ** e), Y0 + PH + 22, f'10^{e}', 13, False, GRAY, 'middle'))
    for s in (20, 50, 100, 200, 400):
        o.append(L(X0, py(s), X0 + PW, py(s), '#E3DDD2', 1))
        o.append(T(X0 - 8, py(s) + 5, str(s), 13, False, GRAY, 'end'))
    o.append(T(X0 + PW / 2, Y0 + PH + 44, 'numero di cicli N (scala logaritmica)', 14, True, INK, 'middle'))
    o.append(T(30, Y0 - 12, 'Δσ (N/mm²)', 14, True, INK))
    def dair(n):
        return (1.52e12 / n) ** (1 / 3) if n <= 1e7 else 53.4 * (1e7 / n) ** (1 / 5)
    def dcor(n):
        return (7.60e11 / n) ** (1 / 3)
    for f, c, dash in [(dair, BLUE, None), (dcor, RUST, '8 5')]:
        pts = []
        for i in range(0, 101):
            n = 10 ** (nmin + (nmax - nmin) * i / 100)
            s = f(n)
            if 20 <= s <= 400:
                pts.append((px(n), py(s)))
        o.append(P(pts, 'none', c, 3.5, False, dash))
    nd = 7.1e7
    o.append(L(px(nd), Y0, px(nd), Y0 + PH, INK, 2, '4 4'))
    o.append(T(px(nd) - 6, Y0 + 20, 'vita di progetto', 13, True, INK, 'end'))
    o.append(T(px(nd) - 6, Y0 + 38, '≈ 7·10^7 onde', 13, True, INK, 'end'))
    o.append(L(110, 392 + 46, 140, 392 + 46, BLUE, 3.5)); o.append(T(146, 443, 'curva D in aria', 14, True, BLUE))
    o.append(L(320, 438, 350, 438, RUST, 3.5, '8 5')); o.append(T(356, 443, 'curva D in acqua di mare', 14, True, RUST))
    return ''.join(o)
add(EC, 'La fatica: cicli che si sommano',
    ['Ogni onda è un **ciclo di tensione**: decine di milioni',
     'Conta l\'**escursione** Δσ, non solo il valore massimo',
     'Le cricche nascono dove la tensione si **concentra**',
     'Acciaio **alta resistenza**: stessa curva, **più tensione**'],
    'curve S-N di progetto delle CSR per giunti saldati', c7(),
    "Fatica: cedimento per accumulo di cicli di tensione inferiori al carico di snervamento. Le CSR (edizione 1 luglio 2025, Pt 1 Ch 9) verificano i dettagli della zona del carico per una vita di progetto a fatica di almeno 25 anni in Nord Atlantico, per navi di lunghezza al bordo libero tra 150 e 500 m. Il numero di cicli d'onda in vita è N D = 31,557·10^6 · f0 · T D / (4 log L) con f0 = 0,85: per una nave di 225 m e 25 anni circa 7·10^7 cicli. La curva S-N di progetto D (giunti saldati, CSR Pt 1 Ch 9 Sec 3, Table 2) ha pendenza inversa m = 3 fino a 10^7 cicli e 5 oltre; a 2·10^6 cicli l'escursione ammessa è 91,3 N/mm². In ambiente corrosivo (Table 3) la curva D corr ha m = 3 senza cambio di pendenza e a 2·10^6 cicli ammette solo 72,4 N/mm²: in acqua di mare non c'è un livello sotto il quale i cicli non contano. Con m = 3 la vita è inversamente proporzionale al cubo dell'escursione: piccoli aumenti di tensione costano molta vita. Acciaio ad alta resistenza: le CSR usano le stesse curve S-N per tutti gli acciai fino a 390 N/mm² di snervamento (Ch 9 Sec 1, [1.1.5]); le strutture in AH sono più sottili e lavorano a tensioni più alte (fattore k, U.D. 2.2.1), quindi a fatica sono più critiche. Le curve della figura sono tracciate con i dati CSR; la scala è logaritmica su entrambi gli assi.")

# ---------------- C8 dove nascono le cricche ----------------
def c8():
    o = [head('Punti caldi di una sezione di stiva')]
    x, y, w, h = 60, 100, 300, 300
    ds = h * 0.14; top_h = h * 0.30; top_w = w * 0.20; hop_h = h * 0.28; hop_w = w * 0.18
    xr, yb = x + w, y + h
    o.append(bc_section(x, y, w, h, cargo=None, hatch=True))
    xf = x + 22
    o.append(L(xf, y + 8 + top_h - 10, xf, yb - ds - hop_h + 10, RUST, 5))
    o.append(P([(xf, y + 8 + top_h - 10), (xf, y + 8 + top_h + 26), (x + 2, y + 8 + top_h + 26)], '#F3D9C7', RUST, 2))
    o.append(P([(xf, yb - ds - hop_h + 10), (xf, yb - ds - hop_h - 26), (x + 2, yb - ds - hop_h - 26)], '#F3D9C7', RUST, 2))
    spots = [(1, x + hop_w, yb - ds, 'Spigolo tramoggia–doppio fondo'),
             (2, xf + 4, y + 8 + top_h + 8, 'Piede del bracciolo superiore'),
             (3, xf + 4, yb - ds - hop_h - 8, 'Bracciolo inferiore dell\'ossatura'),
             (4, x + top_w, y - 16, 'Fine mastra e angolo boccaporto'),
             (5, x + w / 2, yb - ds, 'Base paratia sul doppio fondo')]
    for n, sx, sy, t in spots:
        o.append(C(sx, sy, 13, RUST, '#fff', 2)); o.append(T(sx, sy + 5, str(n), 13, True, '#fff', 'middle'))
        yy = 86 + (n - 1) * 58
        o.append(C(400, yy - 5, 13, RUST, '#fff', 2)); o.append(T(400, yy, str(n), 13, True, '#fff', 'middle'))
        o.append(TW(422, yy, t, 15, 220, bold=True))
    o.append(T(400, 400, 'Le cricche partono dal piede', 14, False, GRAY))
    o.append(T(400, 420, 'della saldatura o da un bordo libero', 14, False, GRAY))
    return ''.join(o)
add(EC, 'Dove nascono le cricche',
    ['**Spigolo della tramoggia** con il doppio fondo',
     '**Piede dei braccioli** di ossature e longitudinali',
     '**Angoli dei boccaporti** e fine delle mastre',
     '**Base delle paratie** corrugate (stool)'],
    'punti caldi a fatica di una portarinfuse (CSR)', c8(),
    "Punti caldi (hot spots): punti in cui una cricca di fatica può nascere per l'effetto combinato della variazione di tensione nominale e della concentrazione dovuta alla geometria della saldatura o a un intaglio nel materiale; si trovano al piede della saldatura, alla radice di saldature a cordone o a parziale penetrazione, o al bordo libero di una lamiera (CSR Pt 1 Ch 9 Sec 1, [2.1]). I dettagli critici che le CSR chiedono di verificare con analisi a maglia molto fine sulle portarinfuse (Ch 9 Sec 2, Table 1): giunzione inferiore della tramoggia con doppio fondo, paramezzale, madiere e anello (1, saldata o raccordata); giunzione superiore della tramoggia nelle navi a doppio fianco; collegamento della base delle paratie trasversali con il cielo del doppio fondo in corrispondenza dei paramezzali (5); piede del bracciolo superiore delle ossature nelle navi a scafo singolo con fondo piatto della cisterna alta (2); piede del bracciolo di estremità delle mastre longitudinali sul ponte (4), con l'angolo raccordato del boccaporto tra i punti caldi (Table 18). Il bracciolo inferiore delle ossature (3) è il punto in cui corrosione, urti allo scarico e concentrazione di tensione si sommano (Rec. 46, paragrafo 5.9). Nelle cisterne di zavorra le cricche tipiche sono alle estremità dei longitudinali dove attraversano gli anelli rinforzati. A bordo: una striscia di ruggine su un rivestimento integro, a partire da un bracciolo o da una saldatura, va guardata da vicino: spesso è una cricca.")

# ---------------- C9 corrosione + fatica ----------------
def c9():
    items = []
    for loss in (0, 5, 10, 15, 20, 25):
        life = (1 - loss / 100) ** 3 * 100
        col = GREEN if loss == 0 else (YEL if loss <= 10 else RUST)
        items.append((f'spessore −{loss} %', life, col, f'{life:.0f} %'))
    o = [hbars('Vita a fatica residua se lo spessore cala', items, y0=62, maxv=100, vw=300, bh=32, gap=18, lw=170, size=15)]
    o.append(callout(370, 'Stessa forza, meno acciaio: tensione ↑ e vita ∝ (t / t0)³', 'y', h=44, size=15))
    o.append(T(28, 440, 'esempio didattico: tensione membranale inversamente proporzionale allo spessore, m = 3', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(EC, 'Corrosione e fatica insieme',
    ['Meno spessore → **più tensione** → **meno vita**',
     'Con m = 3: tensione **+10 %** → vita **−25 %**',
     'In acqua di mare la curva S-N **scende** (CSR)',
     'Il rivestimento **protegge anche dalla fatica**'],
    'quanto costa la corrosione in vita a fatica', c9(),
    "Ragionamento: se la forza trasmessa da un elemento resta la stessa e lo spessore cala, la tensione membranale cresce come t0/t; con la pendenza m = 3 della curva S-N la vita a fatica cala come (t/t0)^3. Numeri della figura: −5 % di spessore → 86 % della vita; −10 % → 73 %; −15 % → 61 %; −20 % → 51 %; −25 % → 42 %. Allo stesso modo, una tensione più alta del 10 % riduce la vita a 1/1,1^3 = 0,75, cioè del 25 %. Due effetti si sommano: lo spessore che cala e l'ambiente corrosivo, che abbassa la curva S-N (D in aria 91,3 contro D corr 72,4 N/mm² a 2·10^6 cicli, CSR Pt 1 Ch 9 Sec 3, Tables 2 e 3). Per questo le CSR calcolano la fatica considerando un periodo protetto dal rivestimento e un periodo in ambiente corrosivo (Ch 9 Sec 3, Table 5) e usano uno spessore netto con metà del margine di corrosione. È un esempio didattico semplificato: nella realtà la ripartizione degli sforzi cambia quando una struttura si assottiglia. Collegamento con la seconda parte: lo stesso ragionamento vale per la tensione di taglio nel fianco (slide 44).")

# ---------------- C10 movimentazione del carico ----------------
def c10():
    o = [head('Rec. 46: 5,4 minuti di troppo')]
    bars = [('SF prima', 97, BLUE, '97 %'), ('SF dopo', 117, RUST, '117 %'), ('BM prima', 99, BLUE, '99 %'), ('BM dopo', 133, RUST, '133 %')]
    for i, (lab, v, c, vt) in enumerate(bars):
        yy = 66 + i * 40
        o.append(T(28, yy + 21, lab, 15, True, INK))
        o.append(R(130, yy + 4, 330 * v / 133, 26, c, None, 0, 5)); o.append(T(136 + 330 * v / 133, yy + 23, vt, 15, True, c))
    xl = 130 + 330 * 100 / 133
    o.append(L(xl, 62, xl, 232, INK, 2, '5 4')); o.append(T(xl + 4, 248, 'limite 100 %', 13, True, INK))
    o.append(T(28, 272, '900 t in più nelle stive 1 e 7 · 10 000 t/h', 13, False, GRAY, maxw=610))
    o.append(T(28, 312, 'Nota GRAB [X]: massa minima della benna (CSR dal 1/7/2015)', 15, True, INK, maxw=610))
    for i, (t, s) in enumerate([('35 t', 'L > 250 m'), ('30 t', '200–250 m'), ('20 t', 'navi più piccole')]):
        x = 28 + i * 206
        o.append(tile(x, 326, 196, 76, t, s, 'r', 20, 14))
    o.append(T(28, 432, 'obbligatoria per BC-A e BC-B', 13, False, GRAY))
    return ''.join(o)
add(EC, 'Movimentazione del carico',
    ['**Velocità di carico** alte: sovraccarico in **minuti**',
     'Zavorra **sincronizzata** con il carico',
     '**Benne**, martelli e ruspe: urti, rivestimenti rotti',
     'Nota di classe **GRAB [X]**: peso della benna'],
    'esempio IACS di sovraccarico e masse di benna di progetto', c10(),
    "IACS Rec. 46 Rev.2, paragrafo 5.3 e Table 1: con due caricatori a 10 000 t/h, 900 t in più nelle stive 1 e 7 (il 10 % del carico della stiva 5 distribuito male) si caricano in 5,4 minuti e portano sforzo di taglio e momento flettente in acqua tranquilla dal 97 e 99 % al 117 e 133 % dei valori ammessi. Il responsabile del carico deve essere pronto a fermare le operazioni se si scostano dal piano concordato; la zavorra deve tenere il passo (se le pompe sono più lente del caricatore, si ferma il carico). Paragrafo 5.8: verificare il peso in ogni stiva, con pescaggi e calcoli se la bilancia di terminale non è affidabile; non caricare una stiva oltre il limite per compensare bunker parziali. Paragrafo 5.9: benne, martelli idraulici e ruspe danneggiano cielo del doppio fondo, tramoggia, ossature e braccioli; l'ammaccatura o il distacco delle ossature alla base può innescare cricche nel fasciame del fianco e allagamento della stiva; gli urti sul cielo o sulla tramoggia rompono anche il rivestimento delle cisterne di zavorra adiacenti, dal lato opposto. Le navi BC-A e BC-B hanno la notazione GRAB [X] con la massa della benna vuota: per le navi CSR con contratto dal 1° luglio 2015 almeno 35 t oltre 250 m, 30 t tra 200 e 250 m, 20 t per le navi più piccole (prima: 20 t per BC-A e BC-B). Conoscere la notazione serve per contestare al terminale benne più pesanti.")

# ---------------- C11 cosa fa il bordo ----------------
def c11():
    o = [head('Metodi a bordo per evitare i danni')]
    items = [('Ispezione di stive e ponte dopo ogni scarico', 'Rec. 46'),
             ('Pulizia dei residui, acqua dolce dopo carichi corrosivi', None),
             ('Ventilazione contro la condensa', None),
             ('Ritocchi del rivestimento, registrati', 'PMS'),
             ('Zavorra: ispezioni, anodi, fango', 'ESP'),
             ('Carico: piano, strumento, peso per stiva', 'XII/11'),
             ('Danni e urti segnalati alla classe', 'ISM 9')]
    for i, (t, tag) in enumerate(items):
        o.append(checkrow(28, 58 + i * 55, 610, t, tag, h=46, size=15))
    return ''.join(o)
add(EC, 'Che cosa fa il bordo',
    ['**Ispezione** di stive e ponte **dopo ogni scarico**',
     '**Pulizia** dei residui e **ritocchi** del rivestimento',
     'Piano di carico rispettato: **STOP** se si devia',
     'Danni alla **classe**, registrati nel **SMS**'],
    'lista di controllo per ufficiali di coperta', c11(),
    "Sintesi operativa dei metodi per evitare gli effetti nocivi. Rec. 46 Rev.2, paragrafo 5.9: al termine dello scarico gli ufficiali di coperta ispezionano stive e ponte per individuare danni fisici, corrosione o rivestimenti danneggiati; i danni che possono compromettere l'integrità dello scafo vanno segnalati alla società di classifica. Pulizia: rimuovere i residui (soprattutto alla base di ossature e paratie) e lavare con acqua dolce dopo carichi corrosivi come carbone o zolfo, compatibilmente con le norme sullo scarico delle acque di lavaggio (MARPOL Annesso V). Ventilazione secondo le regole del punto di rugiada. Ritocchi: i piccoli danni al rivestimento vanno ripresi presto, prima che la ruggine si estenda sotto il film, e registrati nel sistema di manutenzione programmata (IACS Rec. 74 Rev.2, 2018, guida alla gestione della manutenzione). Cisterne di zavorra: ispezioni periodiche dell'armatore, controllo degli anodi, rimozione del fango che trattiene acqua. Carico: piano concordato con il terminale, strumento di carico (SOLAS XII/11), controllo del peso per stiva, fermare le operazioni in caso di scostamenti. Danni e non conformità: Codice ISM, sezione 9 (rapporti) e sezione 10 (manutenzione della nave): ciò che si trova durante le ispezioni di bordo entra nel sistema di gestione della sicurezza e, se strutturale, va alla classe. Nelle visite ESP l'ispettore chiede proprio queste registrazioni (seconda parte).")

# ---------------- C12 sintesi ----------------
def c12():
    o = [head('Sintesi e tre domande per la pausa')]
    sm = [('Struttura', 'nomi e funzioni degli elementi', 'b'), ('Corrosione', 'tipi, zone, margini, difese', 'r'),
          ('Fatica', 'cicli, punti caldi, curva S-N', 'r'), ('Carico', 'piano, velocità, benne', 'y')]
    bw = (610 - 14) / 2
    for i, (t, s, k) in enumerate(sm):
        o.append(tile(28 + (i % 2) * (bw + 14), 62 + (i // 2) * 82, bw, 70, t, s, k, 16, 14))
    qs = ['Quale forma di corrosione si trova lungo le saldature?',
          'Dove nasce di solito una cricca di fatica?',
          'Che cosa significa "corrosione sostanziale"?']
    for i, q in enumerate(qs):
        y = 242 + i * 64
        o.append(R(28, y, 610, 54, SOFTY, YEL, 2, 9)); o.append(T(44, y + 34, f'{i + 1}', 20, True, '#7A5200'))
        o.append(T(72, y + 33, q, 16, True, INK, maxw=552))
    return ''.join(o)
add('PARTE 1 · SINTESI', 'Sintesi della prima parte',
    ['Struttura: **nomi e funzioni** degli elementi',
     'Corrosione: **tipi, zone, margini, difese**',
     'Fatica: **cicli e punti caldi**; la corrosione la accelera',
     'Carico: **piano, velocità, benne**'],
    'sintesi e domande di richiamo', c12(),
    "Chiudere la prima parte con i quattro temi e lasciare tre domande per la pausa; le risposte si danno alla ripresa (slide 23). Risposte attese: 1) il grooving, solco di corrosione lungo le saldature e ai giunti (UR Z10.2, 1.2.19); 2) in un punto caldo: piede di una saldatura, radice di un cordone o bordo libero, in dettagli come lo spigolo tramoggia–doppio fondo, il piede dei braccioli, l'angolo del boccaporto; 3) per le navi CSR, spessore misurato tra lo spessore di rinnovo e il rinnovo più 0,5 mm; per le altre navi, corrosione oltre il 75 % del margine ammesso ma entro i limiti (UR Z10.2, 1.2.11). Le slide su ponte, paratie, prora e poppa, elementi trasversali e longitudinali, acciai, esercizio di riconoscimento, glossario e sezione maestra sono in appendice dopo la sintesi finale, per consultazione o per domande.")
