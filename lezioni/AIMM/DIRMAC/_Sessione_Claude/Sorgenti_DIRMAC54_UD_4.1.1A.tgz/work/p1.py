from lib import *
from plots import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes))

E1 = 'PARTE 1 · INTRODUZIONE'
E2 = 'PARTE 1 · TERMINOLOGIA'
E3 = 'PARTE 1 · ELEMENTI STRUTTURALI'
E4 = 'PARTE 1 · TRASVERSALI E LONGITUDINALI'
E5 = 'PARTE 1 · MATERIALI E SPESSORI'
EX = 'PARTE 1 · ESERCIZIO'

def legend(x, y, items, size=15, gap=30):
    """items: (numero, testo, colore)"""
    o = []
    for i, (n, t, c) in enumerate(items):
        yy = y + i * gap
        o.append(C(x + 11, yy - 5, 11, c)); o.append(T(x + 11, yy, str(n), 13, True, '#fff', 'middle'))
        o.append(T(x + 30, yy, t, size, True, INK, maxw=170))
    return ''.join(o)

def num(x, y, n, c=RUST):
    return C(x, y, 11, c, '#fff', 2) + T(x, y + 5, str(n), 13, True, '#fff', 'middle')

def dots_on(x1, y1, x2, y2, step=16, off=(0, 0), r=3.2, c=BLUE):
    n = max(1, int(math.hypot(x2 - x1, y2 - y1) // step))
    o = []
    for i in range(1, n):
        t = i / n
        o.append(C(x1 + (x2 - x1) * t + off[0], y1 + (y2 - y1) * t + off[1], r, c))
    return ''.join(o)

def secgeo(x, y, w, h):
    deck_t = 8; ds = h * 0.14; top_h = h * 0.30; top_w = w * 0.20; hop_h = h * 0.28; hop_w = w * 0.18
    return dict(x=x, y=y, w=w, h=h, xr=x + w, yb=y + h, dt=deck_t, ds=ds, th=top_h, tw=top_w, hh=hop_h, hw=hop_w)

# ---------------- 2 Obiettivi ----------------
def d2():
    return programma_fonti(['08:30', '10:20', '10:40', '12:30'], [('2011 ESP Code (IMO)', 'A.1049(27), emend. fino a MSC.584(111)'), ('IACS UR Z10.2 · Z10.5', 'Rev.37 feb 2023 · Rev.20 feb 2023'), ('IACS UR Z9 · Rec. 46', 'Rev.2 1996 · Rev.2 gen 2020'), ('IACS UR S11', 'Rev.10 dic 2020'), ('IACS UR S4 · S12 · S31', 'Rev.4 2017 · Rev.5 2010 · Rev.4'), ('CSR BC & OT (IACS)', 'ed. 1 luglio 2025 · Pt 1 Ch 3, 9, 13'), ('SOLAS XI-1/2, XII, II-1/3-2', 'testo consolidato 2017 + emend. MSC'), ('Programma ed esami', 'D.D. 201/2024 · D.D. 76/2025')])
add(E1, 'Obiettivi e programma della giornata',
    ['Leggere la **struttura** con i termini corretti',
     'Evitare i danni da **corrosione e fatica** (U.D. 2.2.2)',
     'Conoscere il programma **ESP** e il ruolo di bordo',
     'Calcolare **τ e flusso di taglio** in una sezione'],
    'scansione oraria e fonti con la revisione usata', d2(),
    "Lezione di approfondimento su temi già toccati nelle U.D. 2.1.7 e 2.2.1 e nel Ripasso (struttura della nave, programma di ispezioni rafforzate ESP, sforzo di taglio), con un'ora dedicata alla U.D. 2.2.2 (corrosione e fatica), prevista in calendario per questa mattina. Orario: prima parte 08:30–10:20, intervallo 10:20–10:40, seconda parte 10:40–12:30. Prima parte: 08:35–09:20 struttura di base (terminologia, sistemi d'ossatura, fondo, fianco, cisterne); 09:20–10:20 U.D. 2.2.2, metodi per evitare i danni da corrosione, fatica e movimentazione del carico (slide 11–22). Le slide di struttura non svolte (ponte, paratie, prora e poppa, elementi trasversali e longitudinali, acciai, esercizio, glossario, sezione maestra) sono in appendice dopo la slide 45, senza tempi. Seconda parte: ESP (origine, ciclo di visite, definizioni, spessimetria, documenti, ruolo di bordo) e taglio (dal valore SF alla tensione τ, flusso di taglio, esercizio numerico, corrosione). Cinque minuti per slide, salvo diversa indicazione sul piede di pagina. Gli schemi sono disegni originali; i numeri degli esempi sono didattici salvo dove è citata la fonte. Fonti e revisioni usate, verificate il 29/10/2026 sulle edizioni pubblicate da IACS (copie in DIRCOP63/Fonti/IACS_vigenti_2026-10-29): 2011 ESP Code, risoluzione IMO A.1049(27) con gli emendamenti fino a MSC.584(111) (in vigore dal 1/1/2028) e linee guida MSC.1/Circ.1700; IACS UR Z10.2 Rev.37 (febbraio 2023) e UR Z10.5 Rev.20 (febbraio 2023); IACS UR Z9 Rev.2 (1996) e Rec. 46 Rev.2 (gennaio 2020) per corrosione e movimentazione del carico; IACS UR S11 Rev.10 (dicembre 2020); IACS UR S4 Rev.4 (aprile 2017), UR S12 Rev.5 (maggio 2010), UR S31 Rev.4; CSR BC & OT, edizione consolidata 1 luglio 2025 (Pt 1 Ch 3 Sec 3 margini di corrosione, Ch 9 fatica, Ch 13 spessori di rinnovo); SOLAS XI-1/2, XII e II-1/3-2 (PSPC, MSC.215(82)), testo consolidato 2017 con gli emendamenti MSC citati (vedi Ripasso).")

# ---------------- 3 Collegamenti ----------------
def d3():
    o = [head('Da dove ripartiamo')]
    prev = [('U.D. 2.1.7', 'parti della nave, SOLAS XII, CSR, cenni ESP'),
            ('U.D. 2.2.1', 'SF, BM, σ = M/Z, limiti e strumento'),
            ('Ripasso', 'SOLAS XII regola per regola, novità ESP')]
    for i, (t, s) in enumerate(prev):
        y = 66 + i * 104
        o.append(tile(28, y, 250, 90, t, s, 'n'))
        o.append(A(284, y + 45, 352, 205, STEEL, 2, 9))
    o.append(R(358, 86, 280, 248, SOFTR, RUST, 2, 10))
    o.append(T(498, 118, 'OGGI, IN PROFONDITÀ', 17, True, RUST, 'middle'))
    for i, (t, s) in enumerate([('Struttura', 'nomi e funzioni degli elementi'), ('Corrosione e fatica', 'U.D. 2.2.2: come evitare i danni'), ('ESP', 'come si ispeziona la struttura'), ('Taglio', 'dove va lo sforzo SF')]):
        y = 132 + i * 50
        o.append(R(374, y, 248, 44, '#fff', LINE, 1.5, 8))
        o.append(T(388, y + 19, t, 16, True, INK)); o.append(T(388, y + 37, s, 13, False, GRAY, maxw=226))
    o.append(callout(372, 'Filo comune: lo spessore t della lamiera', 'y', h=48))
    return ''.join(o)
add(E1, 'Perché un approfondimento',
    ['La 2.1.7 ha **nominato** le parti: oggi le **descriviamo**',
     'La 2.2.1 ha calcolato **SF**: oggi vediamo **dove va**',
     '**Corrosione e fatica**: l\'ora della U.D. 2.2.2',
     'Un **filo** comune: lo spessore della lamiera'],
    'collegamento con le unità precedenti', d3(),
    "Richiamare in due minuti le unità precedenti. Nella 2.1.7 i corsisti hanno visto la sezione maestra, i limiti operativi e costruttivi, SOLAS XII e CSR, e un solo cenno all'ESP (slide 41). Nella 2.2.1 hanno calcolato sforzo di taglio (SF) e momento flettente (BM) sulla trave-scafo e la tensione normale σ = M/Z, ma non la tensione tangenziale. Nel Ripasso hanno letto SOLAS XII sul testo originale e le novità ESP dal 2017. Oggi si entra nel dettaglio. Il filo comune è lo spessore: le regole dimensionano gli spessori (struttura), l'ESP li misura in servizio (spessimetria), e la tensione di taglio dipende direttamente dallo spessore del fianco (τ = q/t). Chiedere: quale parte della sezione porta lo sforzo di taglio? Lasciare la domanda aperta fino alla seconda parte.")

# ---------------- 4 Piani e riferimenti ----------------
def d4():
    o = [head('Riferimenti per localizzare un elemento')]
    x, y, w, h = 70, 150, 520, 90
    yw = 190
    o.append(hull_side(x, y, w, h, '#DCE7ED', INK))
    o.append(L(40, yw, 626, yw, BLUE, 2, '8 6')); o.append(T(40, yw - 6, 'LC', 14, True, BLUE))
    o.append(L(40, y + h, 626, y + h, INK, 2.5)); o.append(T(40, y + h + 20, 'linea di base', 14, True, INK))
    sk = h * 0.34
    xfp = x + sk * (yw - y) / h; xap = x + w - 24
    for xx, lab in [(xfp, 'PP AV'), (xap, 'PP AD')]:
        o.append(L(xx, 92, xx, y + h + 6, RUST, 2, '5 4')); o.append(T(xx, 86, lab, 14, True, RUST, 'middle'))
    xm = (xfp + xap) / 2
    o.append(L(xm, 104, xm, y + h + 6, GREEN, 2.5)); o.append(T(xm, 98, 'sezione maestra', 14, True, GREEN, 'middle'))
    o.append(C(xm, y + h / 2 - 5, 9, 'none', GREEN, 2.5)); o.append(L(xm - 9, y + h / 2 - 5, xm + 9, y + h / 2 - 5, GREEN, 2.5))
    ya = y + h + 52
    o.append(A(xm - 24, ya, xfp + 2, ya, INK, 2, 8)); o.append(A(xm + 24, ya, xap - 2, ya, INK, 2, 8))
    o.append(T(xm, ya + 5, 'Lpp', 15, True, INK, 'middle'))
    for k in range(0, 11):
        xx = xap - k * (xap - xfp) / 10
        o.append(L(xx, y + h, xx, y + h - 8, GRAY, 1.5))
    o.append(T(xap, y + h + 20, 'ossatura 0', 14, False, GRAY, 'middle'))
    o.append(A(xap - 70, y + h + 76, xap - 160, y + h + 76, GRAY, 2, 8)); o.append(T(xap - 60, y + h + 81, 'numerazione', 14, False, GRAY))
    o.append(T(28, 420, 'Prora a sinistra · LC = linea di carico · PP = perpendicolare', 14, False, GRAY, maxw=610))
    return ''.join(o)
add(E2, 'Piani e riferimenti della nave',
    ['**Linea di base**, perpendicolari avanti e addietro',
     '**Lpp**: lunghezza tra le perpendicolari',
     '**Sezione maestra** a metà Lpp: riferimento strutturale',
     'Ogni elemento si localizza per **ossatura e ponte**'],
    'riferimenti longitudinali e numerazione delle ossature', d4(),
    "Terminologia di base, da usare correttamente nei rapporti. Linea di base (baseline): riferimento orizzontale per le quote verticali. Perpendicolare avanti (PP AV): verticale nell'intersezione tra dritto di prora e linea di carico di progetto; perpendicolare addietro (PP AD): di norma sull'asse del timone. Lpp è la distanza tra le due. La sezione maestra (midship section) sta a metà Lpp ed è il disegno strutturale di riferimento. Piano diametrale: piano verticale longitudinale di simmetria. Le ossature sono numerate con passo costante, di solito a partire da poppa (ossatura 0 in corrispondenza della perpendicolare addietro), ma la convenzione va controllata sui piani della propria nave. In un rapporto di avaria o di ispezione si scrive sempre: stiva, lato, ossatura, altezza (es. stiva 3, dritta, ossatura 112, terzo inferiore). Lo stesso schema di localizzazione si ritrova nei rapporti di spessimetria ESP.")

# ---------------- 5 Sistemi d'ossatura ----------------
def mini_sec(x, y, w, h, kind):
    o = [P([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], '#FFFFFF', INK, 3, close=False)]
    o[0] = P([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], 'none', INK, 3, close=False)
    if kind == 'T':
        o.append(P([(x, y + 12), (x + w - 12, y + 12), (x + w - 12, y + h - 12), (x, y + h - 12)], 'none', RUST, 5, close=False))
    elif kind == 'L':
        o.append(dots_on(x, y, x + w, y, 15, (0, 9), c=BLUE))
        o.append(dots_on(x + w, y, x + w, y + h, 15, (-9, 0), c=BLUE))
        o.append(dots_on(x, y + h, x + w, y + h, 15, (0, -9), c=BLUE))
        o.append(P([(x, y + 20), (x + w - 20, y + 20), (x + w - 20, y + h - 20), (x, y + h - 20)], 'none', RUST, 2.5, close=False, dash='7 5'))
    else:
        o.append(dots_on(x, y, x + w, y, 15, (0, 9), c=BLUE))
        o.append(dots_on(x, y + h, x + w, y + h, 15, (0, -9), c=BLUE))
        o.append(L(x + w - 11, y + 14, x + w - 11, y + h - 14, RUST, 5))
    return ''.join(o)
def d5():
    o = [head('Tre sistemi, viste in sezione (metà nave)')]
    labs = [('T', 'TRASVERSALE', 'ossature fitte, a ogni passo', 'navi piccole, estremità'),
            ('L', 'LONGITUDINALE', 'correnti fitti + anelli radi', 'petroliere, navi lunghe'),
            ('M', 'MISTO', 'fondo e ponte longitudinali', 'fianco a ossature trasversali')]
    for i, (k, t, s1, s2) in enumerate(labs):
        x = 40 + i * 212
        o.append(mini_sec(x, 92, 150, 170, k))
        o.append(T(x + 75, 300, t, 17, True, INK, 'middle'))
        o.append(T(x + 75, 324, s1, 14, False, GRAY, 'middle', maxw=196))
        o.append(T(x + 75, 344, s2, 14, False, GRAY, 'middle', maxw=196))
    o.append(C(48, 384, 5, BLUE)); o.append(T(60, 389, 'rinforzo longitudinale (sezionato)', 14, False, INK))
    o.append(L(330, 384, 360, 384, RUST, 5)); o.append(T(368, 389, 'ossatura / anello trasversale', 14, False, INK))
    o.append(callout(404, 'Portarinfuse a scafo singolo: sistema misto', 'b', h=40, size=16))
    return ''.join(o)
add(E2, "I tre sistemi d'ossatura",
    ['**Trasversale**: ossature fitte, verticali, a ogni passo',
     '**Longitudinale**: correnti fitti, anelli rinforzati radi',
     '**Misto**: fondo e ponte longitudinali, fianco trasversale',
     'La portarinfuse a scafo singolo è **a sistema misto**'],
    'sistemi di ossatura in sezione trasversale', d5(),
    "Sistema trasversale: ossature (frames) a passo ravvicinato che girano lungo fondo (madieri), fianco (ossature) e ponte (bagli); semplice da costruire, ma porta poco materiale in direzione longitudinale. Sistema longitudinale (introdotto da Isherwood all'inizio del Novecento): rinforzi longitudinali fitti (correnti, longitudinali) sostenuti da anelli trasversali rinforzati (web frames) a intervalli di alcune ossature; tutto il materiale dei rinforzi contribuisce alla robustezza longitudinale. Sistema misto: fondo, doppio fondo, ponte e cisterne alte e a tramoggia a ossatura longitudinale (dove servono le fibre lontane dall'asse neutro), fianco nella stiva a ossature trasversali. È il sistema tipico della portarinfuse a scafo singolo, e spiega perché le ossature di stiva sono un punto delicato: sono elementi trasversali, esposti a urti, corrosione e sforzi locali. Nelle navi a doppio fianco il fianco è spesso a ossatura longitudinale.")

# ---------------- 6 Gerarchia ----------------
def d6():
    o = [head('Il percorso del carico, livello per livello')]
    items = [('Lamiera', 'pressione locale'), ('Rinforzo ordinario', 'ossatura, longitudinale'),
             ('Rinforzo primario', 'madiere, anello, paramezzale'), ('Paratie e scafo', 'trave-scafo')]
    o.append(flow('', items, y=58, h=112, colors=[STEEL, BLUE, HULL, RUST], size=16)[len(head('')):])
    x0, y0 = 80, 212
    o.append(R(x0, y0, 506, 150, '#EEF3F6', INK, 2, 2))
    for xx in (x0 + 3, x0 + 503):
        o.append(R(xx - 7, y0 - 8, 14, 166, HULL, None, 0, 2))
    for k in range(1, 6):
        yy = y0 + k * 25
        o.append(L(x0 + 10, yy, x0 + 496, yy, BLUE, 4))
    o.append(T(x0 + 253, y0 - 14, 'rinforzi ordinari tra due primari', 14, True, BLUE, 'middle'))
    o.append(A(x0 + 520, y0 + 25, x0 + 520, y0 + 50, INK, 1.8, 7)); o.append(A(x0 + 520, y0 + 50, x0 + 520, y0 + 25, INK, 1.8, 7))
    o.append(T(x0 + 530, y0 + 43, 's', 15, True, INK))
    o.append(A(x0 + 230, y0 + 172, x0 + 10, y0 + 172, INK, 1.8, 7)); o.append(A(x0 + 276, y0 + 172, x0 + 496, y0 + 172, INK, 1.8, 7))
    o.append(T(x0 + 253, y0 + 177, 'ℓ', 17, True, INK, 'middle'))
    o.append(T(28, 418, 's = passo dei rinforzi · ℓ = luce tra i primari', 14, False, GRAY))
    return ''.join(o)
add(E2, 'Lamiere, rinforzi e primari',
    ['**Lamiera**: riceve la pressione del mare o del carico',
     '**Rinforzi ordinari**: ossature e longitudinali, fitti',
     '**Rinforzi primari**: madieri, anelli, paramezzali, radi',
     'Il carico **scende di livello** fino alle paratie'],
    'gerarchia degli elementi e percorso del carico', d6(),
    "Gerarchia usata dalle CSR e dai rapporti di classe. 1) Lamiera (plating): riceve direttamente la pressione (mare, carico, zavorra) e la trasmette ai rinforzi. 2) Rinforzi ordinari (ordinary stiffeners): ossature, longitudinali, correnti; passo s tipico dell'ordine del metro o meno. 3) Rinforzi primari (primary supporting members): madieri, anelli rinforzati, paramezzali, bagli rinforzati; sostengono i rinforzi ordinari sulla luce ℓ. 4) Paratie e trave-scafo: raccolgono tutto e lo portano alla spinta. Conseguenza pratica: un danno a un primario (madiere cricca, anello deformato) è più grave di un danno a un singolo rinforzo, perché scarica il percorso del carico su un'area maggiore. Questa gerarchia ritorna nell'ESP: la close-up survey si estende a 'anelli trasversali' e 'ossature', cioè proprio a primari e ordinari.")

# ---------------- 7 Corsi del fasciame ----------------
def d7():
    o = [head('Il fasciame esterno, corso per corso (metà nave)')]
    cl, xb, yb, yd, r = 250, 600, 400, 92, 46
    yw = 230
    o.append(L(cl, 70, cl, 430, GRAY, 1.5, '10 4 2 4')); o.append(T(cl - 6, 444, 'PD', 14, True, GRAY, 'end'))
    o.append(L(cl - 10, yw, xb + 20, yw, BLUE, 1.5, '8 6')); o.append(T(cl + 8, yw - 6, 'LC', 13, True, BLUE))
    segs = [((cl, yb), (cl + 32, yb), RUST, 1), ((cl + 32, yb), (cl + 74, yb), YEL, 2), ((cl + 74, yb), (xb - r, yb), BLUE, 3)]
    for (a, b, c, n) in segs:
        o.append(L(a[0], a[1], b[0], b[1], c, 9, cap='butt'))
    o.append(PATH(f'M{xb - r} {yb} A{r} {r} 0 0 0 {xb} {yb - r}', stroke=GREEN, sw=9))
    sides = [(yb - r, yw + 30, BLUE), (yw + 30, yw - 30, YEL), (yw - 30, yd + 34, BLUE), (yd + 34, yd, RUST)]
    for a, b, c in sides:
        o.append(L(xb, a, xb, b, c, 9, cap='butt'))
    o.append(L(xb, yd, xb - 70, yd, ORANGE, 9, cap='butt')); o.append(L(xb - 70, yd, cl + 120, yd, STEEL, 9, cap='butt'))
    o.append(L(cl + 120, yd, cl + 120, yd - 30, INK, 4))
    pos = [(cl + 16, yb + 26, 1), (cl + 53, yb + 26, 2), (cl + 200, yb + 26, 3), (xb - 4, yb - 4, 4), (xb + 22, yb - 85, 5),
           (xb + 22, yw, 6), (xb + 22, yd + 70, 7), (xb + 22, yd + 17, 8), (xb - 35, yd - 22, 9), (cl + 185, yd - 22, 10)]
    for x, y, n in pos:
        o.append(num(x, y, n, INK))
    items = [(1, 'Chiglia piatta', RUST), (2, 'Torello', YEL), (3, 'Fondo', BLUE), (4, 'Ginocchio', GREEN), (5, 'Fianco', BLUE),
             (6, 'Bagnasciuga', YEL), (7, 'Fianco alto', BLUE), (8, 'Cinta', RUST), (9, 'Trincarino', ORANGE), (10, 'Ponte', STEEL)]
    o.append(legend(28, 84, items, 15, 33))
    return ''.join(o)
add(E2, 'Il fasciame esterno: i corsi',
    ['**Chiglia piatta** e **torello** al centro del fondo',
     '**Corso del ginocchio** tra fondo e fianco',
     '**Cinta** in alto al fianco, **trincarino** sul ponte',
     'Corsi di **bagnasciuga**: zona critica per corrosione'],
    'i corsi del fasciame nella sezione maestra', d7(),
    "Il fasciame è formato da corsi (strakes), file di lamiere longitudinali. Dal centro verso il ponte: chiglia piatta (keel plate), torello (garboard strake), fondo (bottom plating), corso del ginocchio (bilge strake, curvo), fianco (side shell), corsi di bagnasciuga (wind and water strakes, attorno alle linee di galleggiamento tra zavorra e pieno carico), cinta (sheer strake, il corso più alto del fianco) e, sul ponte, trincarino (stringer plate) e lamiere di ponte. Cinta e trincarino sono le fibre più lontane dall'asse neutro: lavorano con le tensioni di flessione più alte, sono spesso di acciaio ad alta resistenza e il loro spigolo non va saldato con attacchi provvisori. I corsi di bagnasciuga sono alternativamente bagnati e asciutti e si corrodono più velocemente: per questo l'ESP li cita espressamente nella spessimetria. Il ginocchio porta l'aletta di rollio, saldata con cura per non innescare cricche nel fasciame.")

# ---------------- 8 Doppio fondo ----------------
def d8():
    o = [head('Doppio fondo: griglia di paramezzali e madieri')]
    x0, x1, yt, yb = 70, 596, 230, 330
    cl = (x0 + x1) / 2
    o.append(R(x0, yt, x1 - x0, yb - yt, '#E6EEF2', None, 0, 0))
    for hx in (cl - 160, cl - 80, cl + 80, cl + 160):
        o.append(C(hx, (yt + yb) / 2, 20, '#FFFFFF', STEEL, 1.5))
    o.append(L(x0, yt, x1, yt, INK, 5)); o.append(L(x0, yb, x1, yb, INK, 5))
    o.append(L(cl, yt, cl, yb, RUST, 6));
    for gx in (cl - 120, cl + 120):
        o.append(L(gx, yt, gx, yb, BLUE, 5))
    for k in range(-7, 8):
        gx = cl + k * 34 + 17
        if x0 + 6 < gx < x1 - 6 and abs(gx - cl) > 10 and min(abs(gx - cl + 120), abs(gx - cl - 120)) > 10:
            o.append(R(gx - 4, yt + 3, 8, 12, BLUE, None, 0, 1)); o.append(R(gx - 4, yb - 15, 8, 12, BLUE, None, 0, 1))
    o.append(P([(x0, yt), (x0 - 30, yt - 70), (x0 - 30, yt)], '#E6EEF2', INK, 2))
    o.append(P([(x1, yt), (x1 + 30, yt - 70), (x1 + 30, yt)], '#E6EEF2', INK, 2))
    o.append(R(150, 150, 366, 70, SAND, None, 0, 4)); o.append(T(cl - 95, 192, 'carico (t/m²)', 16, True, '#fff', 'middle'))
    labs = [(cl, 88, 'Paramezzale centrale', RUST, cl, yt + 6), (cl + 210, 120, 'Paramezzale laterale', BLUE, cl + 120, yt + 6),
            (120, 120, 'Cielo del doppio fondo', INK, 160, yt - 2)]
    for lx, ly, t, c, px, py in labs:
        o.append(T(lx, ly, t, 15, True, c, 'middle')); o.append(L(lx, ly + 6, px, py, c, 1.5)); o.append(C(px, py, 4, c))
    o.append(T(cl - 80, 372, 'Madiere pieno (fori di alleggerimento)', 15, True, HULL, 'middle'))
    o.append(L(cl - 80, 358, cl - 80, (yt + yb) / 2 + 20, HULL, 1.5))
    o.append(T(560, 372, 'Fondo', 15, True, INK, 'end')); o.append(L(540, 358, 520, yb + 2, INK, 1.5))
    o.append(R(80, 398, 10, 14, BLUE, None, 0, 1)); o.append(T(98, 410, 'longitudinali di fondo e del cielo (sezionati)', 14, False, GRAY))
    return ''.join(o)
add(E3, 'Fondo e doppio fondo',
    ['**Paramezzale centrale** e **laterali**: longitudinali, alti',
     '**Madieri**: trasversali, pieni o stagni a intervalli',
     '**Longitudinali** di fondo e del cielo tra i madieri',
     '**Cielo del DF**: piano di carico e lamiera stagna'],
    'sezione del doppio fondo di una portarinfuse', d8(),
    "Il doppio fondo (DF) è una griglia. In senso longitudinale: paramezzale centrale (centre girder), continuo e spesso stagno, e paramezzali laterali (side girders); tra questi corrono i longitudinali di fondo e del cielo. In senso trasversale: madieri (floors), pieni con fori di alleggerimento, stagni dove delimitano le cisterne, alternati in alcune navi a madieri aperti a traliccio. Il cielo del doppio fondo (inner bottom o tank top) è il pavimento della stiva: il suo limite in t/m² e le masse ammesse per stiva (U.D. 2.2.1) dipendono proprio da questa griglia, che lavora come una piastra tra le paratie trasversali. Il DF ospita zavorra e combustibile: gli spazi sono stretti, bui e pericolosi (spazi chiusi). In ESP le cisterne del DF sono cisterne di zavorra da ispezionare, con close-up survey degli anelli e misure di spessore. Errori tipici: chiamare 'madiere' il paramezzale, o 'cielo' il fondo esterno.")

# ---------------- 9 Fianco ----------------
def d9():
    o = [head('Fianco nella stiva: ossature e braccioli')]
    xs, yt, yb = 600, 70, 420
    o.append(P([(xs, yt), (470, yt), (xs, 170)], '#DCE7ED', INK, 2.5))
    o.append(P([(xs, 300), (xs, yb), (440, yb)], '#DCE7ED', INK, 2.5))
    o.append(L(xs, yt, xs, yb, INK, 6))
    xf = 575
    o.append(P([(xf, 151), (xf, 196), (530, 116)], '#F3D9C7', RUST, 2.5))
    o.append(P([(xf, 319), (xf, 274), (520, 360)], '#F3D9C7', RUST, 2.5))
    o.append(L(xf, 151, xf, 319, RUST, 6))
    o.append(C(536, 336, 30, 'none', RUST, 2.5))
    labs = [(100, 'Cisterna alta', 560, 92, INK), (165, 'Bracciolo superiore', 548, 150, RUST),
            (228, 'Ossatura di stiva', xf, 220, RUST), (290, 'Fasciame del fianco', xs, 262, INK),
            (352, 'Bracciolo inferiore: zona critica', 540, 330, RUST), (412, 'Cisterna a tramoggia', 560, 400, INK)]
    for ly, t, px, py, c in labs:
        o.append(T(28, ly, t, 15, True, c)); o.append(L(28 + tw(t, 15, True) + 6, ly - 5, px, py, c, 1.5)); o.append(C(px, py, 4, c))
    return ''.join(o)
add(E3, 'Il fianco: ossature di stiva',
    ['**Ossature di stiva** verticali, con braccioli alle estremità',
     '**Bracciolo inferiore** sulla tramoggia: punto critico',
     'Il terzo inferiore: **corrosione e urti** di benne e ruspe',
     '**Doppio fianco** sulle navi recenti (SOLAS XII/6.2)'],
    "fianco nella stiva di una portarinfuse a scafo singolo", d9(),
    "Nella portarinfuse a scafo singolo il fianco in stiva è a ossatura trasversale. Ogni ossatura di stiva (hold frame) è collegata in alto alla cisterna alta e in basso alla cisterna a tramoggia con braccioli (brackets). La zona più delicata è il terzo inferiore con il bracciolo inferiore: lì si sommano corrosione (condensa e residui del carico), urti di benne e ruspe durante lo scarico e concentrazioni di tensione al piede del bracciolo. Il distacco di ossature e il cedimento del fianco sono tra le cause riconosciute delle perdite di portarinfuse negli anni '90; per questo IACS ha introdotto i requisiti UR S12 (struttura del fianco) e S31 (criteri di rinnovo delle ossature) e l'ESP chiede close-up survey delle ossature crescente con l'età. Le portarinfuse a doppio fianco hanno il fianco interno liscio verso la stiva: lo spazio tra i due fianchi va ispezionato (vedi Ripasso, SOLAS XII/6.2). Domanda: perché l'ossatura è più esposta del fianco liscio? (spigoli, flange, ristagno di residui).")

# ---------------- 10 Cisterne alte e tramogge ----------------
def d10():
    o = [head('Cisterne: longitudinali e anelli rinforzati')]
    g = secgeo(170, 72, 330, 330)
    o.append(bc_section(g['x'], g['y'], g['w'], g['h'], cargo=None, hatch=True))
    x, y, xr, yb = g['x'], g['y'], g['xr'], g['yb']
    tl = (x + g['tw'], y + g['dt']); tb = (x, y + g['dt'] + g['th'])
    o.append(dots_on(tl[0], tl[1], tb[0], tb[1], 15, (8, 6)))
    o.append(dots_on(x, y + g['dt'], x + g['tw'], y + g['dt'], 15, (0, 7)))
    o.append(dots_on(x, y + g['dt'], x, y + g['dt'] + g['th'], 15, (7, 0)))
    ht = (x, yb - g['ds'] - g['hh']); hb = (x + g['hw'], yb - g['ds'])
    o.append(dots_on(ht[0], ht[1], hb[0], hb[1], 15, (-6, 7)))
    o.append(dots_on(x, yb, xr, yb, 16, (0, -7)))
    o.append(dots_on(x, yb - g['ds'], xr, yb - g['ds'], 16, (0, 7)))
    o.append(P([(x + 14, y + g['dt'] + 12), (x + g['tw'] - 34, y + g['dt'] + 12), (x + 14, y + g['dt'] + g['th'] - 40)], 'none', RUST, 3, dash='7 5'))
    o.append(P([(x + 12, yb - g['ds'] - g['hh'] + 44), (x + 12, yb - g['ds'] - 10), (x + g['hw'] - 40, yb - g['ds'] - 10)], 'none', RUST, 3, dash='7 5'))
    o.append(T(xr + 10, y + 70, 'Cisterna', 15, True, INK)); o.append(T(xr + 10, y + 90, 'alta', 15, True, INK))
    o.append(T(xr + 10, yb - 80, 'Cisterna a', 15, True, INK)); o.append(T(xr + 10, yb - 60, 'tramoggia', 15, True, INK))
    o.append(C(40, 420, 5, BLUE)); o.append(T(52, 425, 'longitudinali', 14, False, INK))
    o.append(L(170, 420, 205, 420, RUST, 3, '7 5')); o.append(T(212, 425, 'anello rinforzato (web)', 14, False, INK))
    o.append(T(28, 120, 'Zavorra', 15, True, BLUE)); o.append(T(28, 140, 'in entrambe', 15, True, BLUE))
    return ''.join(o)
add(E3, 'Cisterne alte e a tramoggia',
    ['Pareti a ossatura **longitudinale**: contano per la trave',
     '**Anelli rinforzati** trasversali ogni alcune ossature',
     'Spazi di **zavorra**: corrosione e rivestimenti',
     'In ESP: close-up survey degli **anelli** per tipo di cisterna'],
    'cisterne alte e a tramoggia con i loro rinforzi', d10(),
    "Le cisterne alte (topside tanks) e a tramoggia (hopper tanks) chiudono gli spigoli della stiva: danno al carico la forma che lo autolivella e sono le prime cisterne di zavorra della nave. Le loro lamiere (ponte, fianco, lamiera inclinata) sono irrigidite da longitudinali: fanno parte della trave-scafo e contribuiscono al momento d'inerzia della sezione. I longitudinali sono sostenuti da anelli rinforzati trasversali (transverse web frames) a intervalli di alcune ossature. Sono spazi di zavorra con acqua di mare, aria umida e cicli termici: il rivestimento è decisivo. Nell'ESP la close-up survey alla prima visita di rinnovo riguarda un anello trasversale con le lamiere e i longitudinali associati in due cisterne rappresentative di ogni tipo; con l'età si passa a tutti gli anelli di ogni cisterna. Il termine 'transverse web' dei rapporti di classe indica proprio questi anelli.")

# ---------------- 11 Ponte ----------------
def d11():
    o = [head('Ponte tra due boccaporti (vista in pianta)')]
    x0, x1, yt, yb = 40, 626, 90, 380
    o.append(R(x0, yt, x1 - x0, yb - yt, '#EEF1F3', INK, 2.5, 2))
    o.append(R(x0, yt, x1 - x0, 22, '#F3D9C7', None, 0, 0)); o.append(R(x0, yb - 22, x1 - x0, 22, '#F3D9C7', None, 0, 0))
    hy0, hy1 = 150, 320
    for hx0, hx1 in [(x0 - 2, 260), (406, x1 + 2)]:
        o.append(R(hx0, hy0, hx1 - hx0, hy1 - hy0, '#FFFFFF', HULL, 5, 0))
    o.append(R(260, hy0 + 6, 146, hy1 - hy0 - 12, '#F7EBCB', None, 0, 0))
    for yy in (120, 136, 334, 350):
        o.append(L(x0, yy, x1, yy, BLUE, 1.6, '6 5'))
    for cx, cy in [(260, hy0), (260, hy1), (406, hy0), (406, hy1)]:
        o.append(C(cx, cy, 13, 'none', RUST, 3))
    o.append(T(333, 240, 'cross deck', 17, True, '#7A5200', 'middle'))
    o.append(T(150, 240, 'boccaporto', 16, True, HULL, 'middle')); o.append(T(516, 240, 'boccaporto', 16, True, HULL, 'middle'))
    o.append(T(333, 82, 'trincarino (fascia ai lati)', 14, True, RUST, 'middle'))
    o.append(T(333, 404, 'longitudinali di ponte (tratteggio, sotto il ponte)', 14, True, BLUE, 'middle'))
    o.append(T(333, 430, 'cerchi: angoli dei boccaporti, concentrazione di tensioni', 14, True, RUST, 'middle'))
    o.append(T(196, 168, 'mastra', 14, True, HULL))
    return ''.join(o)
add(E3, 'Il ponte: trincarino, mastre, cross deck',
    ['**Lamiere di ponte** e **trincarino** ai lati dei boccaporti',
     '**Longitudinali** sotto il ponte, fuori dalle aperture',
     '**Mastre**: longitudinali e trasversali, attorno al boccaporto',
     '**Cross deck** e **angoli**: concentrazioni di tensione'],
    'ponte di una portarinfuse tra due boccaporti, in pianta', d11(),
    "Nella portarinfuse il ponte di resistenza è ridotto a due strisce laterali, perché i boccaporti occupano gran parte della larghezza. Solo il ponte fuori dalle aperture (con trincarino e longitudinali) e le mastre longitudinali continue contribuiscono alla trave-scafo. Il cross deck, la striscia tra due boccaporti, lavora soprattutto in senso trasversale: tiene uniti i due fianchi, è compresso quando il mare spinge i fianchi verso l'interno e ospita spesso bagli rinforzati sottostanti. Gli angoli dei boccaporti sono il punto di massima concentrazione di tensione del ponte: si progettano con raggi ampi e lamiere inspessite (insert plates) e sono una zona tipica di cricche. Mastre e coperchi sono anche barriera all'acqua: SOLAS XII e IACS UR S21 ne fissano la robustezza. Mostrare dove si trova l'angolo del boccaporto più vicino all'aula su una foto o un disegno di nave reale.")

# ---------------- 12 Paratie corrugate ----------------
def d12():
    o = [head('Paratia trasversale corrugata (vista di fianco)')]
    yd, yb = 70, 400
    cx = 300
    o.append(L(60, yd, 560, yd, INK, 6)); o.append(L(60, yb, 560, yb, INK, 6))
    o.append(P([(cx - 75, yb), (cx + 75, yb), (cx + 38, yb - 90), (cx - 38, yb - 90)], '#DCE7ED', INK, 2.5))
    o.append(P([(cx - 50, yd), (cx + 50, yd), (cx + 30, yd + 50), (cx - 30, yd + 50)], '#DCE7ED', INK, 2.5))
    o.append(R(cx - 22, yd + 50, 44, yb - 140 - yd, '#C9D4DA', INK, 2.5, 0))
    for k in range(1, 7):
        yy = yd + 50 + k * (yb - 140 - yd) / 7
        o.append(L(cx - 22, yy, cx + 22, yy, STEEL, 1))
    o.append(P([(cx - 22, yb - 90), (cx - 38, yb - 90), (cx - 22, yb - 120)], '#F3D9C7', RUST, 2))
    o.append(P([(cx + 22, yb - 90), (cx + 38, yb - 90), (cx + 22, yb - 120)], '#F3D9C7', RUST, 2))
    o.append(P([(cx - 75, yb), (cx - 175, yb), (cx - 75, yb - 50)], SAND, None, 0, op=0.8))
    labs_l = [(110, 'Zoccolo superiore', cx - 30, yd + 30), (220, 'Corrugazioni verticali', cx - 22, 220),
              (300, 'Lamiere deflettrici', cx - 30, yb - 102), (370, 'Zoccolo inferiore', cx - 50, yb - 40)]
    for ly, t, px, py in labs_l:
        o.append(T(28, ly, t, 15, True, INK)); o.append(L(28 + tw(t, 15, True) + 6, ly - 5, px, py, RUST, 1.5)); o.append(C(px, py, 4, RUST))
    o.append(T(408, 112, 'Pianta delle corrugazioni', 15, True, INK))
    zz = [(410, 150), (440, 150), (460, 180), (490, 180), (510, 150), (540, 150), (560, 180), (590, 180), (610, 150)]
    o.append(P(zz, 'none', HULL, 4, close=False))
    o.append(T(510, 210, 'stiva AV ↑ · stiva AD ↓', 14, False, GRAY, 'middle'))
    o.append(T(410, 300, 'Saldatura al piede', 15, True, RUST)); o.append(T(410, 320, 'dello zoccolo inferiore:', 15, True, RUST))
    o.append(T(410, 340, 'corrosione e cricche', 15, True, RUST))
    o.append(L(405, 330, cx + 76, yb - 4, RUST, 1.5))
    return ''.join(o)
add(E3, 'Le paratie trasversali corrugate',
    ['**Corrugazioni** verticali: rigidezza senza rinforzi saldati',
     '**Zoccolo inferiore** e **superiore** alle estremità',
     '**Lamiere deflettrici**: niente residui di carico',
     'Il **piede** della corrugazione: zona critica'],
    'paratia corrugata con zoccoli tra due stive', d12(),
    "Le paratie trasversali tra le stive sono di solito corrugate: le pieghe verticali danno rigidezza senza rinforzi saldati, la stiva si pulisce meglio e il carico non ristagna. In basso la paratia poggia su uno zoccolo inferiore (lower stool), in alto su uno zoccolo superiore (upper stool) sotto il cross deck. Le lamiere deflettrici (shedder plates) chiudono gli angoli in testa allo zoccolo e impediscono l'accumulo di carico; le lamiere di raccordo (gusset plates) collegano corrugazioni e zoccolo. La paratia porta la pressione del carico e, in caso di allagamento di una stiva, la pressione dell'acqua: IACS UR S18 la verifica con stiva allagata e SOLAS XII (Ripasso) richiede che le navi esistenti più vulnerabili verifichino la paratia tra le stive 1 e 2. Zona critica: il piede delle corrugazioni sullo zoccolo inferiore, per corrosione da residui umidi e per concentrazione di tensioni. È uno dei punti esaminati in close-up survey ESP a ogni visita di rinnovo.")

# ---------------- 13 Estremità ----------------
def d13():
    o = [head('Le estremità: prora a sinistra')]
    x, y, w, h = 50, 140, 566, 120
    o.append(hull_side(x, y, w, h, '#EEF3F6', INK))
    sk = h * 0.34
    xc = x + 90
    o.append(L(xc, y, xc, y + h, RUST, 5)); o.append(T(xc, y - 40, 'Paratia di', 14, True, RUST, 'middle')); o.append(T(xc, y - 22, 'collisione', 14, True, RUST, 'middle'))
    o.append(P([(x + 3, y + 3), (xc - 3, y + 3), (xc - 3, y + h - 3), (x + sk - 3, y + h - 3)], '#DCE7ED', None, 0))
    o.append(T(x + 66, y + 64, 'gavone', 14, True, HULL, 'middle', maxw=44)); o.append(T(x + 66, y + 82, 'AV', 14, True, HULL, 'middle'))
    o.append(R(xc + 6, y + 6, 70, h - 12, '#FBEDE2', None, 0, 0)); o.append(T(xc + 41, y + h / 2 + 5, 'stiva 1', 14, True, RUST, 'middle'))
    xer = x + w - 190
    o.append(L(xer, y, xer, y + h, INK, 4)); o.append(R(xer + 4, y + 4, 100, h - 8, '#E6E6E6', None, 0, 0))
    o.append(T(xer + 54, y + h / 2 + 5, 'sala macchine', 14, True, INK, 'middle', maxw=94))
    xap = x + w - 80
    o.append(L(xap, y, xap, y + h, INK, 4)); o.append(T(xap + 30, y + 52, 'gavone', 14, True, HULL, 'middle', maxw=48)); o.append(T(xap + 28, y + 70, 'AD', 14, True, HULL, 'middle'))
    o.append(R(x + w - 30, y + h - 4, 10, 46, INK, None, 0, 1)); o.append(R(x + w - 46, y + h + 8, 34, 34, STEEL, INK, 1.5, 2))
    o.append(T(x + w - 30, y + h + 64, 'dritto di poppa e timone', 14, True, INK, 'end'))
    o.append(R(x + 4, y + h + 84, 160, 16, '#F3D9C7', RUST, 1.5, 3))
    o.append(T(x + 172, y + h + 97, 'rinforzi contro panting e slamming (prora)', 14, True, RUST))
    o.append(T(x, 438, 'Pianta schematica, non in scala', 14, False, GRAY))
    return ''.join(o)
add(E3, 'Prora e poppa',
    ['**Paratia di collisione** a prora, **gavoni** alle estremità',
     'Prora: rinforzi contro **panting** e **slamming**',
     'Poppa: **dritto**, timone, sala macchine, gavone AD',
     'Estremità a ossatura **trasversale** e più fitta'],
    'estremità di prora e di poppa in vista laterale', d13(),
    "Le estremità non contribuiscono molto alla robustezza longitudinale (il momento flettente vi è piccolo) ma sono molto sollecitate localmente. A prora: dritto di prora e bulbo, gavone di prora (fore peak, spesso cisterna di zavorra), paratia di collisione, la prima paratia stagna, che deve restare integra in caso di urto. Rinforzi contro il panting (pressioni pulsanti sul fasciame prodiero quando la prora entra ed esce dall'onda) e contro lo slamming (colpi del fondo prodiero sull'acqua, soprattutto in zavorra con poco pescaggio a prora). A poppa: dritto di poppa (sternframe), asse del timone, gavone di poppa, sala macchine. Collegamento con la stiva n. 1: è la più esposta al mare (caso Derbyshire, U.D. 2.1.7); SOLAS XII/12 e XII/13 richiedono allarmi di ingresso d'acqua e mezzi di esaurimento negli spazi prodieri (Ripasso). Nei rapporti si indica sempre 'a proravia' o 'a poppavia' di un'ossatura o di una paratia.")

# ---------------- 14 Elementi trasversali ----------------
def d14():
    o = [head('Elementi trasversali: anelli che danno forma')]
    g = secgeo(56, 92, 250, 280)
    o.append(bc_section(g['x'], g['y'], g['w'], g['h'], cargo=None, hatch=False))
    x, y, xr, yb = g['x'], g['y'], g['xr'], g['yb']
    o.append(P([(x + 6, y + 10), (xr - 6, y + 10), (xr - 6, yb - 6), (x + 6, yb - 6)], 'none', RUST, 5))
    for yy in (180, 260):
        o.append(A(x - 34, yy, x - 4, yy, BLUE, 3, 9)); o.append(A(xr + 34, yy, xr + 4, yy, BLUE, 3, 9))
    o.append(A((x + xr) / 2, yb + 34, (x + xr) / 2, yb + 4, BLUE, 3, 9))
    o.append(T((x + xr) / 2, 82, 'pressione del mare', 14, True, BLUE, 'middle'))
    items = [('Madieri', 'fondo e doppio fondo'), ('Ossature e anelli', 'fianco e cisterne'),
             ('Bagli e cross deck', 'ponte'), ('Paratie trasversali', 'tra le stive')]
    for i, (t, s) in enumerate(items):
        o.append(tile(346, 66 + i * 70, 292, 60, t, s, 'r', 16, 14))
    o.append(T(346, 362, 'Funzioni', 16, True, INK))
    for i, t in enumerate(['mantengono la forma della sezione', 'sostengono lamiere e longitudinali', 'resistono a torsione e distorsione']):
        o.append(C(354, 384 + i * 24 - 5, 4, RUST)); o.append(T(364, 384 + i * 24, t, 14, False, INK, maxw=274))
    return ''.join(o)
add(E4, 'Gli elementi trasversali',
    ['**Madieri**, **ossature**, **anelli**, **bagli**, **paratie**',
     'Mantengono la **forma** della sezione sotto pressione',
     'Sostengono **lamiere e longitudinali**',
     'Resistono a **torsione** e distorsione trasversale'],
    'gli elementi trasversali formano anelli chiusi', d14(),
    "Si ricompone la struttura per funzione. Elementi trasversali: madieri, ossature di stiva, anelli rinforzati delle cisterne, bagli e cross deck, paratie trasversali. Insieme formano anelli chiusi che mantengono la forma della sezione contro la pressione esterna del mare e interna del carico o della zavorra, e sostengono lamiere e longitudinali (gerarchia della slide 6). Resistono alla distorsione trasversale (racking, quando la nave rolla e la sezione tende a deformarsi a parallelogramma) e, con le paratie, alla torsione (U.D. 2.2.1, slide 18). Non contribuiscono al momento d'inerzia della trave-scafo, perché sono orientati trasversalmente: un madiere più spesso non riduce la tensione nel ponte. Le paratie trasversali sono anche gli appoggi della trave doppio fondo: vicino alle paratie si concentrano gli sforzi di taglio locali e globali (seconda parte).")

# ---------------- 15 Elementi longitudinali ----------------
def d15():
    o = [head('Elementi longitudinali: la trave-scafo')]
    g = secgeo(56, 92, 250, 280)
    o.append(bc_section(g['x'], g['y'], g['w'], g['h'], cargo=None, hatch=True, sw=6))
    x, y, xr, yb = g['x'], g['y'], g['xr'], g['yb']
    cl = (x + xr) / 2
    o.append(L(cl, yb - g['ds'], cl, yb, BLUE, 6))
    for gx in (cl - 60, cl + 60):
        o.append(L(gx, yb - g['ds'], gx, yb, BLUE, 4))
    o.append(L(x - 8, y + 150, xr + 8, y + 150, GREEN, 2, '8 5')); o.append(T((x + xr) / 2, y + 144, 'asse neutro', 14, True, GREEN, 'middle'))
    items = [('Fondo e cielo del DF', 'con paramezzali e longitudinali'), ('Fianco e cisterne', 'corsi e lamiere inclinate'),
             ('Ponte e mastre continue', 'fuori dai boccaporti')]
    for i, (t, s) in enumerate(items):
        o.append(tile(346, 92 + i * 74, 292, 62, t, s, 'b', 16, 14))
    o.append(tile(346, 318, 292, 62, 'Solo se continui', 'nella zona centrale (0,4 L)', 'g', 16, 14))
    o.append(T(346, 410, 'Più lontani dall\'asse neutro', 14, True, GRAY)); o.append(T(346, 430, '= più efficaci per I e Z', 14, True, GRAY))
    return ''.join(o)
add(E4, 'Gli elementi longitudinali',
    ['**Fondo, paramezzali, fianco, ponte**, mastre continue',
     'Formano la **trave-scafo**: portano SF e BM',
     'Contano solo se **continui** a centro nave',
     'Più lontani dall\'asse neutro, **più efficaci**'],
    'gli elementi longitudinali formano la trave-scafo', d15(),
    "Elementi longitudinali: fasciame del fondo, cielo del doppio fondo, paramezzali, longitudinali, corsi del fianco, lamiere delle cisterne alte e a tramoggia, ponte fuori dai boccaporti, mastre longitudinali continue. Sono loro a formare la trave-scafo della U.D. 2.2.1: entrano nel calcolo del momento d'inerzia I e del modulo di resistenza Z della sezione maestra, quindi decidono σ = M/Z e, come vedremo, τ = SF·Q/(I·t). Per contare devono essere continui nella zona centrale della nave (circa 0,4 L a centro nave, dove le regole verificano il modulo di resistenza): un elemento che si interrompe non porta flessione. Il contributo cresce con il quadrato della distanza dall'asse neutro: per questo ponte e fondo sono i più importanti per il momento, mentre il fianco, verticale, porta la maggior parte del taglio. Anticipazione per la seconda parte: se il ponte si assottiglia aumenta σ, se il fianco si assottiglia aumenta τ.")

# ---------------- 16 Discontinuità ----------------
def d16():
    o = [head('Dove le tensioni si concentrano')]
    x0, y0, w, h = 40, 70, 360, 230
    o.append(R(x0, y0, w, h, '#EEF3F6', INK, 2, 2))
    ox0, ox1, oy0, oy1 = 150, 290, 140, 230
    for k in range(9):
        yy = y0 + 14 + k * 25
        if oy0 - 8 < yy < oy1 + 8:
            mid = (oy0 + oy1) / 2
            dy = -1 if yy < mid else 1
            ye = (oy0 - 14 - (oy0 - yy) * 0.35) if dy < 0 else (oy1 + 14 + (yy - oy1) * 0.35)
            o.append(PATH(f'M{x0 + 6} {yy} C{ox0 - 50} {yy} {ox0 - 30} {ye} {ox0} {ye} L{ox1} {ye} C{ox1 + 30} {ye} {ox1 + 50} {yy} {x0 + w - 6} {yy}', stroke=BLUE, sw=1.6))
        else:
            o.append(L(x0 + 6, yy, x0 + w - 6, yy, BLUE, 1.6))
    o.append(R(ox0, oy0, ox1 - ox0, oy1 - oy0, '#FFFFFF', HULL, 3, 16))
    for cx, cy in [(ox0, oy0), (ox1, oy0), (ox0, oy1), (ox1, oy1)]:
        o.append(C(cx + (8 if cx == ox0 else -8), cy + (8 if cy == oy0 else -8), 14, 'none', RUST, 3))
    o.append(T(x0 + w / 2, y0 + h + 26, 'linee di tensione attorno a un\'apertura', 14, True, BLUE, 'middle'))
    o.append(tile(424, 62, 214, 82, 'Angoli delle aperture', 'raggio ampio, lamiera inspessita', 'r', 15, 14))
    o.append(tile(424, 152, 214, 82, 'Fine di un elemento', 'mastra o paramezzale: rastremare', 'r', 15, 14))
    o.append(tile(424, 242, 214, 82, 'Punti duri', 'braccioli rigidi su lamiera sottile', 'r', 15, 14))
    o.append(callout(358, 'Qui nascono le cricche: qui guarda l\'ESP', 'r', h=46))
    o.append(T(333, 432, 'Le saldature provvisorie a bordo creano nuovi punti duri', 14, False, GRAY, 'middle'))
    return ''.join(o)
add(E4, 'Continuità e discontinuità',
    ['Le tensioni **deviano** attorno alle aperture',
     'Angoli, estremità e braccioli: **concentrazioni**',
     'Rimedi: **raggi, rastremature, inserti**',
     'Le zone critiche ESP nascono **qui**'],
    'concentrazione di tensioni attorno a un\'apertura', d16(),
    "Le tensioni di flessione corrono nel ponte come un flusso; un'apertura le costringe a deviare e le addensa agli angoli. Fattori di concentrazione di 2–3 volte la tensione nominale sono normali agli angoli delle aperture; per questo gli angoli dei boccaporti hanno raggi ampi o forme ellittiche e lamiere inspessite. Lo stesso vale alla fine di un elemento longitudinale (mastra, paramezzale, longitudinale interrotto): la rigidezza cambia di colpo e la tensione si concentra; si rimedia rastremando gradualmente l'elemento con braccioli. I punti duri (hard spots) sono attacchi rigidi su lamiere flessibili, come un bracciolo che termina a metà di un pannello. Conseguenza operativa: niente saldature provvisorie, golfari o attacchi improvvisati su ponte, cinta, mastre e angoli dei boccaporti senza approvazione della società di classifica. Queste zone corrispondono alle 'critical structural areas' dell'ESP, che vedremo nella seconda parte.")

# ---------------- 17 Acciai ----------------
def d17():
    o = [head('Acciai navali: grado, snervamento e fattore k')]
    hdr = ['Acciaio', 'ReH N/mm²', 'k', '175/k']
    xs = [28, 260, 400, 520]
    o.append(R(28, 62, 610, 38, INK, None, 0, 6))
    for x, t in zip(xs, hdr):
        o.append(T(x + 12, 87, t, 15, True, '#fff'))
    rows_ = [('Normale (A, B, D, E)', '235', '1,00', '175', SOFTB), ('AH32 · DH32 · EH32', '315', '0,78', '224', '#FFFFFF'),
             ('AH36 · DH36 · EH36', '355', '0,72', '243', SOFTB), ('AH40 · DH40 · EH40', '390', '0,68', '257', '#FFFFFF')]
    for i, (a, b, c, d, f) in enumerate(rows_):
        y = 104 + i * 44
        o.append(R(28, y, 610, 40, f, LINE, 1, 4))
        for x, t in zip(xs, (a, b, c, d)):
            o.append(T(x + 12, y + 26, t, 16, x == 28, INK, maxw=220))
    o.append(T(28, 312, 'Lettera = tenacità alle basse temperature (A → E crescente)', 15, True, INK, maxw=610))
    o.append(T(28, 336, 'Numero = snervamento minimo in kgf/mm² (32, 36, 40)', 15, False, GRAY, maxw=610))
    o.append(callout(358, 'Ponte e fondo spesso in AH32/AH36: stesso disegno, spessori minori', 'b', h=50, size=15))
    o.append(T(28, 438, 'Tensione ammessa in mare (UR S11): 175/k N/mm²', 14, False, GRAY))
    return ''.join(o)
add(E5, 'Acciai e fattore del materiale k',
    ['Acciaio **normale** e ad **alta resistenza** (AH, DH, EH)',
     'La lettera indica la **tenacità**, il numero lo **snervamento**',
     'Il fattore **k** riduce gli spessori richiesti',
     'Spessori minori: **margini di corrosione** più critici'],
    'gradi di acciaio navale e fattore del materiale', d17(),
    "Gli acciai da scafo sono di resistenza normale (snervamento minimo 235 N/mm², gradi A, B, D, E) o ad alta resistenza (AH/DH/EH/FH 32, 36, 40, con snervamento minimo 315, 355 e 390 N/mm²). La lettera indica la tenacità, cioè la resistenza alla frattura fragile alle basse temperature (prova di resilienza a temperature via via più basse da A a E e F); si usano gradi più tenaci per cinta, trincarino, ginocchio e lamiere spesse. Il fattore del materiale k (1,00; 0,78; 0,72; 0,68; IACS UR S4 Rev.4, 2017, per le navi non CSR; per l'acciaio 390 vale 0,66 se si esegue una verifica a fatica) entra nelle formule di regola: la tensione ammessa per flessione longitudinale in mare è 175/k N/mm² (IACS UR S11 Rev.10, 2020), quella di taglio 110/k N/mm². Effetto pratico: con acciaio ad alta resistenza lo scafo è più leggero, ma lamiere più sottili hanno meno spessore da perdere per corrosione, e la rigidezza (modulo elastico) è la stessa dell'acciaio normale, quindi l'instabilità (buckling) diventa più critica. Il grado di ogni corso è indicato sul disegno della sezione maestra.")

# ---------------- 18 Spessori ----------------
def d18():
    o = [head('Spessori: dal nuovo al rinnovo (esempio CSR)')]
    x0, bw, y0 = 120, 90, 80
    sc = 300 / 4.5
    def yy(t): return y0 + (16.5 - t) * sc
    o.append(R(x0, yy(16.0), bw, 4.0 * sc, SOFTB, BLUE, 2, 0))
    o.append(R(x0, yy(16.0), bw, 2.5 * sc, '#F3D9C7', RUST, 2, 0))
    o.append(R(x0, yy(14.0), bw, 0.5 * sc, SOFTY, YEL, 2, 0))
    for t, lab, c in [(16.0, 't nuovo 16,0 mm', INK), (14.0, 'soglia corrosione sostanziale 14,0', '#7A5200'), (13.5, 't rinnovo = t netto 13,5', RUST)]:
        o.append(L(x0 + bw, yy(t), x0 + bw + 30, yy(t), c, 2)); o.append(T(x0 + bw + 36, yy(t) + 5, lab, 15, True, c, maxw=380))
    o.append(T(x0 + bw / 2, yy(15.0) + 5, 't c', 15, True, RUST, 'middle'))
    o.append(T(x0 + bw / 2, yy(12.8), 't netto', 15, True, BLUE, 'middle'))
    o.append(P([(x0 - 8, y0 + 296), (x0 + 20, y0 + 286), (x0 + 50, y0 + 300), (x0 + bw + 8, y0 + 288)], 'none', INK, 2, close=False))
    o.append(T(x0 + bw + 36, y0 + 296, 'scala ingrandita, base interrotta', 14, False, GRAY))
    o.append(T(28, 412, 't c = margine di corrosione (2,5 mm nell\'esempio)', 14, False, GRAY))
    o.append(T(28, 434, 'Corrosione sostanziale: misurato tra t rinnovo e t rinnovo + 0,5 mm', 14, False, GRAY, maxw=610))
    return ''.join(o)
add('PARTE 1 · CORROSIONE E FATICA', 'Spessore lordo, netto e di rinnovo',
    ['**t nuovo = t netto + margine di corrosione**',
     'CSR: **t rinnovo** = spessore nuovo − margine',
     '**Corrosione sostanziale**: entro 0,5 mm dal rinnovo',
     'Lo **spessimetro** decide: riparare o sorvegliare'],
    'scala degli spessori di una lamiera, valori didattici', d18(),
    "Ripresa della U.D. 2.1.7 (CSR, spessore netto) con i criteri usati in servizio. Le CSR dimensionano su spessori netti; lo spessore di costruzione aggiunge il margine di corrosione t c (più eventuali aggiunte volontarie dell'armatore). In servizio (CSR, edizione 1 luglio 2025, Pt 1 Ch 13 Sec 2 [2.1.1]: t ren = t as-built − t c − t vol_add) lo spessore di rinnovo t rinnovo è lo spessore di costruzione meno il margine di corrosione (e meno l'eventuale aggiunta volontaria): sotto quel valore la lamiera va rinnovata. Si parla di corrosione sostanziale quando lo spessore misurato è compreso tra t rinnovo e t rinnovo + 0,5 mm: non è ancora da sostituire, ma va misurata a ogni visita annuale o protetta. Per le navi non costruite secondo le CSR la definizione è diversa: corrosione oltre il 75 % del margine ammesso dalla società di classifica, ma entro i limiti accettabili. I valori della figura (16,0; 2,5; 13,5; 14,0 mm) sono esempi didattici: i valori reali sono nei piani della nave, che l'ESP richiede a bordo con gli spessori di rinnovo indicati.")

# ---------------- 19 Esercizio ----------------
def d19():
    o = [head('Esercizio: nome e orientamento')]
    g = secgeo(60, 86, 300, 320)
    o.append(bc_section(g['x'], g['y'], g['w'], g['h'], cargo=None, hatch=True))
    x, y, xr, yb = g['x'], g['y'], g['xr'], g['yb']
    cl = (x + xr) / 2
    o.append(L(cl, yb - g['ds'], cl, yb, INK, 4))
    o.append(L(xr - 22, y + g['dt'] + g['th'] + 14, xr - 22, yb - g['ds'] - g['hh'] - 10, INK, 4))
    marks = [(cl, yb - g['ds'] / 2, 1), (cl - 80, yb - g['ds'] / 2, 2), (cl + 70, yb - g['ds'] - 12, 3), (xr - 40, (y + yb) / 2, 4),
             (x + g['tw'] / 2 + 6, y + g['dt'] + g['th'] / 2 - 10, 5), (x + g['tw'] + 16, y - 36, 6), (xr - g['hw'] / 2 - 4, yb - g['ds'] - g['hh'] / 2 + 6, 7), (xr - 12, y - 8, 8)]
    for mx, my, n in marks:
        o.append(num(mx, my, n))
    o.append(T(398, 92, 'Per ogni numero:', 16, True, INK))
    o.append(T(398, 114, 'nome italiano e inglese,', 15, False, GRAY))
    o.append(T(398, 134, 'T (trasversale) o L', 15, False, GRAY))
    o.append(T(398, 154, '(longitudinale)', 15, False, GRAY))
    for i in range(8):
        yy = 186 + i * 30
        o.append(T(410, yy, f'{i + 1}', 15, True, RUST)); o.append(L(428, yy + 3, 600, yy + 3, LINE, 1.5)); o.append(T(630, yy, 'T/L', 14, False, GRAY, 'end'))
    return ''.join(o)
add(EX, 'Esercizio: riconoscere gli elementi',
    ['Otto elementi **numerati** sulla sezione maestra',
     'Per ciascuno: **nome** italiano e inglese',
     'Indicare se è **trasversale** o **longitudinale**',
     'Tempo: **3 minuti**, poi correzione insieme'],
    'sezione maestra con otto elementi da riconoscere', d19(),
    "Esercizio individuale, tre minuti, correzione a voce. Soluzione: 1 paramezzale centrale (centre girder), L. 2 madiere (floor), visto in sezione come la parete del doppio fondo sullo sfondo, T. 3 cielo del doppio fondo (inner bottom / tank top), L. 4 ossatura di stiva (hold frame), T. 5 lamiera inclinata della cisterna alta (sloping plate of topside tank), L. 6 mastra longitudinale del boccaporto (hatch side coaming), L se continua. 7 lamiera inclinata della cisterna a tramoggia (hopper sloping plate), L; il bracciolo inferiore dell'ossatura, che si attacca qui, è invece T. 8 trincarino (deck stringer plate), L. Errori frequenti: confondere madiere e paramezzale; considerare 'longitudinale' la mastra anche dove è interrotta; dimenticare che una lamiera può essere longitudinale anche se è inclinata. Chiedere quale degli otto elementi contribuisce di più al modulo di resistenza al ponte (8 e le lamiere di ponte, poi 6 se continua).")

# ---------------- 20 Glossario ----------------
def d20():
    o = [head('Italiano e inglese: i termini dei rapporti')]
    pairs = [('Chiglia piatta', 'Flat keel / keel plate'), ('Torello', 'Garboard strake'), ('Corso del ginocchio', 'Bilge strake'),
             ('Cinta', 'Sheer strake'), ('Trincarino', 'Deck stringer plate'), ('Paramezzale', 'Girder'), ('Madiere', 'Floor'),
             ('Ossatura / anello', 'Frame / web frame'), ('Baglio', 'Beam'), ('Mastra', 'Hatch coaming'),
             ('Zoccolo', 'Stool'), ('Cielo del doppio fondo', 'Inner bottom / tank top')]
    for i, (a, b) in enumerate(pairs):
        col, r_ = i // 6, i % 6
        x = 28 + col * 312; y = 64 + r_ * 62
        o.append(R(x, y, 298, 54, SOFTB if (r_ + col) % 2 == 0 else '#FFFFFF', LINE, 1, 6))
        o.append(T(x + 12, y + 23, a, 16, True, INK, maxw=274)); o.append(T(x + 12, y + 44, b, 15, False, BLUE, maxw=274, italic=True))
    o.append(T(333, 446, 'Elenco completo nel glossario della lezione', 14, False, GRAY, 'middle'))
    return ''.join(o)
add(E2, 'Glossario italiano–inglese',
    ['I rapporti di classe e ESP sono **in inglese**',
     'Stesso elemento, **due nomi**: usarli entrambi',
     'Attenzione a **frame** e **web frame**',
     'Elenco completo nel **glossario** della lezione'],
    'corrispondenze tra termini italiani e inglesi', d20(),
    "I rapporti della società di classifica, i rapporti di spessimetria e i questionari ESP sono in inglese; a bordo e nei documenti nazionali si usano i termini italiani. Far leggere le coppie a voce alta. Distinzioni da curare: frame (ossatura ordinaria) e web frame (anello rinforzato, primario); girder (paramezzale, nel doppio fondo; anguilla, sotto il ponte); floor (madiere) e non 'pavimento'; tank top e inner bottom sono sinonimi per il cielo del doppio fondo; stool è lo zoccolo della paratia corrugata; hatch coaming è la mastra, hatch cover il coperchio. Nel glossario allegato i termini sono raccolti con definizione breve, insieme alle sigle ESP e ai simboli della seconda parte.")

# ---------------- 21 Disegno della sezione maestra ----------------
def d21():
    o = [head('Che cosa si legge sul disegno (esempio fittizio)')]
    g = secgeo(80, 92, 260, 300)
    o.append(bc_section(g['x'], g['y'], g['w'], g['h'], cargo=None, hatch=True))
    x, y, xr, yb = g['x'], g['y'], g['xr'], g['yb']
    o.append(L(x - 10, y + 162, xr + 10, y + 162, GREEN, 2, '8 5'))
    notes_ = [(y - 4, 't 17,5 AH36', x + g['tw'] + 40, y + 4), (y + 70, 't 15,0 AH32', xr, y + 70),
              (y + 162, 'asse neutro 8,4 m dalla base', xr + 10, y + 162), (y + 228, 'ossature: passo 820 mm', xr - 18, y + 220),
              (yb - 16, 't 18,0 A · long. 300×12', xr - 60, yb - 4)]
    for ly, t, px, py in notes_:
        o.append(T(380, ly + 5, t, 15, True, BLUE)); o.append(L(376, ly, px, py, BLUE, 1.5)); o.append(C(px, py, 4, BLUE))
    o.append(tile(380, 396, 258, 52, 'Cartiglio', 'Z ponte, Z fondo, I, notazioni', 'n', 15, 14))
    return ''.join(o)
add(E5, 'Il disegno della sezione maestra',
    ['**Spessore e grado** di ogni corso e lamiera',
     '**Profili** dei rinforzi e passo delle ossature',
     '**Asse neutro**, I e Z, spesso nel cartiglio',
     'In ESP: piani con **spessori di rinnovo** a bordo'],
    'annotazioni tipiche di una sezione maestra', d21(),
    "La sezione maestra (midship section drawing) è il documento che traduce in numeri la terminologia della giornata: per ogni corso indica spessore e grado d'acciaio (es. 't 17,5 AH36'), per ogni rinforzo il profilo (es. bulbo o T con dimensioni), il passo delle ossature e dei longitudinali, e spesso nel cartiglio la posizione dell'asse neutro, il momento d'inerzia e i moduli di resistenza al ponte e al fondo, con le notazioni di classe. I valori della figura sono fittizi. Sulle navi CSR i piani riportano anche gli spessori netti o di rinnovo: l'ESP richiede a bordo, tra i documenti di supporto, i piani strutturali principali di stive e cisterne di zavorra con spessori di costruzione e di rinnovo. È il riferimento per leggere un rapporto di spessimetria: misurato contro rinnovo. Esercizio facoltativo: portare in aula la sezione maestra di una nave su cui si è navigato e ritrovare gli elementi.")

# ---------------- 22 Sintesi ----------------
def d22():
    o = [head('Sintesi e tre domande per la pausa')]
    sm = [('Sistema misto', 'fondo e ponte L, fianco T', 'b'), ('Gerarchia', 'lamiera, ordinari, primari', 'b'),
          ('Longitudinali', 'trave-scafo: I e Z', 'b'), ('Spessori', 'nuovo, netto, rinnovo', 'b')]
    bw = (610 - 14) / 2
    for i, (t, s, k) in enumerate(sm):
        o.append(tile(28 + (i % 2) * (bw + 14), 62 + (i // 2) * 82, bw, 70, t, s, k, 16, 14))
    qs = ['Quale elemento della sezione porta la maggior parte del taglio?',
          'Perché una paratia trasversale non entra nel calcolo di Z?',
          'Che cosa significa "corrosione sostanziale"?']
    for i, q in enumerate(qs):
        y = 242 + i * 64
        o.append(R(28, y, 610, 54, SOFTY, YEL, 2, 9)); o.append(T(44, y + 34, f'{i + 1}', 20, True, '#7A5200'))
        o.append(T(72, y + 33, q, 16, True, INK, maxw=552))
    return ''.join(o)
add('PARTE 1 · SINTESI', 'Sintesi della prima parte',
    ['Portarinfuse a **sistema misto**',
     'Elementi **trasversali**: forma e appoggi',
     'Elementi **longitudinali**: trave-scafo, I e Z',
     'Lo **spessore** misurato decide il rinnovo'],
    'sintesi e domande di richiamo', d22(),
    "Chiudere la prima parte con i quattro concetti e lasciare tre domande per la pausa; le risposte si danno alla ripresa (slide 23). Risposte attese: 1) il fianco (e le paratie longitudinali, dove ci sono): gli elementi verticali portano il taglio, come l'anima di una trave a doppio T; 2) perché è orientata trasversalmente: non è continua lungo la nave e non lavora a flessione longitudinale; serve da appoggio e da anello; 3) corrosione con spessore misurato tra lo spessore di rinnovo e il rinnovo + 0,5 mm (navi CSR), oppure oltre il 75 % del margine ammesso ma entro i limiti (altre navi). Ricordare l'orario: si riprende alle 10:40 con l'ESP.")
