import json, copy, importlib.util
from render import *
import p1, p2
def ld(n, p):
    s = importlib.util.spec_from_file_location(n, p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
c222 = ld('c222', '../work/c222.py'); wp1 = ld('work_p1', '../work/p1.py')
def reuse(sl, eyebrow, fixes=()):
    sl = copy.deepcopy(sl); sl['eyebrow'] = eyebrow
    for a, b in fixes:
        assert a in sl['notes'], a; sl['notes'] = sl['notes'].replace(a, b)
    return sl
F = 'PARTE 1 · FORME DI CORROSIONE'; D = 'PARTE 1 · DOVE E PERCHÉ'; P = 'PARTE 1 · PROTEZIONE'
A, B = p1.S, p2.S
part1 = [A['o'], A['r'], A['c'], A['g'], A['gb'], reuse(c222.S[1], F), A['i'], A['e'], A['m'], A['s'],
         reuse(c222.S[2], D), reuse(c222.S[3], D), A['imp'], A['hc'], A['cal'],
         reuse(c222.S[4], P, [('(slide precedente)', '(slide 12)'), ('(date di applicazione nel Ripasso)', '(navi contrattate dal 1° luglio 2006)')]),
         A['prep'], A['afs'], A['an'], A['iccp'], A['sint']]
w16 = reuse(wp1.S[16], 'PARTE 2 · MISURARE', [('Ripresa della U.D. 2.1.7 (CSR, spessore netto) con i criteri usati in servizio.', 'Spessori netti delle CSR e criteri usati in servizio (collegamento con la U.D. 4.1.1 B).')])
c7 = reuse(c222.S[7], 'PARTE 2 · CORROSIONE E FATICA', [(' Collegamento con la seconda parte: lo stesso ragionamento vale per la tensione di taglio nel fianco (slide 44).', '')])
for x in (w16, c7): x['dur'] = 5
part2 = [B['rip'], w16, B['mis'], B['riv'], B['vis'], B['iws'], B['prep'], B['stab'], B['lav'], B['assi'], B['tim'], B['prese'],
         B['pitt'], B['usc'], B['doc'], c7, B['pms'], B['c3'], B['c1'], B['es'], B['sol'], B['rias'], B['fine']]
total = 45
def hm(m): return f'{m//60:02d}:{m%60:02d}'
slides_html = []; notes = []
meta = dict(title='Corrosione, protezione e bacino', tsize=76, tlh=86,
            sub='Lezione 3 di 3 · forme di corrosione, corrosione negli impianti, protezione; misure, visite di classe e bacino di carenaggio', sub_top=600)
t = 8*60+30
slides_html.append(title_slide(meta, total, hm(t), hm(t+5))); notes.append("Min 0:00–0:05. U.D. 4.1.1 A, Materiali impiegati nella costruzione navale, lezione 3 di 3 (Corso Direttivo Macchina 54). Oggi: meccanismo elettrochimico e forme di corrosione, corrosione negli impianti di macchina (corrosione a freddo e a caldo, caldaie), protezione con pitture, antivegetative, anodi e corrente impressa; poi misura della corrosione, stato dei rivestimenti, visite di classe e bacino di carenaggio, con le domande d'esame C.1, C.3, C.4 e B.6–B.7. Struttura: prima parte 08:30–10:20, intervallo 20 minuti, seconda parte 10:40–12:30. Fonti: IACS UR Z e W vigenti al 30/10/2026, Rec. 46 e 74, CSR, SOLAS II-1/3-2 (PSPC), Convenzione AFS, Codice ISM; elenco nella slide 2. Gli schemi sono disegni originali; i numeri sono indicativi salvo dove è citata la fonte.")
t += 5; n = 2
for sl in part1:
    slides_html.append(content(sl, n, total, hm(t), hm(t+5))); notes.append(sl['notes']); t += 5; n += 1
assert t == 10*60+20 and n == 23, (hm(t), n)
slides_html.append(pause_slide('10:20', '10:40', 'Si riprende con misure, visite di classe e bacino')); notes.append('Intervallo di 20 minuti. Domande per la ripresa (slide sintesi): perché lo zinco protegge lo scafo, come si previene la corrosione a freddo, perché non si pitturano gli anodi. La lezione riprende alle 10:40 e chiude alle 12:30.')
t = 10*60+40
for sl in part2:
    d = sl['dur']
    slides_html.append(content(sl, n, total, hm(t), hm(t+d), dark=(n == total))); notes.append(sl['notes']); t += d; n += 1
assert t == 12*60+30 and n == total+1, (hm(t), n)
if __name__ == '__main__':
    warn = render_pngs(slides_html, 'png')
    print('WARN', len(warn)); [print(w) for w in warn]
    json.dump(notes, open('notes.json', 'w'))
