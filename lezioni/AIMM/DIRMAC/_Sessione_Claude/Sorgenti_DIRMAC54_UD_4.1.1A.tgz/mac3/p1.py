"""Lezione 3 (27/11/2026) · U.D. 4.1.1 A · corrosione e protezione · parte 1 (slide nuove; le riusate da COP63 si inseriscono in build.py)."""
from lib import *

S = {}
def add(key, eyebrow, title, bullets, caption, diagram, notes):
    S[key] = dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes)

E1 = 'PARTE 1 · INTRODUZIONE'
E2 = 'PARTE 1 · MECCANISMI'
E3 = 'PARTE 1 · FORME DI CORROSIONE'
E4 = 'PARTE 1 · IMPIANTI DI MACCHINA'
E5 = 'PARTE 1 · PROTEZIONE'

def d2():
    return programma_fonti(['08:30', '10:20', '10:40', '12:30'], [
        ('IACS UR Z10.2 · Z7', 'Rev.37 feb 2023 · Rev.29 Corr.1 2024'),
        ('IACS UR Z3 · Z21', 'carena Rev.8 2019 · assi Rev.4 2015'),
        ('IACS UR Z9 · Rec. 46', 'Rev.2 1996 · Rev.2 gen 2020'),
        ('CSR BC & OT (IACS)', 'ed. 1 luglio 2025 · Pt 1 Ch 3, Ch 9'),
        ('SOLAS II-1/3-2 (PSPC)', 'MSC.215(82)'),
        ('Convenzione AFS (IMO)', 'in vigore 2008 · cibutrina dal 2023'),
        ('Codice ISM', 'sezioni 9 e 10'),
        ('Domande d\'esame', 'Meccanica B.6–B.7, C.1–C.4')])
add('o', E1, 'Obiettivi, orario e fonti',
    ['Capire **perché** il metallo si corrode',
     'Riconoscere le **forme** di corrosione a bordo',
     'Scegliere la **protezione**: pitture, anodi, ICCP',
     'Sapere che cosa si fa in **bacino**'],
    'scansione oraria e fonti con la revisione usata', d2(),
    "Min 08:35. Terza e ultima lezione della U.D. 4.1.1 A. Prima parte: meccanismi e forme di corrosione, corrosione degli impianti di macchina (compresa la corrosione a caldo e a freddo dei motori, domande d'esame B.6 e B.7), protezione con pitture e protezione catodica. Seconda parte: misura della corrosione e stato dei rivestimenti, visite di classe, bacino di carenaggio (domanda C.1), manutenzione programmata (C.4), corrosione dello scafo (C.3). Alcune slide riprendono, adattate, la lezione sulla corrosione e la fatica (U.D. 2.2.2) del corso di coperta. Fonti: IACS UR Z10.2 Rev.37 (febbraio 2023) e UR Z7 Rev.29 Corr.1 (2024) per le visite e lo stato dei rivestimenti; UR Z3 (visita della carena, Rev.8 2019) e UR Z21 (visite degli assi portaelica, Rev.4 2015), da verificare sul testo vigente; UR Z9 Rev.2 (1996); Rec. 46 Rev.2 (2020); CSR edizione 1 luglio 2025, Pt 1 Ch 3 (margini di corrosione) e Ch 9 (fatica); SOLAS II-1/3-2 e risoluzione MSC.215(82) (PSPC); Convenzione AFS; Codice ISM.")

def d3():
    o = [head('Le tre lezioni della U.D. 4.1.1 A')]
    for i, (t, s, k) in enumerate([('13/11 · Acciai', 'gradi, prove, classi, certificati', 'n'), ('20/11 · Altri materiali', 'inox, ghise, alluminio, rame; saldatura e controlli', 'n'),
                                   ('27/11 · Oggi', 'corrosione, protezione, visite e bacino', 'r')]):
        o.append(tile(28, 62 + i * 104, 610, 90, t, s, k, 18, 15))
    o.append(callout(388, 'Filo comune: il materiale giusto, protetto e controllato', 'y', h=48, size=15))
    return ''.join(o)
add('r', E1, 'Da dove ripartiamo',
    ['Lezione 1: **acciai** da scafo',
     'Lezione 2: **altri materiali**, saldatura, controlli',
     'Oggi: **corrosione** e **bacino**',
     'Il materiale va anche **protetto**'],
    'collegamento con le lezioni precedenti', d3(),
    "Richiamo veloce: nella lezione 1 i gradi di acciaio, il fattore k, le classi di materiale, la marcatura e i certificati; nella lezione 2 inossidabili, ghise, alluminio, leghe di rame, non metallici, saldatura e controlli non distruttivi. Oggi la domanda è: come si conserva il materiale per 25 anni in mare? La risposta passa da tre cose: capire i meccanismi della corrosione, proteggere (pitture e protezione catodica), controllare (visite, spessimetrie, bacino).")

def d4():
    o = [head('La cella di corrosione')]
    o.append(R(60, 200, 540, 120, '#DCEBF3', BLUE, 2, 6)); o.append(T(330, 300, 'elettrolita: acqua di mare', 14, True, BLUE, 'middle'))
    o.append(R(120, 120, 70, 150, '#C9D6DE', HULL, 2, 2)); o.append(T(155, 110, 'ANODO', 15, True, RUST, 'middle'))
    o.append(R(470, 120, 70, 150, '#E9D8A6', YEL, 2, 2)); o.append(T(505, 110, 'CATODO', 15, True, BLUE, 'middle'))
    o.append(PATH('M 155 120 L 155 80 L 505 80 L 505 120', 'none', INK, 3)); o.append(A(300, 80, 360, 80, INK, 2.5, 8)); o.append(T(330, 70, 'elettroni e⁻', 14, True, INK, 'middle'))
    o.append(T(155, 290, 'Fe → Fe²⁺ + 2e⁻', 13, True, RUST, 'middle')); o.append(T(505, 290, 'O₂ + 2H₂O + 4e⁻ → 4OH⁻', 13, True, BLUE, 'middle'))
    o.append(A(200, 240, 450, 240, GRAY, 2, 8)); o.append(T(325, 232, 'ioni nell\'acqua', 13, False, GRAY, 'middle'))
    o.append(rows('', [('Servono', 'anodo, catodo, contatto elettrico, elettrolita', 'b'), ('Togli uno', 'e la corrosione si ferma: è il principio delle protezioni', 'g')], y0=340, rh=48, lw=120, size=14))
    return ''.join(o)
add('c', E2, 'Che cos\'è la corrosione',
    ['Una **reazione elettrochimica**',
     'All\'**anodo** il metallo si scioglie',
     'Al **catodo** si consuma ossigeno',
     'Serve un **elettrolita**: l\'acqua di mare'],
    'cella di corrosione schematica', d4(),
    "La corrosione in acqua è una reazione elettrochimica. All'anodo il ferro si ossida e passa in soluzione (Fe → Fe²⁺ + 2e⁻); gli elettroni attraversano il metallo verso il catodo, dove l'ossigeno disciolto si riduce (O₂ + 2H₂O + 4e⁻ → 4OH⁻); gli ioni si combinano e formano la ruggine. Servono quattro elementi: anodo, catodo, contatto elettrico tra i due, elettrolita. Anodo e catodo possono essere due metalli diversi (corrosione galvanica) o zone dello stesso pezzo con condizioni diverse (ossigeno, sollecitazioni, depositi, saldature). Ogni protezione toglie uno dei quattro elementi: la pittura separa il metallo dall'elettrolita, la protezione catodica rende l'intera struttura catodo, l'isolamento interrompe il contatto elettrico.")

def d5():
    items = [('magnesio', 1.6, RUST, '−1,6 V'), ('zinco', 1.03, RUST, '−1,03 V'), ('alluminio (leghe)', 0.85, YEL, '≈ −0,8/−0,9 V'), ('acciaio, ghisa', 0.62, YEL, '≈ −0,6 V'),
             ('bronzo Ni-Al', 0.2, BLUE, '≈ −0,2 V'), ('cupronichel 90/10', 0.25, BLUE, '≈ −0,25 V'), ('inox 316 passivo', 0.08, GREEN, '≈ −0,05/−0,1 V')]
    o = [hbars('Serie galvanica in acqua di mare (indicativa)', items, y0=60, maxv=1.7, vw=250, bh=30, gap=16, lw=190, size=14)]
    o.append(T(28, 400, '↑ meno nobili: si corrodono (anodi)', 14, True, RUST, maxw=610))
    o.append(T(28, 424, '↓ più nobili: protetti (catodi) · potenziali vs Ag/AgCl, valori indicativi', 13, False, GRAY, maxw=610))
    return ''.join(o)
add('g', E2, 'Serie galvanica in acqua di mare',
    ['I metalli si ordinano per **potenziale**',
     'Il meno nobile fa da **anodo** e si consuma',
     'Più sono **lontani**, più è forte la corrosione',
     'Conta anche il **rapporto delle aree**'],
    'potenziali di corrosione indicativi in acqua di mare', d5(),
    "La serie galvanica ordina i metalli secondo il potenziale che assumono in acqua di mare (valori indicativi rispetto a un elettrodo Ag/AgCl, da serie di letteratura come ASTM G82; variano con temperatura, velocità e composizione). Magnesio e zinco sono i meno nobili (si usano come anodi sacrificali), poi le leghe di alluminio, l'acciaio e la ghisa, quindi le leghe di rame, infine gli inossidabili passivi e il titanio. Due metalli diversi in contatto elettrico nello stesso elettrolita formano una pila: il meno nobile si corrode più rapidamente, il più nobile è protetto. Più è grande la differenza di potenziale e più è piccola l'area dell'anodo rispetto a quella del catodo, più rapida è la corrosione: una vite di acciaio in una piastra di bronzo sparisce in fretta; una vite di bronzo in una lamiera d'acciaio fa danni modesti.")

def d6():
    return rows('Corrosione galvanica a bordo', [
        ('Elica e scafo', 'elica in bronzo (catodo) e acciaio della poppa (anodo)', 'r'),
        ('Rimedio', 'anodi a poppa, contatto a terra dell\'asse, ICCP', 'g'),
        ('Alluminio e acciaio', 'sovrastrutture: giunti bimetallici, isolamento', 'r'),
        ('Tubi e flange', 'cupronichel su acciaio: pezzi di sacrificio, isolamento', 'r'),
        ('Casse di presa', 'anodi nelle prese a mare e nei filtri', 'g')], y0=62, lw=170, size=14)
add('gb', E2, 'Corrosione galvanica a bordo',
    ['**Elica** in bronzo e **poppa** in acciaio',
     '**Alluminio** su acciaio',
     '**Tubi** in lega di rame su acciaio',
     'Rimedi: **anodi**, isolamento, collegamenti a massa'],
    'coppie galvaniche tipiche a bordo e rimedi', d6(),
    "Coppie galvaniche tipiche. Elica in bronzo e scafo in acciaio: la zona poppiera, il timone e il dritto di poppa tendono a corrodersi; rimedi: anodi sacrificali a poppa e sul timone, protezione a corrente impressa, e il contatto strisciante a terra dell'asse portaelica (shaft earthing), che porta l'elica allo stesso potenziale dello scafo protetto e riduce anche le correnti attraverso i cuscinetti. Sovrastrutture in alluminio su ponti in acciaio: giunti bimetallici e isolamento (lezione 2). Tubolature in cupronichel o bronzo collegate a valvole o casse in acciaio: pezzi di sacrificio (spool) in acciaio o ferro dolce, giunti isolanti, anodi nelle casse di presa e nei filtri. Domanda per la classe: perché il problema si aggrava se la pittura sul bronzo è integra e quella sull'acciaio rovinata? (piccolo anodo esposto, grande catodo).")

def d8():
    return rows('Corrosione interstiziale e sotto deposito', [
        ('Dove', 'sotto guarnizioni, flange, rondelle, depositi, fanghi', 'b'),
        ('Perché', 'nella fessura manca ossigeno: diventa anodo', 'r'),
        ('Chi soffre', 'inossidabili e alluminio, che vivono di film passivo', 'r'),
        ('A bordo', 'scambiatori a piastre, casse di zavorra con fango, valvole', 'y'),
        ('Rimedi', 'pulizia, guarnizioni adatte, niente ristagni, PREN alto', 'g')], y0=62, lw=140, size=14)
add('i', E3, 'Fessure e depositi',
    ['Nelle **fessure** manca ossigeno',
     'La zona povera di ossigeno diventa **anodo**',
     'Colpisce **inox e alluminio**',
     'Prevenzione: **pulizia** e progetto'],
    'corrosione interstiziale e sotto deposito', d8(),
    "Corrosione interstiziale (crevice) e sotto deposito: in una fessura stretta (sotto una guarnizione, tra due lamiere, sotto una rondella) o sotto un deposito (fango, incrostazioni, residui di carico) l'ossigeno si esaurisce e non si rinnova; la zona diventa anodica rispetto alla superficie libera e l'ambiente nella fessura si acidifica. È tipica degli acciai inossidabili e delle leghe di alluminio, che dipendono dal film passivo; ma anche l'acciaio al carbonio si corrode sotto il fango delle casse di zavorra. A bordo: scambiatori a piastre con guarnizioni, flange di tubi d'acqua di mare, fondi di casse con sedimenti, pompe e valvole ferme. Rimedi: pulizia periodica e rimozione dei sedimenti, guarnizioni e materiali adatti (PREN alto per l'inox in acqua di mare, lezione 2), progetto senza fessure e ristagni.")

def d9():
    return rows('Erosione-corrosione e cavitazione (domanda C.2)', [
        ('Erosione-corrosione', 'acqua veloce o turbolenta asporta il film protettivo', 'r'),
        ('Dove', 'gomiti, ingressi dei tubi degli scambiatori, valvole parzialmente aperte', 'y'),
        ('Cavitazione', 'bolle di vapore che implodono vicino alla superficie', 'r'),
        ('Dove', 'eliche, giranti di pompe, camicie dei motori (lato acqua)', 'y'),
        ('Rimedi', 'velocità limitate, materiali adatti, pressione, inibitori', 'g')], y0=62, lw=170, size=14)
add('e', E3, 'Erosione-corrosione e cavitazione',
    ['Acqua troppo **veloce**: via il film protettivo',
     '**Cavitazione**: bolle che implodono',
     'Eliche, pompe, **camicie** dei motori',
     'Domanda d\'esame **C.2**'],
    'meccanismi e zone tipiche', d9(),
    "Erosione-corrosione: un flusso veloce o turbolento, magari con particelle o bolle d'aria, rimuove il film protettivo (ossidi, pellicola passiva) e il metallo si consuma rapidamente; tipica dei tubi in lega di rame oltre la velocità ammessa (indicativamente 2–3 m/s per il cupronichel 90/10, valore da verificare sulle specifiche), degli ingressi dei tubi negli scambiatori, dei gomiti stretti e delle valvole usate per laminare. Cavitazione (domanda d'esame C.2): dove la pressione locale scende sotto la tensione di vapore si formano bolle che implodono vicino alla superficie con microgetti ad altissima pressione; il metallo si butterà con aspetto spugnoso. Avviene sulle pale delle eliche, nelle giranti e nei corpi delle pompe (NPSH insufficiente), sul lato acqua delle camicie dei motori diesel per le vibrazioni della parete. Rimedi: progetto idrodinamico, NPSH adeguato, pressione del circuito, materiali resistenti (bronzo nichel-alluminio, inox), inibitori nell'acqua di raffreddamento dei motori.")

def d10():
    return rows('Corrosione microbiologica (MIC)', [
        ('Chi', 'batteri solfato-riduttori e altri microrganismi', 'b'),
        ('Dove', 'zavorre con fango, sentine, fondo delle casse di combustibile', 'b'),
        ('Effetto', 'pitting rapido e localizzato, odore di uova marce (H₂S)', 'r'),
        ('Combustibile', 'acqua sul fondo: fanghi, filtri intasati, corrosione', 'y'),
        ('Rimedi', 'drenare l\'acqua, pulire, biocidi, rivestimenti integri', 'g')], y0=62, lw=140, size=14)
add('m', E3, 'Corrosione microbiologica',
    ['**Batteri** che accelerano la corrosione',
     'Vivono dove c\'è **acqua ferma**',
     'Anche nel **combustibile** con acqua',
     'Rimedi: **drenare**, pulire, biocidi'],
    'corrosione microbiologica: dove e come', d10(),
    "La corrosione influenzata da microrganismi (MIC) è causata soprattutto da batteri solfato-riduttori che vivono senza ossigeno sotto depositi e fanghi: producono solfuri e acidi e generano crateri profondi e localizzati in tempi brevi. Si trova nelle casse di zavorra con fango, nelle sentine, nei tubi d'acqua di mare fermi, nel fondo delle casse di combustibile e di olio dove c'è acqua. Collegamento con la Funzione 1 (combustibili): la contaminazione microbiologica del combustibile ('fuel bugs') forma fanghi all'interfaccia acqua-combustibile, intasa filtri e separatori e corrode il fondo delle casse. Segni: odore di uova marce (idrogeno solforato, anche pericoloso per chi entra negli spazi chiusi), fanghi neri, crateri lucidi. Rimedi: drenare regolarmente l'acqua dalle casse, pulire, biocidi dove ammessi, rivestimenti integri.")

def d11():
    return rows('Corrosione e sollecitazioni', [
        ('Sotto sforzo (SCC)', 'tensione + ambiente specifico → cricche senza perdita di spessore', 'r'),
        ('Esempi', 'inox austenitici con cloruri caldi; ottoni con ammoniaca', 'y'),
        ('Fatica-corrosione', 'cicli di tensione in acqua di mare: vita più breve', 'r'),
        ('Esempi', 'assi portaelica senza protezione, braccioli in zavorra', 'y'),
        ('Rimedi', 'materiali adatti, rivestimenti, ridurre le tensioni', 'g')], y0=62, lw=170, size=14)
add('s', E3, 'Corrosione e sollecitazioni',
    ['**Sotto sforzo**: cricche in ambienti specifici',
     'Inox con **cloruri caldi**, ottoni con ammoniaca',
     '**Fatica-corrosione**: la vita si accorcia',
     'Collegamento con la **fatica** (lezione 1)'],
    'corrosione sotto sforzo e fatica-corrosione', d11(),
    "Corrosione sotto sforzo (stress corrosion cracking): combinazione di tensione (anche residua di saldatura o di lavorazione) e di un ambiente specifico per quel materiale; produce cricche fini, ramificate, senza perdita di spessore visibile. Esempi: acciai inossidabili austenitici con cloruri a temperatura superiore a circa 60 °C (tubi di scambiatori, serbatoi d'acqua calda), ottoni con ammoniaca (stagionatura). Fatica-corrosione: in un ambiente corrosivo la curva S-N si abbassa e non c'è un limite di fatica; esempi a bordo: assi portaelica con il rivestimento danneggiato nella zona bagnata, braccioli e longitudinali nelle casse di zavorra (le CSR considerano la vita a fatica in ambiente corrosivo dopo che il rivestimento ha perso efficacia; slide 38 della seconda parte). Rimedi: materiali adatti all'ambiente, rivestimenti e protezione catodica, riduzione delle tensioni (distensione, dettagli migliori).")

def d14():
    return rows('Corrosione negli impianti di macchina', [
        ('Acqua di mare', 'tubi, casse di presa, scambiatori: rame, rivestimenti, anodi', 'b'),
        ('Acqua dolce motori', 'inibitori (nitriti, borati), pH, cloruri controllati', 'g'),
        ('Gas di scarico', 'condense acide nei condotti freddi e nelle caldaie a recupero', 'r'),
        ('Olio lubrificante', 'acqua e acidi: corrosione dei cuscinetti, analisi periodiche', 'y'),
        ('Casse', 'acqua sul fondo, MIC, sedimenti: drenaggio e pulizia', 'y')], y0=62, lw=170, size=14)
add('imp', E4, 'Corrosione negli impianti',
    ['**Acqua di mare**: il circuito più aggressivo',
     'Acqua dolce: **inibitori** e analisi',
     'Scarichi e caldaie: **condense acide**',
     'Olio: **acqua** e acidità sotto controllo'],
    'dove si corrodono gli impianti di macchina', d14(),
    "Panoramica dei circuiti. Acqua di mare: il circuito più aggressivo; materiali in lega di rame o tubi rivestiti, anodi nelle casse di presa e nei refrigeranti, velocità controllate (erosione), filtri puliti. Acqua dolce di raffreddamento dei motori: trattata con inibitori (per esempio a base di nitriti e borati) secondo le specifiche del costruttore, con controllo periodico di concentrazione, pH e cloruri (i cloruri indicano ingresso d'acqua di mare). Gas di scarico: sotto il punto di rugiada acido i prodotti di combustione dello zolfo condensano acido solforico nei condotti, nei silenziatori, nelle caldaie a recupero e negli economizzatori. Olio lubrificante: acqua e acidi corrodono cuscinetti e perni; analisi periodiche (acqua, TBN, metalli). Casse: acqua sul fondo, fanghi e MIC. Collegamento con le unità di macchina del corso.")

def d15():
    o = [head('Corrosione a freddo e a caldo nei motori')]
    o.append(tile(28, 60, 298, 236, 'A freddo (cold)', 'camicie dei 2 tempi: acido solforico condensa sulla parete sotto il punto di rugiada. Basso carico, alta pressione, zolfo, camicia troppo fredda. Rimedi: olio cilindri con BN adatto e dosaggio corretto, temperatura delle camicie', 'b', 17, 14))
    o.append(tile(340, 60, 298, 236, 'A caldo (hot)', 'valvole di scarico, sedi, turbosoffiante: vanadio e sodio del combustibile formano sali che fondono a 500–650 °C e sciolgono gli ossidi protettivi. Rimedi: limitare Na (separatori), temperature, materiali resistenti', 'r', 17, 14))
    o.append(callout(318, 'Domande d\'esame Meccanica B.6 (hot) e B.7 (cold)', 'y', h=46, size=15))
    o.append(T(28, 400, 'combustibili 0,50 % S: olio cilindri a BN più basso', 14, True, INK, maxw=610))
    o.append(T(28, 424, 'valori e limiti: istruzioni del costruttore e ISO 8217', 13, False, GRAY, maxw=610))
    return ''.join(o)
add('hc', E4, 'Corrosione a freddo e a caldo',
    ['**Cold**: condense acide sulle camicie',
     'Pesa il **basso carico** dei motori moderni',
     '**Hot**: vanadio e sodio sulle valvole di scarico',
     'Rimedi: **lubrificazione**, temperature, combustibile'],
    'corrosione a freddo delle camicie e a caldo delle valvole', d15(),
    "Domande d'esame Meccanica B.6 e B.7. Corrosione a freddo (cold corrosion): nei motori a due tempi lenti l'ossido di zolfo dei gas di combustione, insieme all'acqua, condensa acido solforico sulla parete della camicia quando la sua temperatura scende sotto il punto di rugiada acido; il problema è cresciuto con i motori moderni a pressione di combustione elevata e con il funzionamento prolungato a basso carico (slow steaming). Segni: usura anomala della camicia con aspetto a 'pelle di tigre', depositi, analisi dell'olio di drenaggio (ferro, BN residuo). Rimedi: olio cilindri con BN adatto al tenore di zolfo e dosaggio corretto (con combustibili allo 0,50 % S si usano oli a BN più basso, ma con basso carico serve attenzione), temperatura delle camicie controllata (alcuni costruttori prevedono regolazione dell'acqua di raffreddamento delle camicie). Corrosione a caldo (hot corrosion): vanadio e sodio presenti nel combustibile residuo formano composti (vanadati di sodio) che fondono tra circa 500 e 650 °C, si depositano su valvole di scarico, sedi, palette del turbosoffiante e sciolgono gli ossidi protettivi. Rimedi: limitare il sodio (che viene in gran parte con l'acqua, rimossa dai separatori), rispettare i limiti di vanadio della ISO 8217, temperature dei gas e delle valvole controllate, materiali resistenti (leghe di nichel, riporti duri), rotazione delle valvole. Valori indicativi: fanno fede le istruzioni del costruttore.")

def d16():
    return rows('Corrosione in caldaia', [
        ('Ossigeno', 'pitting nei tubi e nel corpo: degasare l\'acqua', 'r'),
        ('pH', 'acqua di caldaia alcalina controllata, condense neutralizzate', 'b'),
        ('Sali e durezza', 'depositi → surriscaldamento e corrosione sotto deposito', 'y'),
        ('Fragilità caustica', 'soda concentrata in fessure: cricche', 'r'),
        ('Lato fumi', 'zolfo: corrosione a bassa temperatura negli economizzatori', 'y')], y0=62, lw=170, size=14)
add('cal', E4, 'Corrosione in caldaia',
    ['**Ossigeno** disciolto: pitting',
     'Acqua **alcalina** e trattata',
     '**Depositi**: surriscaldamento e corrosione',
     'Analisi giornaliere dell\'**acqua di caldaia**'],
    'forme di corrosione nelle caldaie e prevenzione', d16(),
    "Lato acqua: l'ossigeno disciolto provoca pitting nei tubi e nei corpi cilindrici; si rimuove con il degasatore e con sequestranti dell'ossigeno chimici. L'acqua di caldaia si mantiene alcalina entro i valori del fabbricante del trattamento; le condense si neutralizzano con ammine. Sali e durezza formano depositi che isolano i tubi (surriscaldamento, rotture) e favoriscono la corrosione sotto deposito; si controllano con analisi giornaliere (cloruri, alcalinità, fosfati, conducibilità) e spurghi. La fragilità caustica nasce dove la soda si concentra in fessure (giunti mandrinati, perdite). Lato fumi: con combustibili solforati si ha corrosione a bassa temperatura negli economizzatori e nei preriscaldatori d'aria, e incrostazioni di vanadio sui surriscaldatori (corrosione a caldo). Valori di controllo: secondo le istruzioni del costruttore e del fornitore dei prodotti.")

def d18():
    return rows('Preparazione delle superfici', [
        ('Pulizia', 'olio, grasso e sali solubili via prima della sabbiatura', 'b'),
        ('Sabbiatura', 'grado Sa 2½ (ISO 8501-1) e rugosità per l\'adesione', 'b'),
        ('Condizioni', 'acciaio almeno 3 °C sopra il punto di rugiada, umidità controllata', 'y'),
        ('Spessori', 'film secco misurato; PSPC zavorre: 320 µm nominali', 'g'),
        ('Registro', 'condizioni e controlli annotati nel file tecnico del rivestimento', 'n')], y0=62, lw=140, size=14)
add('prep', E5, 'Preparazione delle superfici',
    ['La pittura vale quanto la **preparazione**',
     'Sabbiatura **Sa 2½**, niente sali',
     'Acciaio **sopra il punto di rugiada**',
     'Spessori **misurati** e registrati'],
    'requisiti tipici per applicare un rivestimento', d18(),
    "La durata di un rivestimento dipende soprattutto dalla preparazione. Sgrassare e lavare i sali solubili (i cloruri sotto la pittura causano bolle e distacchi); sabbiare fino al grado Sa 2½ della ISO 8501-1 (metallo quasi bianco) con il profilo di rugosità richiesto dal fabbricante; applicare con acciaio almeno 3 °C sopra il punto di rugiada e umidità relativa entro i limiti (spesso non oltre 85 %); misurare gli spessori del film secco. Per le cisterne di zavorra il PSPC (risoluzione MSC.215(82), reso obbligatorio da SOLAS II-1/3-2) fissa tra l'altro un sistema epossidico con spessore nominale del film secco di 320 µm (regola 90/10: il 90 % delle misure almeno al nominale, il resto non sotto il 90 %), sali solubili non oltre 50 mg/m² come NaCl, ispezioni da parte di ispettori qualificati e un file tecnico del rivestimento (CTF) che resta a bordo. Valori da verificare sul testo della risoluzione per la nave specifica.")

def d19():
    return rows('Antivegetative (Convenzione AFS)', [
        ('Perché', 'la vegetazione aumenta resistenza, consumo e emissioni', 'b'),
        ('Vietati', 'composti organostannici (TBT); dal 2023 anche la cibutrina', 'r'),
        ('Certificato', 'IAFS per le navi di 400 GT e oltre', 'y'),
        ('Tipi', 'a rilascio controllato, autolevigante, antiaderenti (silicone)', 'g'),
        ('Bacino', 'scelta del ciclo secondo velocità, servizio, intervallo', 'n')], y0=62, lw=140, size=14)
add('afs', E5, 'Antivegetative',
    ['La carena sporca costa **combustibile**',
     '**TBT** vietato; dal 2023 anche la **cibutrina**',
     'Certificato **IAFS** (Convenzione AFS)',
     'Ciclo scelto per **velocità e servizio**'],
    'pitture antivegetative e regole AFS', d19(),
    "Le incrostazioni biologiche (alghe, cirripedi) aumentano la resistenza al moto, quindi il consumo e le emissioni (collegamento con 'resistenza e consumo di combustibile' della Funzione 4 e con gli indici di efficienza). La Convenzione internazionale sul controllo dei sistemi antivegetativi nocivi (AFS 2001, in vigore dal 17 settembre 2008) vieta i composti organostannici (TBT); con la risoluzione MEPC.331(76) il divieto è stato esteso alla cibutrina dal 1° gennaio 2023. Le navi di 400 GT e oltre in viaggi internazionali hanno il certificato internazionale del sistema antivegetativo (IAFS); quelle più piccole una dichiarazione. Tipi: pitture a rilascio controllato, autoleviganti (self-polishing), antiaderenti a base di silicone (fouling release) per navi veloci. La scelta del ciclo dipende da velocità, tempo di sosta, intervallo previsto tra i bacini. Date e riferimenti da verificare sul testo IMO.")

def d20():
    o = [head('Protezione catodica con anodi sacrificali')]
    o.append(L(40, 120, 600, 120, '#7FA9C2', 2, '6 4')); o.append(T(46, 112, 'galleggiamento', 12, False, GRAY))
    o.append(P([(40, 130), (520, 130), (600, 170), (600, 250), (40, 250)], '#C9D6DE', HULL, 2))
    for x, y in [(120, 240), (240, 240), (360, 240), (480, 230), (560, 200)]:
        o.append(R(x - 18, y - 8, 36, 12, ORANGE, RUST, 1.5, 3))
    o.append(T(330, 280, 'anodi di zinco o alluminio saldati sulla carena', 14, True, RUST, 'middle'))
    o.append(rows('', [('Principio', 'l\'anodo si consuma al posto dell\'acciaio', 'g'), ('Materiali', 'zinco o alluminio in mare; magnesio in acqua dolce', 'b'),
                       ('Controllo', 'consumo degli anodi, mai pitturarli', 'y')], y0=300, rh=44, lw=120, size=14))
    return ''.join(o)
add('an', E5, 'Anodi sacrificali',
    ['L\'anodo è il metallo **meno nobile**',
     '**Zinco** o **alluminio** in acqua di mare',
     'Si **consumano**: vanno sostituiti in bacino',
     'Mai **pitturare** un anodo'],
    'protezione con anodi sacrificali, schema', d20(),
    "Protezione catodica galvanica: blocchi di metallo meno nobile dell'acciaio (zinco o leghe di alluminio in acqua di mare; magnesio solo in acqua dolce o salmastra, perché in mare si consuma troppo in fretta) sono collegati elettricamente allo scafo e si consumano al suo posto, portandolo a un potenziale protetto (per l'acciaio in acqua di mare indicativamente −0,80 V rispetto ad Ag/AgCl o più negativo). Dove si trovano: carena, poppa vicino all'elica, timone, casse di presa, prese e filtri, cisterne di zavorra (in quest'ultime non sempre ammessi o limitati: per le petroliere ci sono restrizioni su materiale e altezza degli anodi per il rischio di scintille in caso di caduta, secondo i regolamenti di classe). Si dimensionano per un intervallo tra i bacini; in bacino si misura il consumo e si sostituiscono quelli consumati oltre la soglia; non vanno mai pitturati. Il consumo anomalo di un anodo indica un problema (vernice danneggiata vicina, corrente vagante).")

def d21():
    o = [head('Protezione a corrente impressa (ICCP)')]
    o.append(P([(40, 120), (520, 120), (600, 160), (600, 240), (40, 240)], '#C9D6DE', HULL, 2))
    o.append(R(180, 228, 50, 14, '#2F2F2F', None, 0, 3)); o.append(C(205, 235, 32, 'none', YEL, 2)); o.append(T(205, 290, 'anodo + schermo', 13, True, INK, 'middle'))
    o.append(R(400, 230, 22, 12, BLUE, None, 0, 3)); o.append(T(411, 290, 'elettrodo di riferimento', 13, True, BLUE, 'middle'))
    o.append(R(280, 150, 90, 44, INK, None, 0, 6)); o.append(T(325, 177, 'regolatore', 13, True, '#fff', 'middle'))
    o.append(L(300, 194, 205, 228, RUST, 2)); o.append(L(350, 194, 411, 230, BLUE, 2))
    o.append(R(530, 140, 50, 14, STEEL, INK, 1, 2)); o.append(T(555, 134, 'messa a terra asse', 12, True, INK, 'middle'))
    o.append(rows('', [('Principio', 'corrente continua da anodi inerti allo scafo', 'b'), ('Controllo', 'regolata sul potenziale misurato', 'g'),
                       ('Attenzione', 'sovraprotezione: distacco della pittura, idrogeno', 'r')], y0=310, rh=44, lw=120, size=14))
    return ''.join(o)
add('iccp', E5, 'Corrente impressa (ICCP)',
    ['**Anodi inerti** alimentati in corrente continua',
     'Il regolatore segue gli **elettrodi di riferimento**',
     'Si adatta a velocità, acqua, **pittura**',
     'Troppa corrente: **sovraprotezione**'],
    'sistema a corrente impressa, schema', d21(),
    "Nella protezione a corrente impressa un raddrizzatore invia corrente continua dagli anodi (inerti: titanio platinato o con ossidi misti) attraverso l'acqua di mare allo scafo, che diventa catodo. Elettrodi di riferimento (argento-cloruro d'argento o zinco) misurano il potenziale e il regolatore adatta la corrente alle condizioni (velocità, temperatura e salinità dell'acqua, stato della pittura). Intorno agli anodi c'è uno schermo dielettrico che evita correnti troppo alte sulla carena vicina. Il contatto strisciante a terra dell'asse portaelica include l'elica nel sistema. Rischi: sovraprotezione (potenziale troppo negativo, indicativamente oltre −1,05/−1,10 V Ag/AgCl) con distacco della pittura per sviluppo di idrogeno e possibile infragilimento degli acciai ad alta resistenza; sottoprotezione se il sistema è spento (per esempio in bacino o con guasti). A bordo: registrare giornalmente corrente e potenziali, verificare gli allarmi, spegnere secondo procedura quando ci sono sommozzatori in acqua.")

def d22():
    o = [head('Sintesi e tre domande per la pausa')]
    sm = [('Meccanismo', 'anodo, catodo, elettrolita, contatto', 'b'), ('Forme', 'galvanica, pitting, fessure, erosione, MIC', 'r'),
          ('Impianti', 'acqua di mare, cold e hot, caldaie', 'r'), ('Protezione', 'pitture, anodi, ICCP', 'g')]
    bw = (610 - 14) / 2
    for i, (t, s, k) in enumerate(sm):
        o.append(tile(28 + (i % 2) * (bw + 14), 62 + (i // 2) * 82, bw, 70, t, s, k, 16, 14))
    qs = ['Perché un anodo di zinco protegge la carena?', 'Che cos\'è la cold corrosion e come si previene?', 'Perché non si pittura un anodo sacrificale?']
    for i, q in enumerate(qs):
        y = 242 + i * 64
        o.append(R(28, y, 610, 54, SOFTY, YEL, 2, 9)); o.append(T(44, y + 34, f'{i + 1}', 20, True, '#7A5200'))
        o.append(T(72, y + 33, q, 16, True, INK, maxw=552))
    return ''.join(o)
add('sint', 'PARTE 1 · SINTESI', 'Sintesi della prima parte',
    ['La corrosione è una **pila**',
     'Molte **forme**, un meccanismo',
     'Impianti: **acqua di mare**, motori, caldaie',
     'Protezione: **isolare** o **rendere catodo**'],
    'sintesi e domande di richiamo', d22(),
    "Chiudere la prima parte e lasciare tre domande; risposte alla ripresa (slide 23). Risposte attese: 1) perché lo zinco è meno nobile dell'acciaio: collegato allo scafo diventa anodo e si consuma, mentre lo scafo diventa catodo e non si corrode; 2) la condensazione di acido solforico sulle camicie dei motori a due tempi sotto il punto di rugiada acido, favorita da basso carico e pressioni alte; si previene con olio cilindri di BN adatto, dosaggio corretto e temperatura delle camicie controllata; 3) perché la pittura lo isola dall'acqua: l'anodo non scambia più corrente e lo scafo resta senza protezione.")
