"""Lezione 3 (27/11/2026) · U.D. 4.1.1 A · misura, visite e bacino · parte 2 (slide nuove)."""
from lib import *

S = {}
def add(key, eyebrow, title, bullets, caption, diagram, notes, dur=5):
    S[key] = dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes, dur=dur)

E6 = 'PARTE 2 · MISURARE'
E7 = 'PARTE 2 · VISITE'
E8 = 'PARTE 2 · BACINO'
E9 = 'PARTE 2 · VERIFICA'

def d23():
    o = [head('Risposte e programma della seconda parte')]
    ans = [('1', 'lo zinco fa da anodo'), ('2', 'olio BN e temperatura'), ('3', 'la pittura lo isola')]
    for i, (n, a) in enumerate(ans):
        x = 28 + i * 206
        o.append(R(x, 62, 196, 70, SOFTG, GREEN, 2, 9)); o.append(T(x + 14, 90, f'Domanda {n}', 14, True, GRAY))
        o.append(T(x + 14, 116, a, 14, True, GREEN, maxw=172))
    blocks = [('Misurare', 'spessori, rivestimenti', 'b'), ('Visite', 'classe, carena, assi', 'b'), ('Bacino', 'preparazione, lavori, uscita', 'r'), ('Verifica', 'domande C.1, C.3, C.4, esercizio', 'r')]
    for i, (t, s, k) in enumerate(blocks):
        x = 28 + (i % 2) * 312; y = 160 + (i // 2) * 130
        o.append(tile(x, y, 298, 112, t, s, k))
    return ''.join(o)
add('rip', 'PARTE 2 · RIPRESA', 'Ripresa: risposte e programma',
    ['Risposte alle **tre domande** della pausa',
     '**Misurare** la corrosione',
     '**Visite** di classe e della carena',
     'Il **bacino**, passo per passo'],
    'risposte di richiamo e blocchi della seconda parte', d23(),
    "Verificare le risposte: 1) lo zinco, meno nobile, diventa anodo e si consuma; lo scafo diventa catodo; 2) cold corrosion: acido solforico che condensa sulla camicia sotto il punto di rugiada acido; olio cilindri con BN adatto, dosaggio, temperatura delle camicie; 3) la pittura isola l'anodo dall'acqua e interrompe la protezione. Seconda parte: misurare la corrosione e lo stato dei rivestimenti, visite di classe, bacino di carenaggio, manutenzione programmata e domande d'esame.", dur=4)

def d25():
    return grid('Corrosioni locali: criteri per navi CSR (UR Z10.2, §8)', ['Forma', 'Misura', 'Minimo accettabile'], [
        ('Pitting > 15 % (fianco)', 'cinque crateri più profondi', '75 % (ossature) · 70 % (fasciame)'),
        ('Pitting < 20 % (altro)', 'ogni misura', 'min [0,7 (t − t vol), t ren − 1]'),
        ('Corrosione ai bordi', 'flange e bordi liberi', 'min [0,7 (t − t vol), t ren − 1]'),
        ('Solchi (grooving)', 'larghezza ≤ 15 % dell\'anima', 'min [0,75 (t − t vol), t ren − 0,5]')],
        [28, 230, 400], y0=62, rh=70, size=14)
add('mis', E6, 'Misurare la corrosione',
    ['Spessimetria a **ultrasuoni** (lezione 2)',
     'Media dello spessore e **corrosioni locali**',
     'Criteri diversi per **pitting, bordi, solchi**',
     'Sotto il minimo: **rinnovo**'],
    'criteri della UR Z10.2 per le corrosioni locali', d25(),
    "Richiamo della slide precedente (spessori) e della lezione 2 (ultrasuoni). Per le navi costruite con le CSR la UR Z10.2 Rev.37, paragrafo 8, dà criteri per le corrosioni locali: nelle strutture del fianco, con intensità di pitting oltre il 15 %, si pulisce un'area di almeno 300 mm e si misurano i cinque crateri più profondi; il residuo minimo è il 75 % dello spessore di costruzione nelle anime e flange di ossature e braccioli e il 70 % nel fasciame attaccato (entro 30 mm da ciascun lato), senza superare lo spessore di rinnovo. Nelle altre strutture, con pitting sotto il 20 %, ogni misura deve rispettare il minore tra 0,7 (t costruzione − t aggiunta volontaria) e t rinnovo − 1 mm; lo stesso per la corrosione ai bordi; per i solchi (larghezza fino al 15 % dell'altezza dell'anima, massimo 30 mm) il minore tra 0,75 (t − t vol) e t rinnovo − 0,5 mm. Per le navi non CSR valgono i criteri della società. La lettura dei rapporti di spessimetria è una competenza del direttore di macchina in bacino.")

def d26():
    o = [grid('Stato del rivestimento (UR Z10.2, 1.2.13)', ['Stato', 'Definizione'], [
        ('GOOD', 'solo piccole macchie di ruggine'), ('FAIR', 'distacchi ai bordi e alle saldature, o ruggine leggera su ≥ 20 %'),
        ('POOR', 'distacco generale su ≥ 20 % o scaglie dure su ≥ 10 %')], [28, 140], y0=62, rh=60, size=15, fills=[SOFTG, SOFTY, SOFTR])]
    o.append(R(28, 316, 610, 112, SOFTB, BLUE, 2, 10))
    o.append(T(44, 346, 'Conseguenza (UR Z7, cisterne di zavorra):', 15, True, BLUE, maxw=580))
    o.append(T(44, 372, 'rivestimento POOR, molle o assente → esame', 14, False, INK, maxw=580))
    o.append(T(44, 396, 'anche alle visite annuali, e spesso spessimetria', 14, False, INK, maxw=580))
    return ''.join(o)
add('riv', E6, 'Stato del rivestimento',
    ['Tre giudizi: **GOOD, FAIR, POOR**',
     'Si valuta a ogni **visita**',
     'POOR in zavorra: **visite annuali** in più',
     'Il rivestimento decide i **costi** di classe'],
    'definizioni dello stato del rivestimento e conseguenze', d26(),
    "IACS UR Z10.2 Rev.37, paragrafo 1.2.13: GOOD = solo piccole macchie di ruggine; FAIR = distacchi locali ai bordi dei rinforzi e alle saldature e/o ruggine leggera sul 20 % o più dell'area, ma meno che POOR; POOR = distacco generale del rivestimento sul 20 % o più, oppure scaglie dure sul 10 % o più dell'area considerata. Conseguenza per tutte le navi (UR Z7 Rev.29, paragrafo 2.2 e 4.2): nelle cisterne di zavorra in cui il rivestimento duro è POOR, o è molle o semiduro, o non c'è, l'esame si estende alle visite annuali (con misure di spessore se richiesto); lo stesso vale se si trova corrosione sostanziale. Per l'armatore un rivestimento mantenuto GOOD significa meno visite e meno riparazioni: è un argomento economico, oltre che di sicurezza.")

def d27():
    o = [head('Ciclo di visite di classe (5 anni)')]
    X0, W5 = 60, 540
    o.append(L(X0, 150, X0 + W5, 150, INK, 3))
    for y in range(6):
        x = X0 + y * W5 / 5
        o.append(L(x, 140, x, 160, INK, 2)); o.append(T(x, 182, f'{y}', 14, True, INK, 'middle'))
    for y in range(1, 5):
        x = X0 + y * W5 / 5
        o.append(C(x, 120, 9, BLUE));
    o.append(T(X0 + 1 * W5 / 5, 100, 'annuale', 12, True, BLUE, 'middle'))
    o.append(R(X0 + 2 * W5 / 5 - 8, 70, W5 / 5 + 16, 26, SOFTY, YEL, 1.5, 6)); o.append(T(X0 + 2.5 * W5 / 5, 88, 'intermedia (2ª o 3ª)', 12, True, '#7A5200', 'middle'))
    o.append(R(X0 + 5 * W5 / 5 - 40, 104, 80, 32, RUST, None, 0, 6)); o.append(T(X0 + W5, 125, 'rinnovo', 13, True, '#fff', 'middle'))
    o.append(R(X0 + 2.5 * W5 / 5 - 40, 196, 80, 26, SOFTB, BLUE, 1.5, 6)); o.append(T(X0 + 2.5 * W5 / 5, 214, 'carena', 12, True, BLUE, 'middle'))
    o.append(R(X0 + 5 * W5 / 5 - 40, 196, 80, 26, SOFTB, BLUE, 1.5, 6)); o.append(T(X0 + W5, 214, 'carena', 12, True, BLUE, 'middle'))
    o.append(T(X0 + W5 / 2, 248, 'anni dalla classificazione o dall\'ultimo rinnovo', 13, False, GRAY, 'middle'))
    o.append(rows('', [('Annuale', 'entro 3 mesi prima o dopo la data anniversaria', 'b'), ('Carena', 'due visite in 5 anni, intervallo massimo 36 mesi', 'b'),
                       ('Rinnovo', 'ogni 5 anni: rinnova il certificato di classe', 'r')], y0=270, rh=52, lw=120, size=14))
    return ''.join(o)
add('vis', E7, 'Le visite di classe',
    ['**Annuale**, intermedia, **rinnovo** ogni 5 anni',
     '**Carena**: due volte in 5 anni',
     'Massimo **36 mesi** tra due visite della carena',
     'Visite **statutarie** armonizzate'],
    'ciclo quinquennale delle visite di classe', d27(),
    "IACS UR Z7 Rev.29 Corr.1 (2024), visite di classificazione dello scafo: visita di rinnovo (special survey) ogni 5 anni, che rinnova il periodo di classe (2.1); visite annuali entro 3 mesi prima o dopo ogni data anniversaria (paragrafo 3); visita intermedia al posto della seconda o della terza annuale, con estensioni secondo età e tipo di nave (paragrafo 4). La visita della carena (outside of the ship's bottom, UR Z3) si fa due volte nel periodo di 5 anni, una delle quali in occasione del rinnovo, con un intervallo massimo di 36 mesi tra due visite; per le navi di passeggeri le regole di bandiera possono chiedere intervalli più brevi. Le visite statutarie SOLAS seguono lo stesso calendario armonizzato (HSSC). Gli assi portaelica hanno un proprio ciclo (UR Z21) secondo il tipo di lubrificazione e di monitoraggio. Verificare UR Z3 e Z21 sul testo vigente.")

def d28():
    return rows('Visita della carena: in bacino o in acqua', [
        ('In bacino', 'nave all\'asciutto: carena, eliche, timone, prese, assi', 'b'),
        ('In acqua (IWS)', 'sommozzatori con video, in alternanza, se approvato', 'g'),
        ('Condizioni IWS', 'nave idonea, pittura di lunga durata, età, visibilità', 'y'),
        ('Non sostituisce', 'riparazioni che richiedono la nave all\'asciutto', 'r')], y0=62, lw=150, size=15)
add('iws', E7, 'Carena: bacino o visita in acqua',
    ['Una visita su due può essere **in acqua**',
     'Con **sommozzatori** e video, ditta approvata',
     'Serve l\'**approvazione** della classe',
     'Il rinnovo di norma richiede il **bacino**'],
    'alternative per la visita della carena', d28(),
    "La visita della carena si fa normalmente in bacino di carenaggio o su scalo. Le società di classifica ammettono, per una delle due visite del quinquennio (o con regole specifiche per alcune navi), la visita in acqua (in-water survey, IWS) eseguita da una ditta di sommozzatori approvata con video e comunicazione con l'ispettore, purché la nave abbia i requisiti previsti (per esempio rivestimento della carena di lunga durata, marcature per l'orientamento, età e condizioni, acqua sufficientemente limpida). Riparazioni che richiedono la nave all'asciutto, smontaggio delle eliche o degli assi, e di norma la visita di rinnovo restano in bacino. I requisiti dettagliati sono nei regolamenti di ogni società e nella UR Z3: verificarli per la nave specifica.", dur=4)

def d29():
    return vflow('Preparare il bacino', [('Lista lavori', 'visite di classe, manutenzione, riparazioni, modifiche'), ('Specifica', 'richiesta al cantiere: quantità, superfici, materiali'),
                 ('Piano di invasatura', 'docking plan al cantiere: taccate, prese, sporgenze'), ('Nave', 'assetto, stabilità, casse, carico, ricambi'),
                 ('Contratto', 'tempi, prezzi, sicurezza, responsabilità')], colors=[BLUE, BLUE, RUST, YEL, STEEL])
add('prep', E8, 'Preparare il bacino',
    ['La **lista lavori** si scrive mesi prima',
     '**Specifica** chiara per il cantiere',
     '**Piano di invasatura** e dati della nave',
     'Ricambi e materiali **pronti**'],
    'fasi di preparazione di un bacino', d29(),
    "La preparazione inizia mesi prima e coinvolge comandante, direttore di macchina e ufficio tecnico. Lista lavori: visite di classe e statutarie in scadenza (carena, assi, timone, prese a mare, cisterne), manutenzioni del PMS che richiedono la nave all'asciutto, riparazioni di danni e non conformità aperte, modifiche (per esempio impianti di trattamento delle acque di zavorra). Specifica per il cantiere con quantità e superfici (metri quadri di carena, numero di valvole, anodi), materiali e pitture (scheda del fabbricante). Piano di invasatura (docking plan) con posizione delle taccate rispetto a chiglia, prese a mare, sonde, trasduttori, anodi ICCP, alette, così che nessuna taccata cada su una presa. Nave: assetto e stabilità per l'entrata (slide seguente), casse vuote o piene senza superfici libere, carico o zavorra secondo le istruzioni. Contratto: tempi, prezzi unitari, lavori extra, sicurezza (permessi di lavoro a caldo e spazi chiusi del cantiere).")

def d30():
    o = [head('Entrare in bacino: il momento critico')]
    o.append(L(60, 300, 600, 300, INK, 4));
    for x in range(104, 560, 64):
        o.append(R(x, 286, 34, 14, SAND, INK, 1, 2))
    o.append(P([(90, 160), (560, 160), (590, 220), (580, 284), (110, 284), (80, 220)], '#C9D6DE', HULL, 2))
    o.append(A(330, 330, 330, 290, RUST, 3, 9)); o.append(T(342, 336, 'reazione P delle taccate', 14, True, RUST))
    o.append(R(28, 352, 610, 78, SOFTY, YEL, 2, 10))
    o.append(T(44, 380, 'Perdita di altezza metacentrica ≈ P · KM / Δ', 16, True, '#7A5200', maxw=580))
    o.append(T(44, 406, 'critica quando la chiglia appoggia per tutta la lunghezza', 14, False, INK, maxw=580))
    o.append(T(80, 140, 'assetto leggermente appoppato, GM positivo, niente superfici libere', 13, True, INK, maxw=520))
    return ''.join(o)
add('stab', E8, 'Entrata in bacino e stabilità',
    ['Mentre l\'acqua scende, le taccate **spingono**',
     'La spinta P **riduce** l\'altezza metacentrica',
     'Momento critico: chiglia **tutta appoggiata**',
     'GM positivo e **niente superfici libere**'],
    'reazione delle taccate e stabilità all\'appoggio', d30(),
    "Collegamento con la U.D. 4.1.1 C (stabilità). Durante il prosciugamento del bacino, appena la chiglia tocca le taccate (di solito prima a poppa, con un leggero appoppamento), nasce una reazione P verso l'alto sulla chiglia che cresce mentre il livello scende. È come togliere peso nel punto più basso della nave: l'altezza metacentrica effettiva si riduce di circa P · KM / Δ (formulazione della 'perdita virtuale' di GM). Il momento più critico è quando la chiglia appoggia per tutta la lunghezza, subito prima che le taccate laterali e i puntelli entrino in azione: se GM diventa negativo la nave può sbandare sulle taccate. Precauzioni: assetto modesto e concordato con il cantiere, GM sufficiente, casse piene o vuote (niente superfici libere), nessun movimento di pesi durante l'operazione, comunicazioni con il capo bacino. Valutazioni numeriche nella 4.1.1 C.")

def d31():
    return grid('Lavori tipici in bacino', ['Zona', 'Lavori'], [
        ('Carena', 'lavaggio, ispezione, sabbiatura locale o totale, pittura'), ('Anodi e ICCP', 'misura del consumo, sostituzione, verifica di anodi e riferimenti'),
        ('Eliche', 'ispezione, cricche (PT), lucidatura, prova di serraggio'), ('Linea d\'assi', 'abbassamento, tenute, eventualmente sfilamento'),
        ('Timone', 'giochi di perni e cuscinetti, tenute, eventuale smontaggio'), ('Prese a mare', 'apertura, pulizia, anodi, valvole, griglie'),
        ('Fasciame', 'spessimetria, riparazioni, marche di pescaggio')], [28, 200], y0=58, rh=48, size=14)
add('lav', E8, 'Lavori tipici in bacino',
    ['**Carena**: lavaggio, ispezione, pittura',
     '**Eliche, assi, timone**: misure e controlli',
     '**Prese a mare** e valvole aperte',
     '**Anodi** e spessimetria'],
    'principali lavori di bacino per zona', d31(),
    "Elenco tipico dei lavori in bacino, da adattare alla nave e alla lista lavori. Carena: lavaggio ad alta pressione appena all'asciutto (prima che le incrostazioni secchino), ispezione con l'ispettore, sabbiatura locale (spot) o totale, ciclo di pittura (slide 35). Anodi e ICCP: misura del consumo, sostituzione, controllo degli anodi e degli elettrodi di riferimento a corrente impressa. Eliche: ispezione delle pale, liquidi penetranti nelle zone critiche (lezione 2), riparazione dei danni da cavitazione o da urto, lucidatura. Linea d'assi e timone: slide seguenti. Prese a mare e valvole di fasciame: apertura, pulizia, sostituzione degli anodi nelle casse di presa, revisione o sostituzione delle valvole (che restano accessibili solo all'asciutto). Fasciame: spessimetria se prevista, riparazioni, ripasso delle marche di pescaggio e del bordo libero.")

def d32():
    return rows('Linea d\'assi e tenute', [
        ('Abbassamento', 'misura del gioco dell\'astuccio (poker gauge): usura dei cuscinetti', 'b'),
        ('Tenute', 'tenuta poppiera e prodiera: perdite di olio, sostituzione', 'r'),
        ('Visita assi', 'con sfilamento o modificata, secondo UR Z21 e la classe', 'y'),
        ('Monitoraggio', 'analisi dell\'olio dell\'astuccio, temperature, registri', 'g'),
        ('Ambiente', 'oli dell\'astuccio a basso impatto (EAL) in alcune zone', 'n')], y0=62, lw=150, size=14)
add('assi', E8, 'Linea d\'assi e tenute',
    ['Misura dell\'**abbassamento** dell\'asse',
     'Controllo delle **tenute** dell\'astuccio',
     '**Sfilamento** solo quando serve',
     'Il **monitoraggio** dell\'olio allunga gli intervalli'],
    'controlli della linea d\'assi in bacino', d32(),
    "In bacino si misura l'abbassamento (weardown) dell'asse portaelica nell'astuccio con il calibro dedicato (poker gauge) da un punto di riferimento sul mozzo o sulla tenuta: la differenza rispetto alla misura precedente indica l'usura del cuscinetto poppiero. Si ispezionano e, se necessario, si sostituiscono gli anelli della tenuta poppiera; si verificano la tenuta prodiera e le perdite. La visita degli assi portaelica (sfilamento completo, visita modificata, visita parziale o rinvio con monitoraggio delle condizioni) segue la UR Z21 e il regolamento della classe secondo il tipo di lubrificazione (olio o acqua) e i dati di monitoraggio: analisi periodiche dell'olio dell'astuccio (acqua, metalli), temperature dei cuscinetti, consumo di olio. In alcune zone (per esempio acque statunitensi con il VGP o il suo successore) si usano lubrificanti a basso impatto ambientale. Verificare i requisiti sul testo vigente della Z21.")

def d33():
    return rows('Timone', [
        ('Giochi', 'cuscinetti dei perni (agugliotti) e del collo: misura e confronto', 'b'),
        ('Gioco di sollevamento', 'spazio tra timone e fermo: il timone non deve sfilarsi', 'b'),
        ('Ispezione', 'lamiere, saldature, anodi, cricche alle sedi dei perni', 'r'),
        ('Smontaggio', 'se i giochi superano i limiti del costruttore o della classe', 'y'),
        ('Prove', 'dopo i lavori: angolo, tempi da banda a banda in mare', 'g')], y0=62, lw=170, size=14)
add('tim', E8, 'Il timone',
    ['Misura dei **giochi** dei cuscinetti',
     'Controllo del **sollevamento**',
     'Cricche e **anodi** sul timone',
     'Oltre i limiti: **smontaggio**'],
    'controlli del timone in bacino', d33(),
    "Controlli del timone: giochi tra agugliotti e boccole e tra asse e cuscinetto del collo, misurati con spessimetri a lamelle e confrontati con i valori precedenti e con i limiti del costruttore o della classe; gioco di sollevamento (jumping clearance) tra timone e arresto, che impedisce al timone di sollevarsi e sfilarsi; ispezione di lamiere e saldature (cricche alle sedi dei perni e alle aperture di ispezione), stato degli anodi, tappi di drenaggio. Se i giochi superano i limiti si smontano e si rifanno boccole o perni (materiali della lezione 1 e 2: fucinati saldabili, bronzi o materiali sintetici per le boccole). Dopo i lavori: prove della timoneria (tempi da 35° a una banda a 30° all'altra, SOLAS II-1/29) in mare. Collegamento con la domanda d'esame sulle timonerie elettroidrauliche.")

def d34():
    return rows('Prese a mare e valvole di fasciame', [
        ('Apertura', 'casse di presa e griglie aperte, pulizia, ispezione', 'b'),
        ('Valvole', 'revisione o sostituzione: sono accessibili solo all\'asciutto', 'r'),
        ('Anodi', 'nelle casse di presa e nei filtri', 'g'),
        ('Spessori', 'casse di presa e tubi corti: corrosione rapida', 'y'),
        ('Sistemi', 'antivegetativi delle prese (rame, cloro): controllo', 'n')], y0=62, lw=140, size=14)
add('prese', E8, 'Prese a mare e valvole',
    ['Valvole di fasciame: **revisione** all\'asciutto',
     'Casse di presa **pulite** e ispezionate',
     '**Anodi** e sistemi antivegetativi',
     'Una valvola che perde è un rischio di **allagamento**'],
    'lavori su prese a mare e valvole di fasciame', d34(),
    "Le valvole di presa e di scarico a mare e le casse di presa si possono aprire solo con la nave all'asciutto (o con tappi subacquei in casi particolari): il bacino è l'occasione per aprirle, pulirle, ispezionarle e revisionarle o sostituirle, insieme alle griglie. Le casse di presa e i tronchetti tra fasciame e valvola sono zone di corrosione rapida (acqua di mare, turbolenza, coppie galvaniche): si misurano gli spessori e si sostituiscono gli anodi delle casse. Si controllano i sistemi antivegetativi delle prese (anodi di rame, elettroclorazione). Le valvole di fasciame sono parte della tenuta stagna della nave e oggetto della visita di classe: una valvola o un tronchetto che cede è una via d'acqua difficile da controllare.", dur=4)

def d35():
    return vflow('Pitturazione della carena', [('Lavaggio', 'alta pressione appena all\'asciutto'), ('Ispezione', 'stato del ciclo, distacchi, corrosione'),
                 ('Preparazione', 'sabbiatura locale o totale, pulizia, sali'), ('Applicazione', 'anticorrosivo, legante, antivegetativa; spessori misurati'),
                 ('Tempi', 'essiccazione e ricopertura prima dell\'allagamento')], colors=[BLUE, BLUE, YEL, RUST, GREEN])
add('pitt', E8, 'Pitturazione della carena',
    ['Il ciclo lo decide la **scheda tecnica**',
     '**Condizioni** ambientali registrate',
     'Spessori **misurati**',
     'Rispettare i tempi di **essiccazione**'],
    'sequenza della pitturazione della carena', d35(),
    "Sequenza: lavaggio ad alta pressione appena la carena è all'asciutto; ispezione con il rappresentante del fornitore di pitture; preparazione (sabbiatura locale dei punti corrosi o sabbiatura totale, pulizia, controllo dei sali); applicazione del ciclo: primer anticorrosivo epossidico, mano di legame (tie coat) e antivegetativa conforme alla Convenzione AFS, con spessori secondo la scheda tecnica; rispetto dei tempi di essiccazione e di ricopertura prima di riallagare il bacino. Le condizioni ambientali (temperatura dell'acciaio, punto di rugiada, umidità) e gli spessori si registrano: in caso di difetti precoci (distacchi, bolle) sono la base per la garanzia. Attenzione a non pitturare anodi, elettrodi ICCP e trasduttori, e a ripassare le marche di pescaggio.")

def d36():
    return vflow('Uscire dal bacino', [('Verifiche', 'prese chiuse, tappi rimessi, anodi e trasduttori a posto'), ('Allagamento', 'controllo di vie d\'acqua appena l\'acqua sale'),
                 ('Galleggiamento', 'assetto e stabilità come all\'entrata'), ('Prove', 'macchina, eliche, timone, ICCP accesa'), ('Documenti', 'rapporti, certificati, aggiornamento PMS')],
                 colors=[RUST, RUST, YEL, BLUE, GREEN])
add('usc', E8, 'Uscita dal bacino',
    ['**Tappi** di fondo rimessi e verificati',
     'Controllo **vie d\'acqua** durante l\'allagamento',
     '**Prove** di macchina e timone',
     '**Documenti** e certificati in ordine'],
    'controlli prima e dopo l\'uscita dal bacino', d36(),
    "Prima di allagare: verificare con il cantiere che tutti i tappi delle casse di fondo siano rimessi (con la firma del responsabile), le valvole di fasciame montate e chiuse, anodi, trasduttori ed elettrodi ICCP a posto e non pitturati, griglie delle prese montate. Durante l'allagamento: personale in macchina e nei locali bassi per controllare vie d'acqua da valvole, tenute dell'asse, tappi; condizioni di stabilità come all'entrata. Dopo l'uscita: accensione dell'ICCP, prove di macchina, verifica della tenuta dell'astuccio, prova della timoneria, eventuale prova in mare. Documenti: rapporti di visita della classe, certificati aggiornati, rapporti di spessimetria e di pittura, aggiornamento del PMS e dei registri di manutenzione.")

def d37():
    return rows('Documenti dopo il bacino', [
        ('Classe', 'rapporto di visita, eventuali condizioni o raccomandazioni', 'r'),
        ('Statutari', 'certificati aggiornati (carena, IAFS se si cambia antivegetativa)', 'y'),
        ('Rapporti tecnici', 'spessimetria, pitture, misure di assi e timone', 'b'),
        ('PMS', 'lavori registrati, nuove scadenze, ricambi usati', 'g'),
        ('ISM', 'non conformità chiuse, lezioni apprese', 'n')], y0=62, lw=150, size=14)
add('doc', E8, 'Documenti e registrazioni',
    ['Rapporto di **classe** e condizioni',
     'Certificati **statutari** aggiornati',
     'Misure di **assi e timone** archiviate',
     'Tutto nel **PMS** e nel sistema ISM'],
    'documentazione da conservare dopo il bacino', d37(),
    "Dopo il bacino il direttore di macchina verifica che la documentazione sia completa: rapporto di visita della classe con eventuali condizioni (da chiudere entro la scadenza) o raccomandazioni; certificati statutari aggiornati e, se si è cambiato il sistema antivegetativo, il certificato IAFS o la sua appendice; rapporti tecnici (spessimetrie, schede e rapporti delle pitture con spessori e condizioni, abbassamento dell'asse, giochi del timone) archiviati per confronto al bacino successivo; lavori registrati nel sistema di manutenzione programmata con le nuove scadenze; eventuali non conformità chiuse nel sistema ISM (sezioni 9 e 10). Queste registrazioni sono quelle che l'ispettore chiede alle visite successive e che dimostrano la manutenzione richiesta dal Codice ISM.")

def d39():
    o = [head('Manutenzione: programmata o su condizione (C.4)')]
    o.append(tile(28, 60, 298, 210, 'Programmata (planned)', 'a intervalli fissi di ore o di tempo, secondo il costruttore e la classe. Semplice da gestire; a volte smonta ciò che è in buono stato', 'b', 17, 14))
    o.append(tile(340, 60, 298, 210, 'Su condizione (condition based)', 'si interviene quando le misure lo indicano: vibrazioni, analisi dell\'olio, temperature, termografia, spessori. Meno lavori inutili; serve un sistema di misura', 'g', 17, 14))
    o.append(callout(292, 'Codice ISM, sezione 10: manutenzione documentata', 'y', h=46, size=15))
    o.append(T(28, 380, 'Rec. 74 IACS: guida alla gestione della manutenzione', 14, True, INK, maxw=610))
    o.append(T(28, 404, 'la classe può accettare schemi di visita continua', 14, False, GRAY, maxw=610))
    o.append(T(28, 428, 'e di monitoraggio delle condizioni', 14, False, GRAY, maxw=610))
    return ''.join(o)
add('pms', 'PARTE 2 · MANUTENZIONE', 'Manutenzione programmata',
    ['**Programmata**: a ore o a calendario',
     '**Su condizione**: secondo le misure',
     'Il **PMS** registra entrambe',
     'Domanda d\'esame **C.4**'],
    'manutenzione programmata e su condizione', d39(),
    "Domanda d'esame C.4: 'Il candidato parli del Planned Maintenance System spiegando differenza tra manutenzioni PLANNED e CONDITION BASED'. Il Codice ISM, sezione 10, chiede che la compagnia stabilisca procedure perché la nave sia mantenuta conforme alle regole: ispezioni a intervalli appropriati, segnalazione delle non conformità con le cause, azioni correttive, registrazioni. Il sistema di manutenzione programmata (PMS) è lo strumento: elenca macchinari e strutture, lavori, intervalli, ricambi e registrazioni. Manutenzione programmata: a intervalli fissi di ore di moto o di tempo. Su condizione: si interviene quando le misure (vibrazioni, analisi dell'olio, temperature, prestazioni, termografia, spessori) indicano un degrado. La guida IACS Rec. 74 (A Guide to Managing Maintenance) descrive i principi; le società di classifica accettano schemi di visita continua delle macchine e di monitoraggio delle condizioni collegati al PMS. Per la corrosione: lo stato dei rivestimenti e gli spessori sono 'condizioni' da monitorare.", dur=4)

def d40():
    return rows('Domanda C.3: corrosione dello scafo', [
        ('1. Meccanismo', 'cella elettrochimica: anodo, catodo, acqua di mare', 'b'),
        ('2. Forme', 'generale, pitting, bordi, solchi, galvanica, MIC', 'b'),
        ('3. Dove', 'stive, zavorre, carena, poppa: margini CSR', 'r'),
        ('4. Protezione', 'rivestimenti (PSPC, Z9), anodi, ICCP, antivegetative', 'g'),
        ('5. Controllo', 'visite, GOOD/FAIR/POOR, spessimetria, rinnovo', 'y')], y0=62, lw=150, size=14)
add('c3', 'PARTE 2 · VERIFICA', 'Domanda d\'esame C.3 svolta',
    ['Parti dal **meccanismo**',
     'Elenca le **forme** con un esempio',
     'Dì **dove** e **come** si protegge',
     'Chiudi con il **controllo** della classe'],
    'traccia di risposta alla domanda C.3', d40(),
    "Traccia di risposta per 'Il candidato parli della corrosione dello scafo' (Meccanica C.3), circa 5 minuti all'orale: 1) meccanismo elettrochimico; 2) forme con esempio di bordo (pitting nel fondo delle zavorre, solchi lungo le saldature, galvanica a poppa, MIC sotto i fanghi); 3) zone a rischio e margini di corrosione delle regole; 4) protezione: rivestimenti (PSPC per le zavorre, UR Z9 per le stive delle portarinfuse), anodi e corrente impressa, antivegetative (AFS); 5) controllo: visite di classe, stato GOOD/FAIR/POOR, spessimetria, criteri di rinnovo, riparazioni con materiale dello stesso grado (lezione 1).")

def d41():
    return rows('Domanda C.1: le operazioni in bacino', [
        ('1. Prima', 'lista lavori, specifica, piano di invasatura, contratto', 'b'),
        ('2. Entrata', 'assetto, stabilità all\'appoggio, casse, comunicazioni', 'r'),
        ('3. Lavori', 'carena, anodi, eliche, assi, timone, prese, spessori', 'g'),
        ('4. Sicurezza', 'permessi, lavori a caldo, spazi chiusi, tappi', 'y'),
        ('5. Uscita', 'verifiche, allagamento, prove, documenti', 'b')], y0=62, lw=150, size=14)
add('c1', 'PARTE 2 · VERIFICA', 'Domanda d\'esame C.1 svolta',
    ['Una risposta in **cinque tempi**',
     'Prima, entrata, lavori, sicurezza, uscita',
     'Citare la **stabilità** all\'appoggio',
     'E i **documenti** finali'],
    'traccia di risposta alla domanda C.1', d41(),
    "Traccia per 'Il candidato parli delle operazioni che vengono compiute durante un bacino' (Meccanica C.1). Seguire la cronologia delle slide 29–37: preparazione (lista lavori, specifica, piano di invasatura), entrata (assetto, stabilità al momento dell'appoggio, casse senza superfici libere), lavori (carena, anodi, eliche, linea d'assi e tenute, timone, prese a mare e valvole, spessimetria, pitture), sicurezza (permessi di lavoro a caldo e di ingresso negli spazi chiusi del cantiere, controllo dei tappi), uscita (verifiche, allagamento controllato, prove, documenti). Un esempio concreto vissuto dal candidato rende la risposta più convincente.")

def d42():
    o = [head('Esercizio: la lista lavori')]
    o.append(R(28, 62, 610, 150, SOFTB, BLUE, 2, 10))
    for i, t in enumerate(['Portarinfuse di 12 anni, bacino per la visita di rinnovo.', 'Ultimo bacino 30 mesi fa. Note di bordo:', '• anodi di poppa consumati al 90 % in 2 anni',
                           '• perdita d\'olio dalla tenuta poppiera', '• zavorre di prora con rivestimento FAIR', '• valvola di presa dell\'acqua di mare che trafila']):
        o.append(T(44, 92 + i * 22, t, 14, i < 2, INK, maxw=580))
    qs = ['Scrivi la lista dei lavori principali', 'Che cosa ti dice il consumo degli anodi?', 'Che cosa chiedi alla classe?']
    for i, q in enumerate(qs):
        y = 230 + i * 70
        o.append(R(28, y, 610, 58, SOFTY, YEL, 2, 9)); o.append(T(46, y + 36, str(i + 1), 20, True, '#7A5200'))
        o.append(T(76, y + 35, q, 16, True, INK, maxw=548))
    return ''.join(o)
add('es', 'PARTE 2 · VERIFICA', 'Esercizio: la lista lavori',
    ['Un caso **realistico**',
     'Usare **tutte e tre** le lezioni',
     'A coppie, **5 minuti**',
     'Soluzione nella **slide seguente**'],
    'caso pratico per preparare una lista lavori', d42(),
    "Caso inventato ma tipico. Far scrivere la lista lavori a coppie; poi discutere. Soluzione nella slide seguente.")

def d43():
    return grid('Soluzione', ['Voce', 'Lavori e motivi'], [
        ('Visite', 'rinnovo di classe e carena; spessimetria secondo età; zavorre'), ('Anodi', 'sostituirli; consumo alto: verificare pittura e messa a terra dell\'asse'),
        ('Tenuta poppiera', 'abbassamento dell\'asse, revisione o sostituzione degli anelli'), ('Zavorre FAIR', 'ritocchi o rifacimento locale per evitare il POOR'),
        ('Valvola di presa', 'revisione o sostituzione all\'asciutto, tronchetto misurato'), ('Carena', 'lavaggio, ispezione, ciclo antivegetativo AFS')],
        [28, 200], y0=58, rh=56, size=14)
add('sol', 'PARTE 2 · VERIFICA', 'Soluzione dell\'esercizio',
    ['Le **visite** decidono il minimo',
     'Le **anomalie** di bordo il resto',
     'Anodi consumati: **cerca la causa**',
     'FAIR oggi è **POOR** domani'],
    'lista lavori commentata', d43(),
    "Soluzione commentata. Visite: visita di rinnovo (scafo, macchine, carena), con l'estensione delle spessimetrie prevista per l'età e il tipo di nave (per le portarinfuse il programma ESP, U.D. di coperta). Anodi: un consumo del 90 % in due anni è anomalo: verificare danni estesi alla pittura vicino a poppa, il funzionamento del contatto a terra dell'asse, eventuali correnti vaganti da apparecchiature o da cantiere, la presenza di ICCP spenta. Tenuta poppiera: misura dell'abbassamento, ispezione e sostituzione degli anelli di tenuta; valutare l'analisi dell'olio. Zavorre con rivestimento FAIR: ritocchi e riparazioni locali ora costano poco ed evitano che diventi POOR (con visite annuali aggiuntive). Valvola di presa: revisione o sostituzione, misura dello spessore del tronchetto e della cassa. Carena: lavaggio, ispezione, ciclo antivegetativo. Alla classe: concordare l'estensione della visita, il piano di spessimetria, l'ispezione delle eliche e del timone, la chiusura di eventuali raccomandazioni aperte.")

def d44():
    return grid('La U.D. 4.1.1 A in una pagina', ['Lezione', 'Idee chiave', 'Riferimenti'], [
        ('1 · Acciai', 'gradi, k, classi, certificati', 'UR W11, CSR'),
        ('2 · Altri', 'inox, ghise, Al, Cu; saldatura, CND', 'UR W, Rec. 47'),
        ('3 · Corrosione', 'forme, protezione, bacino', 'UR Z, PSPC, AFS')], [28, 190, 450], y0=62, rh=80, size=15)
add('rias', 'PARTE 2 · RIEPILOGO', 'La U.D. in una pagina',
    ['**Scegliere** il materiale',
     '**Unirlo** e controllarlo',
     '**Proteggerlo** e verificarlo',
     'Tre lezioni, **un filo**'],
    'riepilogo delle tre lezioni', d44(),
    "Riepilogo delle tre lezioni della U.D. 4.1.1 A per il ripasso d'esame: scegliere il materiale (gradi e proprietà), unirlo e controllarlo (saldatura e controlli non distruttivi), proteggerlo e verificarlo nel tempo (corrosione, rivestimenti, protezione catodica, visite, bacino). Le domande d'esame collegate sono Meccanica C.1, C.2, C.3, C.4, C.5, C.14 e B.6–B.7.", dur=4)

def d45():
    o = [head('Tre idee da portare a bordo')]
    ideas = [('La corrosione è una pila', 'togli un elemento e si ferma'), ('Proteggere costa meno che riparare', 'rivestimenti, anodi, ICCP mantenuti'),
             ('Il bacino si prepara a bordo', 'lista lavori, misure, documenti')]
    for i, (t, s) in enumerate(ideas):
        y = 70 + i * 116
        o.append(C(60, y + 40, 22, RUST)); o.append(T(60, y + 47, str(i + 1), 20, True, '#fff', 'middle'))
        o.append(R(100, y, 538, 84, '#F6F4EE', LINE, 1.5, 10)); o.append(T(118, y + 34, t, 18, True, INK, maxw=500)); o.append(T(118, y + 62, s, 15, False, GRAY, maxw=500))
    o.append(T(333, 440, 'Fine della U.D. 4.1.1 A · segue la 4.1.1 B', 14, True, BLUE, 'middle', maxw=600))
    return ''.join(o)
add('fine', 'PARTE 2 · SINTESI', 'Sintesi della lezione',
    ['Corrosione: **meccanismo** e forme',
     'Protezione: **pitture**, anodi, ICCP',
     'Controllo: **visite** e bacino',
     'Domande d\'esame: **C.1, C.3, C.4**, B.6–B.7'],
    'le tre idee chiave della lezione', d45(),
    "Chiusura della U.D. 4.1.1 A. Riprendere le tre idee e indicare il collegamento con la U.D. 4.1.1 B (principi fondamentali della costruzione navale) e con la 4.1.1 C (assetto e stabilità, anche in bacino). Ricordare ai corsisti i materiali di ripasso: le tabelle riepilogative di ciascuna lezione, il glossario e le sigle della U.D.")
