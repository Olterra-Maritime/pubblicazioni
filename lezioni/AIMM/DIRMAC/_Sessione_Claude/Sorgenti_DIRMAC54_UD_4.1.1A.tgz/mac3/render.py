"""Template slide + rendering (PNG per slide, PDF vettoriale, PPTX con note)."""
import re, html, os, sys
from lib import *
UD = 'U.D. 4.1.1 A'
LESSON = '08:30–12:30'
HD = f'<div class="hd">Accademia Italiana della Marina Mercantile · Corso Direttivo Macchina 54 · {UD}</div>'
LIC = 'https://creativecommons.org/licenses/by-nc-sa/4.0/deed.it'
UDF = 'U.D. 4.1.1 A · lezione 3'  # etichetta breve per il piede
DATA_LUNGA = 'Venerdì 27 novembre 2026'  # data della lezione dal calendario Accademia Genova
DATA_BREVE = '27/11/2026'
DL = DATA_LUNGA + ' · ' if DATA_LUNGA else 'Lezione '
DB = DATA_BREVE + ' · ' if DATA_BREVE else ''
CR = f'<div class="cr">© 2026 ing. Pietro Lauro 6497A-GE. Quest\'opera è distribuita con licenza CC BY-NC-SA 4.0 (<a href="{LIC}">{LIC}</a>).</div>'

FONTS = """
@font-face{font-family:Oswald;font-weight:600;src:url(fonts/oswald-latin-600-normal.woff2)}
@font-face{font-family:PS;font-weight:400;src:url(fonts/public-sans-latin-400-normal.woff2)}
@font-face{font-family:PS;font-weight:500;src:url(fonts/public-sans-latin-500-normal.woff2)}
@font-face{font-family:PS;font-weight:600;src:url(fonts/public-sans-latin-600-normal.woff2)}
"""
CSS = FONTS + """
@page{size:2000px 1125px;margin:0}
*{box-sizing:border-box;margin:0;padding:0}
body{background:#fff}
.s{position:relative;width:2000px;height:1125px;overflow:hidden;font-family:PS,sans-serif;page-break-after:always;break-after:page}
.s.light{background:#F4F1EA;color:#16222B}
.s.dark{background:#0F2A3D;color:#F4F1EA}
.eb{position:absolute;left:134px;top:164px;font-size:26.7px;line-height:26.7px;font-weight:600;letter-spacing:.12em;white-space:nowrap}
.light .eb{color:#A8450F}.dark .eb{color:#F0A15F}
h1{position:absolute;left:134px;top:302px;font-family:Oswald;font-weight:600;font-size:66.6px;line-height:78px;white-space:nowrap}
ul{position:absolute;left:134px;top:468px;width:860px;list-style:none;font-size:39px;line-height:54px}
li{position:relative;padding-left:44px}
li::before{content:"";position:absolute;left:14px;top:21px;width:12px;height:12px;border-radius:50%;background:currentColor}
.dark ul{color:#E6ECEF}
strong{font-weight:600}
.card{position:absolute;left:1034px;top:384px;width:833px;height:572px;background:#fff;border:2px solid #E3DDD2;border-radius:24px;overflow:hidden}
.card svg{display:block;width:833px;height:572px;margin:-2px 0 0 -2px}
.cap{position:absolute;left:1034px;top:968px;width:833px;font-size:27px;line-height:32px;color:#5E6B73}
.dark .cap{color:#9FB3BD}
.ft{position:absolute;left:134px;top:1004px;font-size:25px;line-height:30px;color:#5E6B73;white-space:nowrap}
.dark .ft{color:#9FB3BD}
.hd{position:absolute;left:134px;top:72px;font-size:22px;line-height:26px;font-weight:500;letter-spacing:.03em;white-space:nowrap}
.light .hd{color:#5E6B73}.dark .hd{color:#9FB3BD}
.cr{position:absolute;left:134px;top:1060px;font-size:18.5px;line-height:24px;white-space:nowrap}
.light .cr{color:#5E6B73}.dark .cr{color:#9FB3BD}
.cr a{color:inherit;text-decoration:none}
"""

def md(s):
    s = html.escape(s, quote=False).replace('n. 1', 'n.\u00a01')
    return re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)

def content(sl, n, total, t0, t1, dark=False):
    cls = 'dark' if dark else 'light'
    lis = ''.join(f'<li>{md(b)}</li>' for b in sl['bullets'])
    return (f'<div class="s {cls}">{HD}<div class="eb">{html.escape(sl["eyebrow"])}</div>'
            f'<h1>{html.escape(sl["title"])}</h1><ul>{lis}</ul>'
            f'<div class="card">{sl["diagram"]}</div>'
            f'<div class="cap">Schema originale: {html.escape(sl["caption"])}</div>'
            f'<div class="ft">{UDF} · {DB}{t0}–{t1} · {n}/{total}</div>{CR}</div>')

def title_art():
    o = []
    o.append(R(0, 0, 917, 1125, '#123349', None, 0, 0))
    o.append(R(0, 783, 917, 342, SEA, None, 0, 0))
    o.append(C(677, 222, 123, '#1A4560'))
    # nave
    ysd = 674
    o.append(P([(60, ysd), (850, ysd), (815, 783), (122, 783)], '#24506B', '#9FB3BD', 3))
    for i in range(5):
        hx = 150 + i * 118
        o.append(R(hx, 646, 106, 28, '#2E6B8A', '#9FB3BD', 2, 0))
    # cumulo di carico sul boccaporto di sinistra e nastro
    # shiploader: torre + braccio sulla stiva 2
    o.append(R(40, 470, 20, 204, '#9FB3BD', None, 0, 2))
    o.append(R(10, 664, 80, 10, '#9FB3BD', None, 0, 0))
    o.append(L(50, 475, 262, 560, ORANGE, 9))
    o.append(L(50, 475, 120, 420, ORANGE, 7))
    o.append(L(120, 420, 262, 560, ORANGE, 3))
    o.append(P([(250, 548), (278, 548), (284, 564), (244, 564)], '#C9D4DA', None, 0))
    for k, (dx, dy) in enumerate([(0, 0), (6, 26), (-5, 46), (3, 66), (-2, 84)]):
        o.append(R(259 + dx - 5, 572 + dy, 10, 12, SAND, None, 0, 2))
    o.append(P([(215, 646), (303, 646), (280, 616), (238, 616)], SAND, None, 0))
    # sovrastruttura
    o.append(R(718, 570, 132, 104, '#2E6B8A', '#9FB3BD', 3, 0))
    for wx in (736, 776, 816):
        o.append(R(wx, 592, 28, 20, '#D9E8EF', None, 0, 2))
    o.append(R(768, 512, 38, 60, RUST, ORANGE, 3, 0))
    # onde
    for (x, y, w) in [(30, 835, 260), (310, 880, 250), (110, 935, 250), (560, 985, 250), (260, 1030, 250)]:
        o.append(PATH(f'M{x} {y} q{w/4} -14 {w/2} 0 t{w/2} 0', stroke='#1D4663', sw=4))
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="917" height="1125" viewBox="0 0 917 1125">{"".join(o)}</svg>'

def title_slide(meta, total, t0, t1):
    return (f'<div class="s dark">'
            f'<div style="position:absolute;left:1083px;top:0">{title_art()}</div>'
            f'<div style="position:absolute;left:134px;top:162px;font-size:25.4px;line-height:28px;font-weight:600;letter-spacing:.12em;color:#F0A15F;white-space:nowrap">ACCADEMIA ITALIANA DELLA MARINA MERCANTILE</div>'
            f'<div style="position:absolute;left:134px;top:258px;font-size:29.3px;line-height:34px;color:#9FB3BD;white-space:nowrap">Corso Direttivo Macchina 54 · {UD}</div>'
            f'<div style="position:absolute;left:134px;top:366px;width:900px;font-family:Oswald;font-weight:600;font-size:{meta["tsize"]}px;line-height:{meta["tlh"]}px;color:#F4F1EA">{html.escape(meta["title"])}</div>'
            f'<div style="position:absolute;left:134px;top:{meta["sub_top"]}px;width:900px;font-size:36px;line-height:50px;color:#D9E2E6">{html.escape(meta["sub"])}</div>'
            + (f'<div style="position:absolute;left:134px;top:966px;font-size:29px;line-height:34px;color:#F0A15F;font-weight:600;white-space:nowrap">{DATA_LUNGA}</div>' if DATA_LUNGA else '')
            + f'<div style="position:absolute;left:134px;top:1010px;font-size:29px;line-height:34px;color:#9FB3BD;white-space:nowrap">Lezione {LESSON} · {total} slide · intervallo di 20 minuti</div>{CR}</div>')

def pause_slide(p0, p1, nxt):
    clock = (f'<svg style="position:absolute;left:900px;top:138px" width="200" height="140" viewBox="0 0 200 140">'
             f'<circle cx="100" cy="68" r="62" fill="none" stroke="#F0A15F" stroke-width="8"/>'
             f'<path d="M100 30 V70 L128 88" fill="none" stroke="#F0A15F" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg>')
    return (f'<div class="s dark">{HD}{clock}'
            f'<div style="position:absolute;left:0;width:2000px;top:395px;text-align:center;font-family:Oswald;font-weight:600;font-size:123px;line-height:140px;color:#F4F1EA">Intervallo</div>'
            f'<div style="position:absolute;left:0;width:2000px;top:710px;text-align:center;font-size:45.8px;line-height:56px;color:#D9E2E6">20 minuti · dalle {p0} alle {p1}</div>'
            f'<div style="position:absolute;left:0;width:2000px;top:885px;text-align:center;font-size:33.2px;line-height:40px;color:#9FB3BD">{html.escape(nxt)}</div>'
            f'<div class="ft" style="color:#9FB3BD">{UDF} · {DB}intervallo</div>{CR}</div>')

def page(slides_html):
    return f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{"".join(slides_html)}</body></html>'

def render_pngs(slides_html, outdir):
    from playwright.sync_api import sync_playwright
    os.makedirs(outdir, exist_ok=True)
    open('deck.html', 'w').write(page(slides_html))
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={'width': 2000, 'height': 1125})
        pg.goto('file://' + os.path.abspath('deck.html')); pg.wait_for_timeout(800)
        pg.evaluate('document.fonts.ready')
        n = pg.evaluate('document.querySelectorAll(".s").length')
        for i in range(n):
            el = pg.query_selector_all('.s')[i]
            el.screenshot(path=f'{outdir}/s{i+1:02d}.png')
        pg.pdf(path='deck.pdf', width='2000px', height='1125px', print_background=True)
        # controllo overflow titoli/testi
        warn = pg.evaluate('''()=>{const r=[];document.querySelectorAll('.s').forEach((s,i)=>{
          const h=s.querySelector('h1'); if(h && h.scrollWidth>1050) r.push([i+1,'titolo largo',h.scrollWidth]);
          const u=s.querySelector('ul'); if(u && u.getBoundingClientRect().bottom - s.getBoundingClientRect().top>935) r.push([i+1,'bullets troppo lunghi',Math.round(u.getBoundingClientRect().bottom - s.getBoundingClientRect().top)]);
          s.querySelectorAll('.card svg text').forEach(t=>{const b=t.getBBox(); if(b.x<4||b.x+b.width>662||b.y<2||b.y+b.height>455) r.push([i+1,'testo fuori card',t.textContent.slice(0,30)]);});
          const sr=s.getBoundingClientRect();
          const w=document.createTreeWalker(s,NodeFilter.SHOW_TEXT);let n;
          while((n=w.nextNode())){ if(!n.textContent.trim()||n.parentElement.closest('svg')) continue;
            const rg=document.createRange(); rg.selectNodeContents(n);
            for(const b of rg.getClientRects()){ if(b.left<sr.left+20||b.right>sr.right-20||b.top<sr.top+10||b.bottom>sr.bottom-8) r.push([i+1,'testo fuori slide',n.textContent.slice(0,40),Math.round(b.right-sr.left),Math.round(b.bottom-sr.top)]); }}
          s.querySelectorAll('.cap').forEach(c=>{const b=c.getBoundingClientRect(); const f=s.querySelector('.cr'); if(f && b.bottom>f.getBoundingClientRect().top-4) r.push([i+1,'didascalia sul copyright',Math.round(b.bottom-sr.top)]);});
        });return r;}''')
        b.close()
    return warn
