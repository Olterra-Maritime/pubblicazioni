import json, glob
from pptx import Presentation
from pptx.util import Emu
notes = json.load(open('notes.json'))
pngs = sorted(glob.glob('png/s*.png'))
assert len(pngs) == len(notes) == 46
p = Presentation(); p.slide_width = Emu(12192000); p.slide_height = Emu(6858000)
for f, n in zip(pngs, notes):
    s = p.slides.add_slide(p.slide_layouts[6])
    s.shapes.add_picture(f, 0, 0, p.slide_width, p.slide_height)
    s.notes_slide.notes_text_frame.text = n
p.core_properties.title = 'U.D. 4.1.1 A – Lezione 3 – Corrosione, protezione e bacino'
p.save('out/UD_4.1.1A_L3_Corrosione_protezione_bacino.pptx')
