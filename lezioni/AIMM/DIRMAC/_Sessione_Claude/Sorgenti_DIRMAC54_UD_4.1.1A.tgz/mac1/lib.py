"""Libreria di disegno SVG (diagrammi originali) e template slide."""
from PIL import ImageFont
import re, html

FR = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
FB = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
_f = {}
def _font(b):
    if b not in _f:
        _f[b] = ImageFont.truetype(FB if b else FR, 100)
    return _f[b]
FS = 1.12  # fattore di ingrandimento dei testi nelle figure
def tw(s, size, bold=False):
    return _font(bold).getlength(s) * size * FS / 100.0

NAVY = '#0F2A3D'; PANEL = '#123349'; SEA = '#0A1E2C'
INK = '#16222B'; BLUE = '#2E6B8A'; RUST = '#A8450F'; ORANGE = '#F0A15F'
GREEN = '#1F6B4A'; GRAY = '#5E6B73'; CREAM = '#F4F1EA'; LINE = '#C9C3B8'
SOFTB = '#EAF1F4'; SOFTR = '#FBEDE2'; SOFTG = '#D8EAE0'; SAND = '#8C7F5F'
YEL = '#C98A1B'; SOFTY = '#F7EBCB'; STEEL = '#8B949B'; HULL = '#24506B'

W, H = 666, 457

def esc(s):
    return html.escape(str(s), quote=False)

def T(x, y, s, size=20, bold=False, fill=INK, anchor='start', maxw=None, italic=False, dy=0):
    """Testo con riduzione automatica se supera maxw."""
    s = str(s)
    if maxw:
        while tw(s, size, bold) > maxw and size > 11:
            size -= 0.5
    st = ' font-style="italic"' if italic else ''
    return (f'<text x="{x}" y="{y+dy}" font-size="{size}" font-weight="{700 if bold else 400}" '
            f'fill="{fill}" text-anchor="{anchor}"{st}>{esc(s)}</text>').replace(f'font-size="{size}"', f'font-size="{round(size * FS, 2)}"', 1)

def wrap(s, size, maxw, bold=False):
    words = s.split(); lines = []; cur = ''
    for w in words:
        t = (cur + ' ' + w).strip()
        if tw(t, size, bold) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines

def TW(x, y, s, size=18, maxw=300, lh=None, bold=False, fill=INK, anchor='start'):
    lh = lh or size * 1.22 * FS
    out = []
    for i, ln in enumerate(wrap(s, size, maxw, bold)):
        out.append(T(x, y + i * lh, ln, size, bold, fill, anchor))
    return ''.join(out)

def nlines(s, size, maxw, bold=False):
    return len(wrap(s, size, maxw, bold))

def R(x, y, w, h, fill='none', stroke='none', sw=2, rx=8, dash=None, op=None):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    o = f' opacity="{op}"' if op else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{d}{o}/>'

def L(x1, y1, x2, y2, c=INK, sw=2, dash=None, cap='round'):
    d = f' stroke-dasharray="{dash}"' if dash else ''
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{c}" stroke-width="{sw}" stroke-linecap="{cap}"{d}/>'

def P(pts, fill='none', stroke='none', sw=2, close=True, dash=None, op=None):
    d = ' '.join(f'{x},{y}' for x, y in pts)
    tag = 'polygon' if close else 'polyline'
    ds = f' stroke-dasharray="{dash}"' if dash else ''
    o = f' opacity="{op}"' if op else ''
    return f'<{tag} points="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"{ds}{o}/>'

def C(cx, cy, r, fill='none', stroke='none', sw=2):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'

def PATH(d, fill='none', stroke='none', sw=2, dash=None):
    ds = f' stroke-dasharray="{dash}"' if dash else ''
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"{ds}/>'

import math
def A(x1, y1, x2, y2, c=INK, sw=2.5, head=10):
    ang = math.atan2(y2 - y1, x2 - x1)
    bx, by = x2 - head * math.cos(ang), y2 - head * math.sin(ang)
    px, py = -math.sin(ang) * head * 0.55, math.cos(ang) * head * 0.55
    return (L(x1, y1, bx, by, c, sw, cap='butt') +
            P([(x2, y2), (bx + px, by + py), (bx - px, by - py)], fill=c, stroke=c, sw=1))

def head(title, x=28, y=34, size=21, fill=INK):
    return T(x, y, title, size, True, fill, maxw=W - 2 * x)

def box(x, y, w, h, title, sub=None, fill=BLUE, stroke=None, tfill='#FFFFFF', sfill=None,
        tsize=19, ssize=16, rx=8, sw=2):
    stroke = stroke or fill
    out = [R(x, y, w, h, fill, stroke, sw, rx)]
    sfill = sfill or tfill
    if sub:
        sl = wrap(sub, ssize, w - 14)
        tot = (tsize * 1.05 + len(sl) * ssize * 1.18) * FS
        y0 = y + (h - tot) / 2 + tsize * 0.85 * FS
        out.append(T(x + w / 2, y0, title, tsize, True, tfill, 'middle', maxw=w - 12))
        for i, ln in enumerate(sl):
            out.append(T(x + w / 2, y0 + (tsize * 0.35 + (i + 1) * ssize * 1.18) * FS, ln, ssize, False, sfill, 'middle'))
    else:
        ls = wrap(title, tsize, w - 14, True)
        tot = len(ls) * tsize * 1.15 * FS
        y0 = y + (h - tot) / 2 + tsize * 0.88 * FS
        for i, ln in enumerate(ls):
            out.append(T(x + w / 2, y0 + i * tsize * 1.15 * FS, ln, tsize, True, tfill, 'middle'))
    return ''.join(out)

def svg(body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
            f'font-family="Liberation Sans, Arial, Helvetica, sans-serif">{body}</svg>')

# ---------- pattern generici ----------
def rows(title, items, y0=62, rh=None, gap=8, lw=150, size=17):
    """items: (label, testo, stile) stile in b,r,g,n"""
    sty = {'b': (SOFTB, BLUE), 'r': (SOFTR, RUST), 'g': (SOFTG, GREEN), 'n': ('#EFEDE7', STEEL), 'y': (SOFTY, YEL)}
    n = len(items)
    avail = H - y0 - 20
    rh = rh or (avail - gap * (n - 1)) / n
    out = [head(title)] if title else []
    for i, it in enumerate(items):
        lab, txt, st = it
        f, s = sty[st]
        y = y0 + i * (rh + gap)
        out.append(R(28, y, W - 56, rh, f, s, 2, 9))
        out.append(T(42, y + rh / 2 + 6, lab, 17, True, INK, maxw=lw - 24))
        lines = wrap(txt, size, W - 56 - lw - 24)
        lh = size * 1.2 * FS
        yy = y + rh / 2 - (len(lines) - 1) * lh / 2 + 6
        for j, ln in enumerate(lines):
            out.append(T(28 + lw + 8, yy + j * lh, ln, size, False, INK))
    return ''.join(out)

def flow(title, items, y=120, h=84, colors=None, note=None, sub_y=None, size=18):
    n = len(items)
    gap = 26
    bw = (W - 56 - gap * (n - 1)) / n
    out = [head(title)]
    for i, it in enumerate(items):
        t, s = it if isinstance(it, tuple) else (it, None)
        col = (colors[i] if colors else BLUE)
        x = 28 + i * (bw + gap)
        out.append(box(x, y, bw, h, t, s, fill=col, tsize=size, ssize=15))
        if i < n - 1:
            out.append(A(x + bw + 2, y + h / 2, x + bw + gap - 2, y + h / 2, INK, 2.5, 9))
    if note:
        out.append(T(W / 2, y + h + 38, note, 16, False, GRAY, 'middle', maxw=W - 56))
    return ''.join(out)

def hbars(title, items, y0=70, maxv=None, vw=300, bh=30, gap=22, lw=170, unit='', fmt=None, size=16):
    """items: (label, valore, colore, testo_valore)"""
    maxv = maxv or max(i[1] for i in items)
    out = [head(title)] if title else []
    for i, (lab, v, col, vt) in enumerate(items):
        y = y0 + i * (bh + gap)
        out.append(T(28, y + bh / 2 + 6, lab, size + 1, True, INK, maxw=lw - 10))
        out.append(R(28 + lw, y, vw, bh, '#F0EEE8', None, 0, 5))
        out.append(R(28 + lw, y, max(4, vw * v / maxv), bh, col, None, 0, 5))
        out.append(T(28 + lw + vw + 10, y + bh / 2 + 6, vt, size, True, col, maxw=W - 28 - lw - vw - 38))
    return ''.join(out)

def callout(y, text, kind='g', h=40, size=17):
    f, s = {'g': (SOFTG, GREEN), 'r': (SOFTR, RUST), 'b': (SOFTB, BLUE), 'y': (SOFTY, YEL)}[kind]
    col = {'g': GREEN, 'r': RUST, 'b': BLUE, 'y': '#7A5200'}[kind]
    ls = wrap(text, size, W - 56 - 24, True)
    hh = max(h, len(ls) * size * 1.2 * FS + 16)
    out = [R(28, y, W - 56, hh, f, s, 2, 9)]
    for i, ln in enumerate(ls):
        out.append(T(W / 2, y + hh / 2 + 6 - (len(ls) - 1) * size * 0.6 * FS + i * size * 1.2 * FS, ln, size, True, col, 'middle'))
    return ''.join(out)

# ---------- elementi nave ----------
def hull_side(x, y, w, h, fill=HULL, stroke='#B9C7D0'):
    """scafo in vista laterale, prora a sinistra"""
    sk = h * 0.34
    return P([(x, y), (x + w, y), (x + w - sk * 0.6, y + h), (x + sk, y + h)], fill, stroke, 2)

def bc_section(x, y, w, h, cargo=None, cargo_fill=SAND, hatch=True, sw=3):
    """sezione maestra semplificata. (x,y)=angolo sup. sx dello scafo; w,h dimensioni."""
    out = []
    deck_t = 8
    ds = h * 0.14          # altezza doppio fondo
    top_h = h * 0.30; top_w = w * 0.20
    hop_h = h * 0.28; hop_w = w * 0.18
    xr = x + w; yb = y + h
    # sagoma esterna
    out.append(R(x, y, w, h, '#FFFFFF', INK, sw, 4))
    # doppio fondo
    out.append(R(x, yb - ds, w, ds, '#DCE7ED', INK, 2, 0))
    # cisterne tramoggia
    out.append(P([(x, yb - ds - hop_h), (x + hop_w, yb - ds), (x, yb - ds)], '#DCE7ED', INK, 2))
    out.append(P([(xr, yb - ds - hop_h), (xr - hop_w, yb - ds), (xr, yb - ds)], '#DCE7ED', INK, 2))
    # cisterne alte
    out.append(P([(x, y + deck_t), (x + top_w, y + deck_t), (x, y + deck_t + top_h)], '#DCE7ED', INK, 2))
    out.append(P([(xr, y + deck_t), (xr - top_w, y + deck_t), (xr, y + deck_t + top_h)], '#DCE7ED', INK, 2))
    # ponte
    out.append(R(x, y, w, deck_t, INK, INK, 0, 0))
    if cargo:
        top = yb - ds - cargo * (h - ds - deck_t)
        pts = [(x + 2, yb - ds - hop_h + 1), (x + hop_w, yb - ds), (xr - hop_w, yb - ds), (xr - 2, yb - ds - hop_h + 1)]
        out.append(P(pts + [(xr - 2, max(top, y + deck_t + top_h)), (x + 2, max(top, y + deck_t + top_h))], cargo_fill, None, 0))
    if hatch:
        hw = w - 2 * top_w
        out.append(R(x + top_w, y - 16, 5, 16, INK, INK, 0, 0))
        out.append(R(xr - top_w - 5, y - 16, 5, 16, INK, INK, 0, 0))
        out.append(R(x + top_w - 4, y - 22, hw + 8, 7, STEEL, INK, 1.5, 2))
    return ''.join(out)

def ship_profile(x, y, w, h, nholds=7, fills=None, label=True, numbers=True, fill=HULL, cargo=SAND):
    """profilo longitudinale con prora a sinistra; fills = lista livelli 0..1 per stiva"""
    out = []
    out.append(hull_side(x, y, w, h, fill, '#B9C7D0'))
    acc_w = w * 0.16
    hold_w = (w - acc_w - w * 0.07) / nholds
    x0 = x + w * 0.07
    for i in range(nholds):
        hx = x0 + i * hold_w
        out.append(R(hx + 3, y + 5, hold_w - 6, h - 10, '#E9EFF2', None, 0, 3))
        if fills and fills[i]:
            fh = (h - 14) * fills[i]
            out.append(R(hx + 3, y + h - 7 - fh, hold_w - 6, fh, cargo, None, 0, 2))
        out.append(R(hx + 4, y - 7, hold_w - 8, 7, STEEL, INK, 1, 2))
        if numbers:
            out.append(T(hx + hold_w / 2, y + 30, str(i + 1), 17, True, INK, 'middle'))
    ax = x + w - acc_w
    out.append(R(ax, y - 34, acc_w - 4, 34, '#DCE7ED', INK, 2, 3))
    out.append(R(ax + 8, y - 24, 8, 8, HULL, None, 0, 1)); out.append(R(ax + 24, y - 24, 8, 8, HULL, None, 0, 1))
    out.append(R(ax + acc_w - 26, y - 58, 16, 24, RUST, INK, 1.5, 2))
    return ''.join(out)

def sea(y, c=BLUE, w=W):
    return PATH(f'M0 {y} q20 -8 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0', stroke=c, sw=2)

def tile(x, y, w, h, title, sub=None, kind='b', tsize=17, ssize=15):
    f, s = {'b': (SOFTB, BLUE), 'r': (SOFTR, RUST), 'g': (SOFTG, GREEN), 'y': (SOFTY, YEL), 'n': ('#EFEDE7', STEEL)}[kind]
    out = [R(x, y, w, h, f, s, 2, 9)]
    out.append(T(x + 14, y + 24, title, tsize, True, INK, maxw=w - 24))
    if sub:
        for i, ln in enumerate(wrap(sub, ssize, w - 28)):
            out.append(T(x + 14, y + 24 + (i + 1) * ssize * 1.25 * FS, ln, ssize, False, GRAY))
    return ''.join(out)

def checkrow(x, y, w, text, tag=None, h=44, size=17, kind='g'):
    out = [R(x, y, w, h, '#F6F4EE', LINE, 1.5, 8)]
    out.append(R(x + 10, y + h / 2 - 12, 24, 24, SOFTG, GREEN, 2, 5))
    out.append(P([(x + 15, y + h / 2), (x + 21, y + h / 2 + 6), (x + 30, y + h / 2 - 7)], 'none', GREEN, 3, False))
    out.append(T(x + 46, y + h / 2 + 6, text, size, True, INK, maxw=w - 60 - (tw(tag, 14, True) + 20 if tag else 0)))
    if tag:
        tws = tw(tag, 14, True) + 16
        out.append(R(x + w - tws - 10, y + h / 2 - 13, tws, 26, SOFTR, RUST, 1.5, 13))
        out.append(T(x + w - tws / 2 - 10, y + h / 2 + 5, tag, 14, True, RUST, 'middle'))
    return ''.join(out)

# ---------- slide 2: orario + fonti con revisione ----------
def programma_fonti(times, fonti, title='Orario e fonti (revisione usata)'):
    """times: 4 orari (inizio, pausa, ripresa, fine); fonti: lista (fonte, revisione)."""
    sc = 610 / 240
    p1, pa = 110 * sc, 20 * sc
    o = [head(title)]
    o.append(R(28, 50, p1, 40, BLUE, None, 0, 8)); o.append(T(28 + p1 / 2, 76, 'PARTE 1 · slide 1-22', 15, True, '#fff', 'middle', maxw=p1 - 12))
    o.append(R(28 + p1 + 4, 50, pa - 8, 40, ORANGE, None, 0, 8)); o.append(T(28 + p1 + pa / 2, 76, 'PAUSA', 13, True, INK, 'middle', maxw=pa - 12))
    o.append(R(28 + p1 + pa, 50, p1, 40, BLUE, None, 0, 8)); o.append(T(28 + p1 + pa + p1 / 2, 76, 'PARTE 2 · slide 23-45', 15, True, '#fff', 'middle', maxw=p1 - 12))
    o.append(L(28, 100, 638, 100, LINE, 2))
    for x, t, a in [(28, times[0], 'start'), (28 + p1, times[1], 'middle'), (28 + p1 + pa, times[2], 'middle'), (638, times[3], 'end')]:
        o.append(L(x, 95, x, 105, GRAY, 2)); o.append(T(x, 122, t, 14, False, GRAY, a))
    o.append(R(28, 136, 610, 28, INK, None, 0, 5))
    o.append(T(40, 155, 'Fonte', 14, True, '#fff')); o.append(T(330, 155, 'Revisione usata', 14, True, '#fff'))
    n = len(fonti); rh = min(40, (446 - 168) / n)
    for i, (f, r) in enumerate(fonti):
        y = 168 + i * rh
        o.append(R(28, y, 610, rh - 4, SOFTB if i % 2 == 0 else '#FFFFFF', LINE, 1, 4))
        o.append(T(40, y + rh / 2 + 3, f, 14, True, INK, maxw=280))
        o.append(T(330, y + rh / 2 + 3, r, 14, False, INK, maxw=298))
    return ''.join(o)

# ---------- tabella generica ----------
def grid(title, headers, rows, colx, y0=60, rh=32, size=14, hsize=14, bold_first=True, fills=None):
    """headers: lista; rows: liste di stringhe; colx: x di inizio colonne (l'ultima colonna arriva a 638)."""
    o = [head(title)] if title else []
    xs = list(colx) + [638]
    o.append(R(28, y0, 610, rh, INK, None, 0, 5))
    for i, h in enumerate(headers):
        o.append(T(xs[i] + 8, y0 + rh / 2 + 5, h, hsize, True, '#fff', maxw=xs[i + 1] - xs[i] - 12))
    for r, row in enumerate(rows):
        y = y0 + (r + 1) * rh
        f = (fills[r] if fills and fills[r] else (SOFTB if r % 2 == 0 else '#FFFFFF'))
        o.append(R(28, y + 2, 610, rh - 4, f, LINE, 1, 4))
        for i, c in enumerate(row):
            o.append(T(xs[i] + 8, y + rh / 2 + 5, c, size, bold_first and i == 0, INK, maxw=xs[i + 1] - xs[i] - 12))
    return ''.join(o)

def vflow(title, items, colors=None, note=None, y0=58):
    """flusso verticale: items (titolo, testo); frecce verso il basso"""
    n = len(items); gap = 14
    avail = H - y0 - 16 - (34 if note else 0)
    bh = (avail - gap * (n - 1)) / n
    o = [head(title)] if title else []
    for i, (t, s) in enumerate(items):
        y = y0 + i * (bh + gap)
        c = colors[i] if colors else BLUE
        o.append(R(28, y, 190, bh, c, None, 0, 8))
        o.append(T(123, y + bh / 2 + 6, t, 16, True, '#fff', 'middle', maxw=176))
        o.append(R(226, y, 412, bh, '#F6F4EE', LINE, 1.5, 8))
        o.append(T(242, y + bh / 2 + 6, s, 15, False, INK, maxw=384))
        if i < n - 1:
            o.append(A(123, y + bh + 1, 123, y + bh + gap - 1, INK, 2.5, 7))
    if note:
        o.append(T(333, H - 18, note, 14, True, GRAY, 'middle', maxw=600))
    return ''.join(o)
