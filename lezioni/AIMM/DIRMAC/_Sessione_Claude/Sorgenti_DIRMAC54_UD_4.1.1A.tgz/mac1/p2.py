"""Lezione 1 (13/11/2026) · U.D. 4.1.1 A · parte 2 (slide 23-45)."""
from lib import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes, dur=5):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes, dur=dur))

E6 = 'PARTE 2 · ALTRI ACCIAI'
E7 = 'PARTE 2 · TRATTAMENTI E PROPRIETÀ'
E8 = 'PARTE 2 · PROGETTO E RIPARAZIONE'
E9 = 'PARTE 2 · VERIFICA'

# ---------------- 23 Ripresa ----------------
def d23():
    o = [head('Risposte e programma della seconda parte')]
    ans = [('1', 'stessa resistenza, più tenace'), ('2', 'snervamento 355 N/mm²'), ('3', 'tensioni massime')]
    for i, (n, a) in enumerate(ans):
        x = 28 + i * 206
        o.append(R(x, 62, 196, 70, SOFTG, GREEN, 2, 9)); o.append(T(x + 14, 90, f'Domanda {n}', 14, True, GRAY))
        o.append(T(x + 14, 116, a, 15, True, GREEN, maxw=170))
    blocks = [('Altri acciai', 'getti, fucinati, assi, caldaie', 'b'), ('Trattamenti e prove', 'calore, durezza, proprietà tecnologiche', 'b'),
              ('Progetto', 'k, peso, fatica, saldature', 'r'), ('Riparazione e verifica', 'sostituzioni, esercizi, domande', 'r')]
    for i, (t, s, k) in enumerate(blocks):
        x = 28 + (i % 2) * 312; y = 160 + (i // 2) * 130
        o.append(tile(x, y, 298, 112, t, s, k))
    return ''.join(o)
add('PARTE 2 · RIPRESA', 'Ripresa: risposte e programma',
    ['Risposte alle **tre domande** della pausa',
     'Acciai per **getti, fucinati** e macchinari',
     '**Trattamenti termici**, durezza, proprietà',
     'Progetto, **riparazioni**, esercizi d\'esame'],
    'risposte di richiamo e blocchi della seconda parte', d23(),
    "Verificare le risposte della pausa: 1) A ed E hanno la stessa resistenza; E garantisce 27 J a −40 °C ed è calmato, a grano fine e normalizzato o TM; 2) 36 = snervamento minimo 355 N/mm²; 3) cinta e trincarino a centro nave portano le tensioni massime della flessione della trave-scafo: serve la tenacità più alta. Seconda parte: gli acciai fuori dallo scafo (getti e fucinati, assi, caldaie, tubolature), trattamenti termici e durezza, proprietà tecnologiche (domanda d'esame C.5), conseguenze progettuali dell'alta resistenza, materiali d'apporto, riparazioni ed esercizi.", dur=4)

# ---------------- 24 Produttori approvati ----------------
def d24():
    return vflow('Dall\'approvazione del produttore al pezzo', [('Approvazione', 'acciaieria e processo approvati dalla classe'), ('Collaudo', 'prove per colata o lotto, con l\'ispettore'),
                 ('Marcatura', 'grado, colata, timbro della classe'), ('Certificato', 'firmato dal produttore e dalla classe'), ('A bordo', 'piano dei gradi e certificati')],
                 colors=[BLUE, BLUE, RUST, RUST, GREEN], note='Senza approvazione e certificato il materiale non entra nello scafo')
add(E6, 'Produttori approvati e controlli',
    ['L\'acciaieria è **approvata** dalla classe',
     'Prove su ogni **colata** o lotto',
     'Ispettore presente alle **prove**',
     'A bordo: **piano dei gradi** e certificati'],
    'catena dei controlli sul materiale', d24(),
    "IACS UR W11 Rev.9, paragrafo 2 e appendice A: gli acciai da scafo sono prodotti in stabilimenti approvati dalla società di classifica per il tipo di acciaio, il processo e gli spessori; l'approvazione prevede la verifica del sistema qualità, prove di qualificazione e un sistema di identificazione dei materiali in tutte le fasi. Ogni fornitura è collaudata con prove su campioni per colata o per lotto, alla presenza dell'ispettore (paragrafi 11–14), marcata (16) e accompagnata da certificato (17). Lo stesso schema vale per getti, fucinati, tubi, materiali d'apporto e componenti di macchina soggetti a classe. A bordo: CSR Pt 1 Ch 3 Sec 1 [2.1.5] chiede un piano con tipi e gradi di acciaio; i certificati dei materiali sostituiti nelle riparazioni si conservano con la documentazione di classe.")

# ---------------- 25 Getti e fucinati ----------------
def d25():
    return rows('Getti e fucinati di acciaio (UR W7, W8)', [
        ('Fucinati · W7', 'asse del timone, agugliotti, linea d\'assi, bielle, alberi a gomiti', 'b'),
        ('Getti · W8', 'dritto di poppa, mozzi, corpi di valvole, supporti', 'b'),
        ('Sempre', 'trattamento termico, prove meccaniche, controlli non distruttivi', 'r'),
        ('Revisioni', 'W7 Rev.4 2022 e W8 Rev.4 2024; Rev.5 dal 1° gennaio 2027', 'n')], y0=62, lw=150, size=15)
add(E6, 'Getti e fucinati di acciaio',
    ['**Fucinati**: assi, timoni, alberi a gomiti',
     '**Getti**: dritti di poppa, mozzi, valvole',
     'Sempre **trattati termicamente**',
     'Prove meccaniche e **controlli non distruttivi**'],
    'impieghi tipici di getti e fucinati', d25(),
    "IACS UR W7 Rev.4 (febbraio 2022), Hull and machinery steel forgings, e UR W8 Rev.4 (marzo 2024), Hull and machinery steel castings; entrambe hanno una Rev.5 che si applica dal 1° gennaio 2027. W7 cita come componenti di scafo l'asse del timone e gli agugliotti, e come componenti di macchina la linea d'assi, le bielle, gli alberi a gomiti (con requisiti di fibratura per gli alberi forgiati); gli assi del timone e gli agugliotti devono essere di qualità saldabile. W8 riguarda getti per scafo e macchine come dritti di poppa e componenti di macchine. Requisiti comuni: produttore approvato, composizione con limiti sul carbonio e sugli elementi residui, trattamento termico definito (normalizzazione, eventualmente rinvenimento, o bonifica), prove di trazione e resilienza, esame visivo e controlli non distruttivi (magnetoscopia, ultrasuoni) secondo il componente. Le eliche in acciaio fuso hanno una UR dedicata (W27), quelle in lega di rame la W24: lezione 2.")

# ---------------- 26 Assi e timone ----------------
def d26():
    o = [head('Linea d\'assi e timone: dove sta il materiale')]
    o.append(L(40, 200, 560, 200, INK, 10))
    for x, t in [(120, 'reggispinta'), (300, 'cuscinetti intermedi'), (470, 'astuccio')]:
        o.append(R(x - 24, 182, 48, 36, '#DCE7ED', INK, 2, 4)); o.append(T(x, 248, t, 13, True, INK, 'middle'))
    o.append(P([(560, 160), (600, 130), (600, 270), (560, 240)], STEEL, INK, 2))
    o.append(T(600, 292, 'elica', 13, True, INK, 'middle'))
    o.append(R(612, 70, 10, 100, RUST, INK, 1, 0)); o.append(T(600, 84, 'asse del timone', 13, True, RUST, 'end'))
    o.append(rows('', [('Fucinati', 'asse portaelica, assi intermedi, asse del timone (W7)', 'b'),
                       ('Getti', 'dritto di poppa, mozzo, supporti (W8)', 'b'),
                       ('Eliche', 'lega di rame (W24) o acciaio fuso (W27)', 'r')], y0=316, lw=110, size=14))
    return ''.join(o)
add(E6, 'Assi, alberi e timone',
    ['Assi **fucinati**: resistenza a **torsione e fatica**',
     'Asse del timone: acciaio **saldabile**',
     'Elica: **lega di rame** o acciaio fuso',
     'Dati del materiale nei **certificati** di bordo'],
    'componenti della linea d\'assi e del timone, schema', d26(),
    "Collegamento con la parte di macchina del corso. La linea d'assi (asse portaelica, assi intermedi, reggispinta) è in acciaio forgiato secondo UR W7: lavora a torsione, flessione rotante e fatica, e il dimensionamento delle regole (IACS UR M68) tiene conto della resistenza a rottura del materiale. L'asse del timone e gli agugliotti sono fucinati di qualità saldabile (UR W7 Rev.4: 'Rudder stocks and pintles should be of weldable quality'), perché possono essere riparati o avere parti saldate. Dritto di poppa, mozzi e supporti possono essere getti (W8). Le eliche sono quasi sempre in lega di rame (W24) o, più raramente, in acciaio fuso (W27). A bordo i certificati di questi componenti servono quando si ordinano ricambi o riparazioni: il ricambio deve avere lo stesso materiale o uno approvato dalla classe.")

# ---------------- 27 Caldaie e tubi ----------------
def d27():
    return rows('Acciai per pressione e temperatura', [
        ('Caldaie', 'lamiere per alte temperature, resistenza a caldo garantita', 'r'),
        ('Recipienti', 'serbatoi d\'aria, scambiatori: classi secondo pressione e temperatura', 'b'),
        ('Tubolature', 'tubi senza saldatura o saldati, classi I, II, III', 'b'),
        ('Creep', 'deformazione lenta sotto carico ad alta temperatura', 'y'),
        ('Regole', 'regolamenti della società di classifica, norme EN e ISO', 'n')], y0=62, lw=140, size=15)
add(E6, 'Acciai per caldaie, recipienti e tubi',
    ['Ad alta temperatura conta la resistenza **a caldo**',
     '**Creep**: deformazione lenta nel tempo',
     'Tubi e recipienti divisi in **classi**',
     'Requisiti nei **regolamenti** della classe'],
    'materiali per componenti in pressione', d27(),
    "Per caldaie, recipienti in pressione e tubolature non c'è una UR della serie W equivalente alla W11: i requisiti sono nei regolamenti di ogni società di classifica (parte materiali e parte macchine) e richiamano norme come le EN 10028 (lamiere per recipienti a pressione) e le EN 10216 e 10217 (tubi). Concetti da ricordare: ad alta temperatura la resistenza diminuisce e conta il valore garantito a caldo; oltre una certa temperatura l'acciaio si deforma lentamente sotto carico costante (scorrimento viscoso, creep), da cui la vita limitata di surriscaldatori e tubi di caldaia; tubolature e recipienti sono divisi in classi (I, II, III) secondo pressione, temperatura e fluido, e la classe decide materiale, prove e controlli delle saldature. Approfondimento nelle unità di macchina del corso; qui basta il collegamento con il materiale.")

# ---------------- 28 Trattamenti termici ----------------
def d28():
    return rows('Trattamenti termici: che cosa fanno', [
        ('Normalizzazione', 'riscaldo sopra la trasformazione, aria calma: grano fine', 'b'),
        ('Tempra', 'raffreddamento rapido: durezza e resistenza alte', 'r'),
        ('Rinvenimento', 'dopo la tempra: recupera tenacità', 'r'),
        ('Bonifica (QT)', 'tempra + rinvenimento: resistenza e tenacità', 'g'),
        ('Distensione', 'riscaldo moderato: riduce le tensioni residue', 'y'),
        ('TMCP', 'laminazione controllata con raffreddamento: grano fine senza forno', 'n')], y0=62, lw=160, size=14)
add(E7, 'Trattamenti termici',
    ['**Normalizzazione**: grano fine e uniforme',
     '**Bonifica**: tempra più rinvenimento',
     '**Distensione** dopo saldature importanti',
     '**TMCP**: il trattamento fatto in laminazione'],
    'i trattamenti termici più usati e il loro scopo', d28(),
    "Richiamo applicato. Normalizzazione: riscaldo sopra la temperatura di trasformazione e raffreddamento in aria calma; affina e uniforma il grano, migliora la tenacità (richiesta per i gradi D spessi ed E, UR W11 tabelle 4 e 5). Tempra: raffreddamento rapido in acqua o olio; aumenta durezza e resistenza ma rende l'acciaio fragile. Rinvenimento: riscaldo a temperatura più bassa dopo la tempra; recupera tenacità. Bonifica (QT): tempra più rinvenimento, usata per gli acciai a 390 N/mm² di grande spessore, per gli acciai della UR W16 e per molti fucinati. Distensione: riscaldo a temperatura moderata con raffreddamento lento, per ridurre le tensioni residue di saldatura (caldaie, componenti spessi). TMCP: laminazione a temperature controllate seguita da raffreddamento accelerato; dà grano fine e carbonio equivalente basso senza un trattamento separato, ma una lamiera TM non va riscaldata oltre circa 580 °C (per esempio in raddrizzature a caldo) senza accordo con la classe, perché perde le proprietà.")

# ---------------- 29 Durezza ----------------
def d29():
    o = [grid('Prove di durezza', ['Metodo', 'Penetratore', 'Uso tipico'], [
        ('Brinell HB', 'sfera', 'getti, fucinati, materiali grossolani'), ('Vickers HV', 'piramide di diamante', 'saldature e zona termicamente alterata'),
        ('Rockwell HRC', 'cono di diamante', 'pezzi temprati, controllo rapido')], [28, 190, 380], y0=62, rh=50, size=14)]
    o.append(R(28, 290, 610, 140, SOFTR, RUST, 2, 10))
    o.append(T(44, 320, 'Qualifica dei procedimenti di saldatura (UR W28):', 15, True, RUST, maxw=580))
    o.append(T(44, 348, 'acciai con ReH ≤ 420 N/mm²: massimo 350 HV10', 15, False, INK, maxw=580))
    o.append(T(44, 374, 'oltre 420 fino a 690 N/mm²: massimo 420 HV10', 15, False, INK, maxw=580))
    o.append(T(44, 400, 'più durezza = rischio di cricche nella saldatura', 14, False, GRAY, maxw=580))
    return ''.join(o)
add(E7, 'Prove di durezza',
    ['Resistenza alla **penetrazione** di un corpo duro',
     '**Brinell**, **Vickers**, **Rockwell**',
     'Nelle saldature si usa il **Vickers HV10**',
     'Limite **350 HV10** per gli acciai da scafo'],
    'metodi di prova della durezza e limite per le saldature', d29(),
    "La durezza misura la resistenza alla penetrazione: Brinell (sfera, impronta grande, adatto a getti e fucinati), Vickers (piramide di diamante, impronte piccole, adatto a saldature e zone termicamente alterate), Rockwell (cono o sfera, lettura diretta, per pezzi temprati). È legata alla resistenza a trazione e, nelle saldature, è un indice del rischio di cricche. IACS UR W28 Rev.2 (2012), paragrafo 4.2.2.7: nella qualifica dei procedimenti di saldatura la prova di durezza è richiesta per acciai con snervamento ≥ 355 N/mm², metodo Vickers HV10, con valori massimi di 350 HV10 per ReH fino a 420 N/mm² e 420 HV10 da 420 a 690 N/mm². La Rev.3 della W28 si applica dal 1° gennaio 2027. La prova fa parte anche delle verifiche dopo riparazioni importanti.", dur=4)

# ---------------- 30 Proprietà tecnologiche ----------------
def d30():
    return rows('Proprietà tecnologiche (domanda C.5)', [
        ('Saldabilità', 'saldare senza cricche: C e Ceq bassi', 'r'),
        ('Formabilità', 'piegare e calandrare a freddo: duttilità', 'b'),
        ('Lavorabilità', 'tagliare, forare, lavorare all\'utensile', 'b'),
        ('Colabilità', 'riempire uno stampo: ghise, bronzi, getti', 'y'),
        ('Temprabilità', 'indurire con la tempra: acciai legati', 'y'),
        ('Fucinabilità', 'deformare a caldo: assi, alberi', 'n')], y0=62, lw=140, size=15)
add(E7, 'Proprietà tecnologiche',
    ['Dicono come il materiale si **lavora**',
     'Per lo scafo conta la **saldabilità**',
     'Per i getti la **colabilità**',
     'Domanda d\'esame: proprietà **meccaniche + tecnologiche**'],
    'le proprietà tecnologiche e dove contano', d30(),
    "Domanda d'esame Meccanica C.5: 'Il candidato parli dei materiali più usati a bordo, elencando anche le proprietà tecnologiche dei materiali'. Proprietà meccaniche: resistenza, duttilità, tenacità, durezza, resistenza a fatica. Proprietà tecnologiche: attitudine del materiale a essere lavorato. Saldabilità (decisiva per lo scafo: carbonio basso, carbonio equivalente limitato); formabilità o deformabilità a freddo (piegatura, calandratura delle lamiere: serve duttilità; prova di piegamento); lavorabilità alle macchine utensili; colabilità (ghise, bronzi, acciai da getto); temprabilità (acciai legati per organi meccanici); fucinabilità (assi, alberi, bielle). Schema di risposta consigliato: materiale → impiego a bordo → proprietà che lo rendono adatto → requisito di classe. Esempio: acciaio EH36 → cinta e trincarino → resistenza 355 N/mm², tenacità a −40 °C, saldabilità → UR W11.")

# ---------------- 31 Esercizio numerico ----------------
def d31():
    o = [head('Esercizio: stessa lamiera, due acciai')]
    o.append(R(28, 62, 610, 110, SOFTB, BLUE, 2, 10))
    o.append(T(44, 92, 'Fondo di una cisterna: in acciaio normale servono 16 mm', 15, True, INK, maxw=580))
    o.append(T(44, 118, 'Regola semplificata: t ∝ s · √(p · k)', 15, False, INK, maxw=580))
    o.append(T(44, 144, 'stessa pressione p e stesso passo s', 14, False, GRAY, maxw=580))
    qs = ['Quanto spessore serve in AH36?', 'Quanto peso si risparmia, in percentuale?', 'E il modulo di una trave in AH36?']
    for i, q in enumerate(qs):
        y = 196 + i * 74
        o.append(R(28, y, 610, 62, SOFTY, YEL, 2, 9)); o.append(T(46, y + 38, str(i + 1), 20, True, '#7A5200'))
        o.append(T(76, y + 37, q, 16, True, INK, maxw=548))
    return ''.join(o)
add(E8, 'Esercizio numerico',
    ['Lamiera sotto **pressione laterale**',
     'Spessore proporzionale a **√k**',
     'Trave a flessione: modulo proporzionale a **k**',
     'A coppie, **5 minuti**'],
    'esercizio sul fattore k', d31(),
    "Esercizio semplificato, senza margini di corrosione e minimi di regola. Le formule delle regole per lamiere sotto pressione laterale hanno la forma t = c · s · √(p · k) più un margine; a parità di passo s e pressione p lo spessore netto è proporzionale a √k. Per le travi (rinforzi) il modulo di resistenza richiesto è proporzionale a k. Soluzione nella slide seguente. Far lavorare a coppie con la calcolatrice; chiedere poi quale conseguenza ha uno spessore minore su deformabilità e fatica (slide 33-34).")

# ---------------- 32 Soluzione ----------------
def d32():
    items = [('acciaio normale', 16.0, STEEL, '16,0 mm'), ('AH32 (k 0,78)', 16 * 0.78 ** 0.5, BLUE, f'{16 * 0.78 ** 0.5:.1f} mm'.replace('.', ',')),
             ('AH36 (k 0,72)', 16 * 0.72 ** 0.5, BLUE, f'{16 * 0.72 ** 0.5:.1f} mm'.replace('.', ',')), ('AH40 (k 0,68)', 16 * 0.68 ** 0.5, BLUE, f'{16 * 0.68 ** 0.5:.1f} mm'.replace('.', ','))]
    o = [hbars('Spessore della lamiera con k diversi', items, y0=66, maxv=16, vw=300, bh=34, gap=20, lw=170, size=15)]
    o.append(R(28, 300, 610, 128, SOFTG, GREEN, 2, 10))
    o.append(T(44, 330, '1) 16 × √0,72 = 13,6 mm', 16, True, GREEN, maxw=580))
    o.append(T(44, 360, '2) peso della lamiera −15 % (13,6 / 16 = 0,85)', 15, False, INK, maxw=580))
    o.append(T(44, 390, '3) modulo della trave: 72 % di quello in acciaio normale', 15, False, INK, maxw=580))
    o.append(T(44, 416, 'valori didattici, senza margini di corrosione', 13, False, GRAY, maxw=580))
    return ''.join(o)
add(E8, 'Soluzione dell\'esercizio',
    ['AH36: **13,6 mm** invece di 16',
     'Peso della lamiera **−15 %**',
     'Modulo della trave **−28 %**',
     'Meno acciaio, **stessa rigidezza**? No'],
    'spessori calcolati con i quattro valori di k', d32(),
    "Soluzione: t(AH36) = 16 × √0,72 = 16 × 0,849 = 13,6 mm; per AH32 14,1 mm, per AH40 13,2 mm. Il peso della lamiera è proporzionale allo spessore: con AH36 circa il 15 % in meno. Il modulo di resistenza richiesto per una trave è proporzionale a k: con AH36 basta il 72 % del modulo in acciaio normale. Nelle regole reali si aggiungono il margine di corrosione (lezione 3) e gli spessori minimi, quindi il risparmio effettivo è minore. Domanda di passaggio alla slide seguente: la trave in AH36, con meno modulo e quindi meno momento d'inerzia, si inflette di più o di meno? Di più: il modulo elastico è lo stesso.")

# ---------------- 33 Peso e rigidezza ----------------
def d33():
    return rows('Alta resistenza: che cosa si guadagna e che cosa no', [
        ('Si guadagna', 'peso della struttura, portata, spessori più facili da saldare', 'g'),
        ('Non cambia', 'modulo elastico E: la rigidezza dipende dalla geometria', 'n'),
        ('Si perde', 'margine contro instabilità di pannelli sottili', 'r'),
        ('Si perde', 'margine a fatica: escursioni di tensione più alte', 'r'),
        ('Si perde', 'margine contro la corrosione: meno spessore da consumare', 'r')], y0=62, lw=140, size=15)
add(E8, 'Peso risparmiato e prezzo da pagare',
    ['Meno **peso**, più **portata**',
     'Stessa **rigidezza** del materiale: E non cambia',
     'Pannelli più sottili: rischio di **instabilità**',
     'Meno spessore da perdere per **corrosione**'],
    'vantaggi e limiti dell\'acciaio ad alta resistenza', d33(),
    "L'acciaio ad alta resistenza è usato in gran parte delle navi moderne (spesso oltre metà del peso dello scafo nelle grandi portarinfuse e petroliere) perché riduce il peso e aumenta la portata. Ma il modulo elastico è lo stesso dell'acciaio normale (circa 206 000 N/mm²): strutture più sottili sono meno rigide, si deformano di più e i pannelli compressi raggiungono prima l'instabilità (buckling). Le tensioni di lavoro più alte significano escursioni di tensione più alte e quindi più danno a fatica (slide seguente). Infine, a parità di velocità di corrosione, una lamiera più sottile perde prima una percentuale significativa del suo spessore: per questo i margini di corrosione delle CSR non dipendono dal grado (lezione 3).")

# ---------------- 34 Fatica ----------------
def d34():
    o = [head('Fatica: l\'acciaio più resistente non aiuta')]
    o.append(R(28, 62, 610, 96, SOFTB, BLUE, 2, 10))
    o.append(T(44, 94, 'CSR Pt 1 Ch 9: stesse curve S-N per tutti gli acciai', 15, True, BLUE, maxw=580))
    o.append(T(44, 120, 'con snervamento fino a 390 N/mm²', 15, False, INK, maxw=580))
    o.append(T(44, 144, 'curva D, giunti saldati: 91,3 N/mm² a 2 milioni di cicli', 14, False, GRAY, maxw=580))
    items = [('acciaio normale', 100, STEEL, '100 %'), ('AH36, tensioni +39 %', 100 / (1 / 0.72) ** 3, RUST, f'{100 * 0.72 ** 3:.0f} %')]
    o.append(hbars('', items, y0=200, maxv=100, vw=300, bh=40, gap=26, lw=200, size=15))
    o.append(T(28, 360, 'vita a fatica relativa se le tensioni crescono come 1/k', 14, True, INK, maxw=610))
    o.append(T(28, 384, 'modulo al 72 % → tensioni × 1/0,72 = 1,39 · esempio didattico', 13, False, GRAY, maxw=610))
    o.append(callout(400, 'Più tensione, stessa curva: meno vita', 'r', h=40, size=15))
    return ''.join(o)
add(E8, 'Fatica degli acciai ad alta resistenza',
    ['La **resistenza a fatica** dei giunti saldati non cresce',
     'Stessa **curva S-N** per tutti i gradi',
     'Tensioni più alte → **vita più breve**',
     'I punti caldi vanno **ispezionati**'],
    'perché la fatica limita l\'uso dell\'alta resistenza', d34(),
    "Le CSR (Pt 1 Ch 9 Sec 1, [1.1.5]) usano le stesse curve S-N di progetto per tutti gli acciai con snervamento fino a 390 N/mm²: nei giunti saldati la resistenza a fatica dipende dal dettaglio e dalla saldatura, non dalla resistenza statica del materiale. Curva D per giunti saldati: 91,3 N/mm² di escursione a 2 milioni di cicli, pendenza m = 3 (Ch 9 Sec 3, tabella 2). Se una trave in AH36 ha il 72 % del modulo della stessa in acciaio normale (slide 32), sotto lo stesso carico le tensioni crescono di 1/0,72 = 1,39 volte e la vita a fatica scende a 0,72³ ≈ 37 %. Esempio didattico: il rapporto reale dipende da come il progettista ha sfruttato il materiale. Per questo l'uso esteso dell'alta resistenza dagli anni '80 ha portato più cricche di fatica in servizio e le regole hanno introdotto verifiche specifiche (vedi anche la U.D. 2.2.2 di coperta e la lezione 3).", dur=4)

# ---------------- 35 Materiali d'apporto ----------------
def d35():
    o = [grid('Materiali d\'apporto (UR W17)', ['Grado', 'Per acciai', 'Prova Charpy'], [
        ('1, 2, 3', 'normali A–E', '+20, 0, −20 °C'), ('1Y … 4Y', 'fino a 355 N/mm²', 'fino a −40 °C'), ('2Y40 … 5Y40', 'fino a 390 N/mm²', 'fino a −60 °C')],
        [28, 200, 420], y0=62, rh=50, size=15)]
    o.append(R(28, 280, 610, 150, SOFTY, YEL, 2, 10))
    o.append(T(44, 308, 'Suffissi: S, T, M, TM, V = processo di saldatura', 14, True, '#7A5200', maxw=580))
    o.append(T(44, 334, 'H15, H10, H5 = idrogeno diffusibile controllato', 14, False, INK, maxw=580))
    o.append(T(44, 360, 'il numero più alto copre i gradi più bassi', 14, False, INK, maxw=580))
    o.append(T(44, 386, 'stesso gruppo di resistenza', 14, False, INK, maxw=580))
    o.append(T(44, 412, 'esempio: 3Y salda A, B, D, E, A36, D36, E36', 14, True, INK, maxw=580))
    return ''.join(o)
add(E8, 'Materiali d\'apporto',
    ['Anche gli **elettrodi** hanno un grado',
     'Numero = **tenacità**, Y = **alta resistenza**',
     'Approvati dalla classe (**UR W17**)',
     'Basso idrogeno: **H5, H10**'],
    'gradi dei materiali d\'apporto e loro uso', d35(),
    "IACS UR W17 Rev.6 (2021), approvazione dei materiali d'apporto per acciai da scafo. Tre gruppi di resistenza: normali (gradi 1, 2, 3), alta resistenza fino a 355 N/mm² (1Y, 2Y, 3Y, 4Y), alta resistenza fino a 390 N/mm² (2Y40, 3Y40, 4Y40, 5Y40). Il numero è legato alla temperatura della prova Charpy sul metallo depositato (per esempio 3 e 3Y a −20 °C, 4Y a −40 °C, 5Y40 a −60 °C). Un materiale che soddisfa un grado di tenacità superiore vale anche per i gradi inferiori dello stesso gruppo. La tabella 1 della UR collega i gradi d'apporto ai gradi di acciaio: per esempio 3Y salda A, B, D, E e gli A, D, E 32/36. Suffissi del processo (S arco sommerso, M e TM fili per saldatura semiautomatica, T tecnica a due passate, V verticale per elettrogas o elettroscoria) e marchi dell'idrogeno diffusibile (H15, H10, H5). A bordo: per riparazioni chiedere elettrodi approvati del grado giusto.")

# ---------------- 36 Saldare acciai diversi ----------------
def d36():
    return rows('Saldare acciai diversi (W17, note)', [
        ('Normale + HT', 'basta l\'apporto del grado più basso accettabile per l\'uno o l\'altro', 'b'),
        ('Stessa resistenza', 'tenacità diversa: grado più basso accettabile per l\'uno o l\'altro', 'b'),
        ('Basso idrogeno', 'consigliato per gli HT; altri solo con Ceq ≤ 0,41 %', 'r'),
        ('1Y su HT', 'spessore massimo 25 mm', 'y'),
        ('Procedura', 'qualificata (W28) e saldatori qualificati (W32)', 'g')], y0=62, lw=150, size=14)
add(E8, 'Saldare acciai diversi',
    ['Scegliere l\'apporto per **entrambi** i materiali',
     'Per gli HT: elettrodi a **basso idrogeno**',
     'Procedura **qualificata**, saldatore qualificato',
     'In dubbio: chiedere alla **classe**'],
    'regole per i giunti tra acciai diversi', d36(),
    "IACS UR W17 Rev.6, note alla tabella 1: (a) unendo acciaio normale ad alta resistenza si possono usare materiali d'apporto del grado più basso accettabile per l'uno o per l'altro materiale; (b) lo stesso vale unendo acciai dello stesso livello di resistenza ma di tenacità diversa; (c) si raccomandano materiali a idrogeno controllato per gli acciai ad alta resistenza; altri materiali sono ammessi a discrezione della società quando il carbonio equivalente non supera 0,41 %; (e) con l'apporto di grado 1Y su acciai ad alta resistenza lo spessore non deve superare 25 mm. Procedure di saldatura qualificate secondo UR W28 e saldatori qualificati secondo UR W32 (lezione 2). Esempio da discutere: riparazione di un trincarino EH36 con un inserto: elettrodo almeno 3Y, basso idrogeno, procedura approvata.")

# ---------------- 37 Riparazioni ----------------
def d37():
    return vflow('Sostituire un materiale in riparazione', [('Piano dei gradi', 'che cosa c\'era: grado e spessore'), ('Stesso grado', 'o tenacità superiore, stesso livello di resistenza'),
                 ('Certificato', 'del nuovo materiale (W11, 17)'), ('Classe', 'approva la riparazione'), ('Documenti', 'registrare e conservare a bordo')],
                 colors=[BLUE, GREEN, BLUE, RUST, STEEL], note='Mai un grado inferiore o un livello di resistenza diverso senza nuova verifica')
add(E8, 'Riparazioni: sostituire un materiale',
    ['Si parte dal **piano dei gradi** di bordo',
     'Stesso grado o **superiore**, stesso livello di resistenza',
     'Materiale **certificato** e approvato',
     'Ogni riparazione strutturale passa dalla **classe**'],
    'sequenza per sostituire un materiale in riparazione', d37(),
    "Regola pratica: in una riparazione si usa lo stesso grado e lo stesso livello di resistenza del materiale originale, oppure un grado di tenacità superiore con lo stesso livello di resistenza; un livello di resistenza diverso richiede una nuova verifica degli spessori (il fattore k cambia). Il riferimento è il piano dei gradi di acciaio che le CSR chiedono di tenere a bordo (Pt 1 Ch 3 Sec 1 [2.1.5]) e i piani approvati. Il nuovo materiale deve essere certificato (UR W11, paragrafo 17). Le riparazioni strutturali sono concordate con la società di classifica e, per la qualità di esecuzione, si fa riferimento allo standard IACS Rec. 47 (Shipbuilding and Repair Quality Standard), parte B riparazioni. Un esempio pratico: sostituire una lamiera EH36 di 20 mm del trincarino con un DH36 è un declassamento della tenacità e non è accettabile senza approvazione.")

# ---------------- 38 Temperatura in servizio ----------------
def d38():
    return rows('Acciaio e temperatura in servizio', [
        ('Ponte esposto', 'in climi freddi è la zona più fredda della trave-scafo', 'b'),
        ('Cisterne riscaldate', 'differenze di temperatura → tensioni termiche', 'r'),
        ('Carichi refrigerati', 'paratie e cieli raffreddati dal carico', 'b'),
        ('Gas liquefatti', 'acciai al nichel, inox, alluminio (UR W1, Codice IGC)', 'y'),
        ('Incendio', 'oltre 400–500 °C l\'acciaio perde resistenza', 'r')], y0=62, lw=170, size=14)
add(E8, 'Acciaio e temperatura in servizio',
    ['Il **freddo** riduce la tenacità',
     'Le **differenze** di temperatura creano tensioni',
     'Gas liquefatti: **acciai speciali**',
     'Il **calore** riduce la resistenza'],
    'situazioni di bordo in cui la temperatura conta', d38(),
    "Collegare i gradi alle situazioni reali. Il ponte esposto in climi freddi è la parte più fredda e più sollecitata della trave-scafo: per questo i gradi D ed E sono richiesti nelle zone più tese e le navi per climi freddi hanno requisiti aggiuntivi. Le cisterne di carico o di combustibile riscaldate generano differenze di temperatura con le strutture adiacenti e quindi tensioni termiche (uno dei fattori citati nei casi di frattura fragile). Le navi frigorifere raffreddano paratie e cieli. Le gasiere usano per i contenitori del carico acciai al nichel, acciai inossidabili austenitici o leghe di alluminio, secondo la temperatura del gas (UR W1 e Codice IGC). Un ufficiale di macchina deve ricordare anche l'effetto opposto: in un incendio l'acciaio da costruzione perde gran parte della resistenza già oltre 400–500 °C, da cui l'isolamento delle paratie (lezione 2 per l'alluminio).")

# ---------------- 39 Verifica in servizio ----------------
def d39():
    return vflow('Come la classe segue l\'acciaio in servizio', [('Visite', 'annuali, intermedie, di rinnovo'), ('Spessimetria', 'misure a ultrasuoni, ditte approvate'),
                 ('Confronto', 'con lo spessore di rinnovo'), ('Decisione', 'tenere, sorvegliare o sostituire')],
                 colors=[BLUE, BLUE, RUST, GREEN], note='Approfondimento nella lezione 3: corrosione, protezione e bacino')
add(E9, 'Come la classe verifica in servizio',
    ['**Visite** periodiche dello scafo',
     '**Spessimetria** a ultrasuoni',
     'Confronto con lo **spessore di rinnovo**',
     'Sostituzione con materiale **equivalente**'],
    'controllo del materiale durante la vita della nave', d39(),
    "Collegamento con la lezione 3. Durante la vita della nave la società di classifica controlla lo stato della struttura con visite annuali, intermedie e di rinnovo; nelle navi soggette al programma ESP (portarinfuse, petroliere) con visite ravvicinate e misure di spessore crescenti con l'età (IACS UR Z10.x). Le misure si fanno a ultrasuoni da ditte approvate; lo spessore misurato si confronta con lo spessore di rinnovo (per le navi CSR: spessore di costruzione meno margine di corrosione e aggiunte volontarie). Quando un elemento va rinnovato, si sostituisce con materiale dello stesso grado o equivalente, certificato, come visto nella slide 37.", dur=4)

# ---------------- 40 Tabella riepilogo ----------------
def d40():
    return grid('Gli acciai da scafo in una tabella', ['Grado', 'ReH', 'k', 'Prova Charpy', 'Dove'], [
        ('A', '235', '1,00', 'solo oltre 50 mm', 'fianco, interni'), ('B', '235', '1,00', '0 °C', 'classi I–III sottili'),
        ('D', '235', '1,00', '−20 °C', 'classi II–III medie'), ('E', '235', '1,00', '−40 °C', 'classe III spessa'),
        ('AH/DH/EH32', '315', '0,78', '0, −20, −40 °C', 'come sopra, HT'), ('AH/DH/EH36', '355', '0,72', '0, −20, −40 °C', 'ponte, fondo, cinta'),
        ('AH/DH/EH40', '390', '0,68', '0, −20, −40 °C', 'grandi navi'), ('F32–F40', '315–390', '0,78–0,68', '−60 °C', 'navi per il freddo')],
        [28, 160, 236, 306, 462], y0=58, rh=42, size=14)
add(E9, 'Tabella riepilogativa',
    ['Lettera: **tenacità**',
     'Numero: **snervamento** e fattore k',
     'Classe del materiale: **dove** si usa',
     'Una pagina da **stampare** e ripassare'],
    'riepilogo dei gradi di acciaio da scafo', d40(),
    "Tabella di ripasso costruita sui dati delle slide 12–15 (UR W11 tabelle 6 e 7, UR S4 e CSR Pt 1 Ch 3 Sec 1). La colonna 'Dove' è indicativa: il grado effettivo di un elemento dipende dalla sua classe di materiale, dalla posizione rispetto a 0,4 L e dallo spessore (tabella 7 delle CSR). Consigliare ai corsisti di stampare questa pagina insieme alla tabella della slide 15 per l'esame.")

# ---------------- 41 Domanda C.5 ----------------
def d41():
    return rows('Domanda C.5: schema di risposta', [
        ('1. Apertura', 'a bordo: acciai, ghise, leghe di rame e di alluminio, inox, non metallici', 'b'),
        ('2. Acciaio da scafo', 'gradi A–E e AH–FH, k, classi di materiale', 'b'),
        ('3. Macchina', 'fucinati e getti, assi, caldaie, tubi', 'b'),
        ('4. Proprietà', 'meccaniche (ReH, Rm, A, KV, durezza) e tecnologiche', 'r'),
        ('5. Controllo', 'produttori approvati, prove, certificati, classe', 'g')], y0=62, lw=170, size=14)
add(E9, 'Domanda d\'esame C.5 svolta',
    ['**Elencare** i materiali e dove stanno',
     'Per ognuno: **proprietà** che servono',
     'Citare **requisiti** e **prove**',
     'Chiudere con il **controllo** della classe'],
    'traccia di risposta alla domanda C.5', d41(),
    "Traccia di risposta per 'Il candidato parli dei materiali più usati a bordo, elencando anche le proprietà tecnologiche dei materiali' (Meccanica C, domanda 5). 1) Panoramica: acciai al carbonio-manganese per lo scafo; acciai fucinati e getti per assi, timone, alberi a gomiti; ghise per basamenti e corpi di valvole; leghe di rame per eliche e tubolature d'acqua di mare; leghe di alluminio per sovrastrutture; acciai inossidabili; materiali non metallici (lezione 2). 2) Acciaio da scafo: gradi, resistenza e tenacità, fattore k, classi di materiale. 3) Macchina: fucinati e getti, materiali per caldaie e tubi. 4) Proprietà meccaniche e tecnologiche (slide 30) con un esempio per ciascuna. 5) Controllo: produttori approvati, prove davanti all'ispettore, marcatura e certificato. Tempo indicativo all'orale: 5 minuti.")

# ---------------- 42 Domande tipo ----------------
def d42():
    o = [head('Domande in stile esame')]
    qs = ['Perché il grado E costa più del grado A?', 'Che cosa misura la prova Charpy?', 'Che cosa significa la sigla EH36 TM Z35?',
          'Perché un acciaio HT non è più rigido?', 'Quale elettrodo per saldare A con AH36?']
    for i, q in enumerate(qs):
        y = 60 + i * 76
        o.append(C(46, y + 30, 16, RUST)); o.append(T(46, y + 36, str(i + 1), 16, True, '#fff', 'middle'))
        o.append(R(72, y + 6, 566, 50, '#F6F4EE', LINE, 1.5, 8)); o.append(T(86, y + 37, q, 16, True, INK, maxw=540))
    return ''.join(o)
add(E9, 'Domande in stile esame',
    ['Risposte **brevi** con il **perché**',
     'Citare il **requisito** quando serve',
     'Usare i **numeri** della lezione',
     'Lavoro individuale, poi **correzione**'],
    'cinque domande di verifica', d42(),
    "Risposte attese. 1) Il grado E richiede acciaio calmato a grano fine, normalizzato o TM e prove Charpy a −40 °C su ogni lotto: processo e controlli più costosi. 2) L'energia assorbita dalla rottura di un provino con intaglio a V a una temperatura data: misura la tenacità, cioè la resistenza alla frattura fragile. 3) Alta resistenza con snervamento 355 N/mm², provato a −40 °C, fornito termomeccanico, con proprietà nello spessore Z35 (strizione media ≥ 35 %). 4) Perché il modulo elastico E è lo stesso per tutti gli acciai: la rigidezza dipende da E e dalla geometria, e strutture più sottili sono meno rigide. 5) Un materiale d'apporto del grado più basso accettabile per l'uno o l'altro acciaio (UR W17 nota a): per esempio grado 2 o 3 adatto all'acciaio A, preferibilmente a basso idrogeno; in pratica si sceglie spesso un 2Y o 3Y.")

# ---------------- 43 Esercizio finale ----------------
def d43():
    o = [grid('Esercizio: scegli il grado minimo (CSR, tab. 7)', ['Elemento a centro nave', 'Classe', 't', 'Acciaio', 'Grado?'], [
        ('Cinta (L = 220 m)', 'III', '22 mm', 'HT', '?'), ('Fondo', 'II', '18 mm', 'MS', '?'), ('Fianco', 'I', '14 mm', 'MS', '?'),
        ('Trincarino (L = 280 m)', 'III', '28 mm', 'HT', '?')], [28, 288, 372, 452, 540], y0=62, rh=56, size=15)]
    o.append(T(28, 376, 'MS = acciaio normale · HT = alta resistenza', 14, False, GRAY, maxw=610))
    o.append(T(28, 400, 'attenzione alla tabella 5 per le navi oltre 250 m', 14, True, RUST, maxw=610))
    return ''.join(o)
add(E9, 'Esercizio finale: scegliere il grado',
    ['Usare la **tabella 7** delle CSR (slide 15)',
     'Classe, spessore e tipo di acciaio',
     'Controllare i **minimi** per le navi lunghe',
     'Individuale, **5 minuti**'],
    'quattro elementi strutturali da assegnare a un grado', d43(),
    "Esercizio sulla tabella CSR Pt 1 Ch 3 Sec 1 tabella 7 (slide 15) e sulle tabelle 4 e 5. Soluzione nella slide seguente: cinta di classe III, 22 mm, alta resistenza → DH (tabella 7, 20–25 mm); fondo classe II, 18 mm, acciaio normale → A; fianco classe I, 14 mm → A; trincarino di classe III, 28 mm, alta resistenza su nave di 280 m → dalla tabella 7 DH, ma la tabella 5 per navi oltre 250 m impone E/EH entro 0,4 L: quindi EH. Classi di materiale e lunghezze sono dati dell'esercizio.")

# ---------------- 44 Soluzione ----------------
def d44():
    o = [grid('Soluzione', ['Elemento', 'Grado', 'Perché'], [
        ('Cinta, 22 mm HT', 'DH', 'classe III, 20–25 mm'), ('Fondo, 18 mm MS', 'A', 'classe II, 15–20 mm'),
        ('Fianco, 14 mm MS', 'A', 'classe I, ≤ 15 mm'), ('Trincarino, 28 mm HT', 'EH', 'tab. 7 dà DH, ma L > 250 m: E/EH')],
        [28, 260, 360], y0=62, rh=58, size=15, fills=[None, None, None, SOFTR])]
    o.append(callout(372, 'Prima la classe e lo spessore, poi i minimi per la lunghezza', 'g', h=50, size=15))
    return ''.join(o)
add(E9, 'Soluzione dell\'esercizio finale',
    ['Cinta: **DH** · Fondo e fianco: **A**',
     'Trincarino di una nave lunga: **EH**',
     'Le tabelle di minimo **prevalgono**',
     'Il piano dei gradi di bordo dà la **risposta reale**'],
    'soluzione con il ragionamento per ogni elemento', d44(),
    "Soluzione commentata. Cinta: classe III entro 0,4 L, 22 mm, HT → DH (tabella 7). Fondo: classe II, 18 mm, MS → A. Fianco: classe I, 14 mm, MS → A. Trincarino: classe III, 28 mm, HT → DH secondo la tabella 7, ma la tabella 5 (navi oltre 250 m) richiede grado E/EH per cinta e trincarino entro 0,4 L: quindi EH. Sottolineare il metodo: prima la classe del materiale dell'elemento, poi lo spessore, poi i requisiti aggiuntivi per lunghezza e tipo di nave. Nella realtà la risposta è già scritta nel piano dei gradi della nave.", dur=4)

# ---------------- 45 Sintesi ----------------
def d45():
    o = [head('Tre idee da portare a bordo')]
    ideas = [('La lettera è la tenacità', 'A, B, D, E, F: temperatura della prova Charpy'), ('Il numero è la resistenza', '32, 36, 40: snervamento e fattore k'),
             ('Ogni pezzo è tracciabile', 'marcatura, certificato, piano dei gradi')]
    for i, (t, s) in enumerate(ideas):
        y = 70 + i * 116
        o.append(C(60, y + 40, 22, RUST)); o.append(T(60, y + 47, str(i + 1), 20, True, '#fff', 'middle'))
        o.append(R(100, y, 538, 84, '#F6F4EE', LINE, 1.5, 10)); o.append(T(118, y + 34, t, 18, True, INK, maxw=500)); o.append(T(118, y + 62, s, 15, False, GRAY, maxw=500))
    o.append(T(333, 440, 'Prossima lezione, 20/11: altri materiali, saldatura e prove', 14, True, BLUE, 'middle', maxw=600))
    return ''.join(o)
add('PARTE 2 · SINTESI', 'Sintesi della lezione',
    ['**Gradi**: lettera = tenacità, numero = resistenza',
     '**Classi** di materiale e spessore: dove va ogni grado',
     '**Prove**, marcatura e certificato',
     'Prossima volta: **altri materiali e saldatura**'],
    'le tre idee chiave della lezione', d45(),
    "Chiusura. Riprendere le tre idee e annunciare la lezione del 20 novembre: acciai inossidabili, ghise, leghe di alluminio e di rame, compositi e materiali non metallici; saldatura, qualifica dei procedimenti, difetti e controlli non distruttivi; saldatura a bordo e in una cassa combustibile (domanda C.14). Chiedere ai corsisti di portare la tabella riepilogativa (slide 40).")
