"""Grafici semplici (curve di carico, taglio, momento) per i diagrammi SVG."""
from lib import *

def integ(xs, ys):
    out = [0.0]
    for i in range(1, len(xs)):
        out.append(out[-1] + (ys[i] + ys[i - 1]) / 2 * (xs[i] - xs[i - 1]))
    return out

def beam(segs, L=100.0, n=400, light=None):
    """segs: lista (x0, x1, peso_t). Spinta uniforme = peso totale / L (chiatta).
    Ritorna xs, carico (t/m, peso-spinta), SF (t), BM (t·m)."""
    xs = [L * i / n for i in range(n + 1)]
    tot = sum(p for _, _, p in segs)
    b = tot / L
    q = []
    for x in xs:
        w = 0.0
        for a, c, p in segs:
            if a <= x < c or (x == L and c == L):
                w += p / (c - a)
        q.append(w - b)
    sf = integ(xs, q)
    bm = integ(xs, sf)
    return xs, q, sf, bm

def mapper(x, y, w, h, xmin, xmax, ymin, ymax):
    def f(xx, yy):
        return (x + (xx - xmin) / (xmax - xmin) * w, y + h - (yy - ymin) / (ymax - ymin) * h)
    return f

def curve(f, xs, ys, col, sw=3, dash=None):
    pts = [f(a, b) for a, b in zip(xs, ys)]
    return P(pts, 'none', col, sw, close=False, dash=dash)

def area(f, xs, ys, col, op=0.18):
    pts = [f(xs[0], 0)] + [f(a, b) for a, b in zip(xs, ys)] + [f(xs[-1], 0)]
    return P(pts, col, 'none', 0, op=op)

def panel(x, y, w, h, xmin, xmax, ymin, ymax, label, col, xs, ys, fill=True, lab_size=15):
    f = mapper(x, y, w, h, xmin, xmax, ymin, ymax)
    o = [R(x, y, w, h, '#FAF9F5', LINE, 1, 4)]
    zx0, zy = f(xmin, 0); zx1, _ = f(xmax, 0)
    o.append(L(zx0, zy, zx1, zy, GRAY, 1.5))
    if fill:
        o.append(area(f, xs, ys, col))
    o.append(curve(f, xs, ys, col, 3))
    o.append(R(x + 4, y + 3, tw(label, lab_size, True) + 9, lab_size * FS + 6, '#FAF9F5', None, 0, 3))
    o.append(T(x + 8, y + 18, label, lab_size, True, col))
    return ''.join(o), f
