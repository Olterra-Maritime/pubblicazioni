"""Lezione 1 (13/11/2026) · U.D. 4.1.1 A · Acciai da costruzione navale · parte 1 (slide 2-22)."""
import math
from lib import *

S = []
def add(eyebrow, title, bullets, caption, diagram, notes):
    S.append(dict(eyebrow=eyebrow, title=title, bullets=bullets, caption=caption, diagram=svg(diagram), notes=notes))

E1 = 'PARTE 1 · INTRODUZIONE'
E2 = 'PARTE 1 · PROPRIETÀ E PROVE'
E3 = 'PARTE 1 · GRADI DI ACCIAIO'
E4 = 'PARTE 1 · DOVE SI USANO'
E5 = 'PARTE 1 · DOCUMENTI'

# ---------------- 2 Obiettivi e fonti ----------------
def d2():
    return programma_fonti(['08:30', '10:20', '10:40', '12:30'], [
        ('IACS UR W11', 'Rev.9 mag 2017 (Rev.10 dal 1/1/2027)'),
        ('IACS UR W2 · W13 · W14', 'Rev.3 2021 · Rev.7 2021 · Rev.3 2021'),
        ('IACS UR W7 · W8', 'Rev.4 2022 · Rev.4 2024 (Rev.5 dal 2027)'),
        ('IACS UR W16 · W31', 'Rev.3 2016 · Rev.3 mar 2023'),
        ('IACS UR W17 · W28', 'Rev.6 2021 · Rev.2 2012 (Rev.3 dal 2027)'),
        ('IACS UR S4', 'Rev.4 apr 2017'),
        ('CSR BC & OT (IACS)', 'ed. 1 luglio 2025 · Pt 1 Ch 3 Sec 1'),
        ('Programma ed esami', 'D.D. 201/2024, allegato B, Funzione 4')])
add(E1, 'Obiettivi, orario e fonti',
    ['Riconoscere i **gradi** di acciaio da scafo',
     'Leggere le **prove**: trazione, Charpy, durezza',
     'Sapere **dove va** ogni grado sulla nave',
     'Leggere **marcatura e certificato** di una lamiera'],
    'scansione oraria e fonti con la revisione usata', d2(),
    "Min 08:35. Prima lezione della U.D. 4.1.1 A, Materiali impiegati nella costruzione navale (12 ore: 13, 20 e 27 novembre). Oggi gli acciai da costruzione navale; il 20 novembre gli altri materiali, la saldatura e le prove non distruttive; il 27 novembre corrosione, protezione e bacino. Fonti e revisioni usate, verificate il 30/10/2026 sul sito IACS (copie in DIR MAC 54/Fonti/IACS_UR_W): UR W11 Rev.9 (maggio 2017), acciai da scafo normali e ad alta resistenza; la Rev.10 (settembre 2025) si applica alle navi con contratto dal 1° gennaio 2027; UR W2 Rev.3 (2021) provini e prove meccaniche; UR W13 Rev.7 (2021) tolleranze di spessore; UR W14 Rev.3 (2021) acciai con proprietà nello spessore (Z); UR W7 Rev.4 (2022) fucinati e UR W8 Rev.4 (2024) getti di acciaio, entrambe con Rev.5 dal 1° gennaio 2027; UR W16 Rev.3 (2016) acciai ad alta resistenza bonificati; UR W31 Rev.3 (2023) acciai YP47 e crack arrest; UR W17 Rev.6 (2021) materiali d'apporto; UR W28 Rev.2 (2012) qualifica dei procedimenti, Rev.3 dal 2027; UR S4 Rev.4 (2017) fattore k; CSR edizione 1 luglio 2025, Pt 1 Ch 3 Sec 1 (materiali). Programma: D.D. 201/2024, allegato B, Funzione 4.")

# ---------------- 3 Dove sta la U.D. ----------------
def d3():
    o = [head('La U.D. 4.1.1 A nel corso')]
    o.append(R(28, 58, 610, 70, SOFTR, RUST, 2, 10))
    o.append(T(44, 86, 'D.D. 201/2024 · allegato B · Funzione 4', 16, True, RUST))
    o.append(T(44, 110, 'Controlla l\'assetto, la stabilità e gli sforzi · 101 ore in aula', 14, False, INK, maxw=580))
    tiles = [('4.1.1 A · oggi', 'materiali della costruzione navale · 12 h', 'r'), ('4.1.1 B', 'principi della costruzione navale · 21 h', 'b'),
             ('4.1.1 C e 4.1.2', 'assetto, stabilità, allagamento', 'b'), ('4.1.1 D', 'costruzione navale in inglese · 8 h', 'b')]
    bw = (610 - 14) / 2
    for i, (t, s, k) in enumerate(tiles):
        o.append(tile(28 + (i % 2) * (bw + 14), 144 + (i // 2) * 84, bw, 72, t, s, k, 16, 14))
    o.append(R(28, 320, 610, 64, '#EFEDE7', STEEL, 2, 10))
    o.append(T(44, 346, 'Già svolta: U.D. 1.2.8 Tecnologia dei materiali', 15, True, INK, maxw=580))
    o.append(T(44, 368, 'produzione dell\'acciaio, prove distruttive e non distruttive', 14, False, GRAY, maxw=580))
    o.append(callout(398, 'Oggi: l\'acciaio come lo vede la classe e il bordo', 'y', h=46, size=15))
    return ''.join(o)
add(E1, 'Dove sta questa unità didattica',
    ['Funzione 4: **assetto, stabilità e sforzi**',
     'I **materiali** della nave, visti dalla classe',
     'La produzione dell\'acciaio è già nella **1.2.8**',
     'Legata alla **4.1.1 B**: principi di costruzione'],
    'la U.D. 4.1.1 A tra le unità del corso', d3(),
    "Il D.D. 201/2024 (allegato B) assegna alla Funzione 4, competenza 'Controlla l'assetto, la stabilità e gli sforzi', 101 ore in aula: principi della costruzione navale, sollecitazioni, dinamica della nave, corrosione e prevenzione, ispezioni e bacini, stabilità, resistenza al moto, timoni. È la competenza della tabella STCW A-III/2 per direttori e primi ufficiali di macchina. Nel calendario del corso la U.D. 4.1.1 A (materiali, 12 ore) precede la 4.1.1 B (principi della costruzione navale, Mazzacurati), la 4.1.1 C e la 4.1.2 (assetto e stabilità, Delfino) e la 4.1.1 D (in inglese, Puppo). La produzione dell'acciaio (altoforno, convertitore, forno elettrico, colata continua, laminazione) e le prove sui materiali sono già state svolte nella U.D. 1.2.8 Tecnologia dei materiali (Giancola): qui si richiamano solo per leggere i requisiti della classe. Domande d'esame collegate (Meccanica C): 'materiali più usati a bordo e loro proprietà tecnologiche', 'corrosione dello scafo', 'operazioni in bacino'.")

# ---------------- 4 Requisiti ----------------
def d4():
    return rows('Che cosa chiediamo all\'acciaio da scafo', [
        ('Resistenza', 'snervamento ReH e rottura Rm: quanto carico porta', 'b'),
        ('Duttilità', 'allungamento A: si deforma prima di rompersi', 'b'),
        ('Tenacità', 'energia Charpy: resiste alla frattura fragile', 'r'),
        ('Saldabilità', 'carbonio equivalente basso: niente cricche', 'y'),
        ('Uniformità', 'composizione e spessore controllati, tracciabili', 'g'),
        ('Costo', 'disponibile in grandi quantità a prezzo basso', 'n')], y0=62, lw=140, size=15)
add(E1, 'Che cosa chiediamo all\'acciaio',
    ['**Resistenza** e **duttilità** insieme',
     '**Tenacità** anche al freddo',
     '**Saldabilità**: la nave è tutta saldata',
     'Qualità **costante** e **certificata**'],
    'le sei proprietà richieste all\'acciaio dello scafo', d4(),
    "Una nave è una trave saldata di decine di migliaia di tonnellate che lavora per 25 anni in mare, al caldo e al freddo, con carichi ciclici. All'acciaio si chiedono quindi: resistenza (carico unitario di snervamento ReH e di rottura Rm), duttilità (allungamento a rottura A: deve deformarsi visibilmente prima di rompersi), tenacità (capacità di assorbire energia in presenza di un intaglio, misurata con la prova Charpy, decisiva alle basse temperature), saldabilità (composizione con poco carbonio e carbonio equivalente limitato), uniformità e tracciabilità (ogni lamiera è riconducibile alla colata e certificata dalla classe) e un costo contenuto. I requisiti sono fissati da IACS UR W11 e recepiti nei regolamenti di ogni società di classifica. Domanda d'esame C.5: queste sono le 'proprietà tecnologiche' da citare insieme a quelle meccaniche.")

# ---------------- 5 Richiamo 1.2.8 ----------------
def d5():
    o = [vflow('Dalla colata alla lamiera certificata', [('Acciaieria', 'colata e analisi chimica'), ('Laminazione', 'stato di fornitura: AR, N, CR, TM, QT'),
               ('Prove', 'trazione e Charpy davanti alla classe'), ('Marcatura', 'grado, colata e timbro della classe')], colors=[STEEL, BLUE, RUST, GREEN], y0=58)]
    return ''.join(o)
add(E2, 'Richiamo dalla U.D. 1.2.8',
    ['La produzione si è vista nella **1.2.8**',
     'Qui conta lo **stato di fornitura**',
     'Le **prove** si fanno davanti alla **classe**',
     'Ogni pezzo è **tracciabile** fino alla colata'],
    'dalla colata alla lamiera e stati di fornitura', d5(),
    "Richiamo veloce: la produzione dell'acciaio è stata trattata in modo completo nella U.D. 1.2.8. Per la classe contano lo stato di fornitura e le prove. IACS UR W11 Rev.9, paragrafo 5 e tabelle 4 e 5, ammette secondo grado e spessore: as rolled (AR), normalizzato (N), laminazione controllata (CR, cioè laminazione normalizzante), termomeccanico (TM, TMCP) e, per gli acciai a 390 N/mm² e per i gradi F, anche bonificato (QT). Esempi: il grado E è sempre normalizzato o TM; il grado A fino a 50 mm può essere fornito in qualunque stato. Le prove meccaniche si eseguono su campioni prelevati dal prodotto finito, in presenza dell'ispettore della classe (W11, paragrafi 11-14), e i pezzi sono identificati dalla colata al prodotto finito (paragrafo 10).")

# ---------------- 6 Composizione chimica ----------------
def d6():
    return grid('Composizione (analisi di colata, % max)', ['Elemento', 'A', 'D', 'E', 'AH–EH', 'Effetto'], [
        ('C', '0,21', '0,21', '0,18', '0,18', 'resistenza; saldabilità ↓'),
        ('Mn', '≥ 2,5 C', '≥ 0,60', '≥ 0,70', '0,90–1,60', 'resistenza, tenacità'),
        ('Si', '0,50', '0,35', '0,35', '0,50', 'disossidante'),
        ('P, S', '0,035', '0,035', '0,035', '0,035', 'impurezze: fragilità'),
        ('Al', '–', '≥ 0,015*', '≥ 0,015', '≥ 0,015', 'grano fine'),
        ('Nb, V, Ti', '–', '–', '–', '≤ 0,12 tot.', 'microlegati: grano fine')],
        [28, 118, 196, 274, 352, 452], y0=62, rh=44, size=14)
add(E2, 'Composizione chimica',
    ['**Carbonio** basso: resistenza senza fragilità',
     '**Manganese** per resistenza e tenacità',
     '**Zolfo e fosforo**: impurezze da limitare',
     '**Microlegati** e alluminio: grano fine'],
    'limiti della UR W11 per alcuni gradi', d6(),
    "Valori di IACS UR W11 Rev.9, tabelle 1 e 2 (analisi di colata). Acciai normali: carbonio massimo 0,21 % per A, B, D e 0,18 % per E (0,23 % per i profilati di grado A); manganese minimo 2,5 volte il carbonio per A, 0,80 per B, 0,60 per D, 0,70 per E; silicio massimo 0,50 (A) e 0,35 (B, D, E); fosforo e zolfo massimo 0,035 %; carbonio più un sesto del manganese non oltre 0,40 %. Il grado D oltre 25 mm (asterisco) e il grado E sono calmati e trattati a grano fine con alluminio solubile almeno 0,015 %. Alta resistenza (A, D, E 32-36-40): C massimo 0,18 %, Mn 0,90–1,60 %, P e S massimo 0,035 % (0,025 % e C 0,16 % per i gradi F), elementi affinanti (Al, Nb 0,02–0,05, V 0,05–0,10, Ti ≤ 0,02, totale Nb+V+Ti ≤ 0,12 %). Il grano fine migliora insieme resistenza e tenacità. Per la U.D. 1.2.8 i corsisti conoscono già il ruolo dei singoli elementi: qui basta collegarli ai numeri della classe.")

# ---------------- 7 Carbonio equivalente ----------------
def d7():
    o = [head('Carbonio equivalente e saldabilità')]
    o.append(R(28, 62, 610, 64, SOFTB, BLUE, 2, 10))
    o.append(T(333, 102, 'Ceq = C + Mn/6 + (Cr + Mo + V)/5 + (Ni + Cu)/15', 18, True, BLUE, 'middle', maxw=590))
    o.append(T(28, 156, 'Esempio: C 0,16 · Mn 1,40 · Cr 0,05 · Ni 0,10 · Cu 0,10', 15, True, INK, maxw=610))
    o.append(T(28, 182, 'Ceq = 0,16 + 0,233 + 0,010 + 0,013 = 0,42 %', 15, False, INK, maxw=610))
    o.append(grid(None, ['Grado TM (W11, tab. 3)', 't ≤ 50 mm', '50 < t ≤ 100 mm'], [
        ('A–F 32', '0,36', '0,38'), ('A–F 36', '0,38', '0,40'), ('A–F 40', '0,40', '0,42')], [28, 300, 460], y0=206, rh=38, size=15))
    o.append(callout(370, 'Ceq alto: zona termicamente alterata dura, rischio di cricche a freddo, serve preriscaldo', 'r', h=56, size=14))
    return ''.join(o)
add(E2, 'Carbonio equivalente',
    ['Un numero per la **saldabilità**',
     'Somma pesata di **C e leganti**',
     'Limiti per gli acciai **TM** (W11)',
     'Ceq alto → **preriscaldo** e cautela'],
    'formula IIW del carbonio equivalente e limiti W11', d7(),
    "IACS UR W11, tabella 2 nota 6 e paragrafo 4.3: il carbonio equivalente Ceq = C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15, calcolato sull'analisi di colata, dà un'indicazione generale della saldabilità degli acciai al carbonio-manganese. Per gli acciai ad alta resistenza forniti termomeccanici (TM) i limiti sono quelli della tabella 3: 0,36 % (32), 0,38 % (36), 0,40 % (40) fino a 50 mm e 0,02 in più tra 50 e 100 mm. In alternativa la classe può usare l'indice Pcm di suscettibilità alle cricche a freddo. Esempio numerico della slide: con C 0,16, Mn 1,40, Cr 0,05, Ni 0,10, Cu 0,10 si ottiene circa 0,42 %: sopra il limite di un AH36 TM fino a 50 mm. Messaggio pratico per la riparazione a bordo: più è alto il Ceq, più la zona termicamente alterata tende a indurire e a criccare; si usa preriscaldo, elettrodi a basso idrogeno e procedura qualificata (lezione 2).")

# ---------------- 8 Prova di trazione ----------------
def d8():
    o = [head('Prova di trazione: diagramma σ–ε')]
    X0, Y0, PW, PH = 70, 70, 540, 300
    def px(e): return X0 + e / 0.30 * PW
    def py(s): return Y0 + PH - s / 560 * PH
    o.append(L(X0, Y0 + PH, X0 + PW, Y0 + PH, INK, 2)); o.append(L(X0, Y0, X0, Y0 + PH, INK, 2))
    pts = [(0, 0), (0.0017, 360), (0.004, 340), (0.02, 345)]
    for i in range(1, 41):
        e = 0.02 + (0.18 - 0.02) * i / 40
        s = 345 + (520 - 345) * math.sin(math.pi / 2 * (e - 0.02) / 0.16)
        pts.append((e, s))
    for i in range(1, 16):
        e = 0.18 + 0.08 * i / 15
        pts.append((e, 520 - 120 * (i / 15) ** 2))
    o.append(P([(px(e), py(s)) for e, s in pts], 'none', BLUE, 3.5, False))
    o.append(L(X0, py(355), X0 + PW, py(355), RUST, 1.5, '6 4')); o.append(T(X0 + 60, py(355) + 20, 'ReH 355', 14, True, RUST))
    o.append(L(X0, py(520), X0 + PW, py(520), GREEN, 1.5, '6 4')); o.append(T(X0 + 210, py(520) - 8, 'Rm 520', 14, True, GREEN))
    o.append(C(px(0.26), py(400), 6, RUST)); o.append(T(px(0.26) + 4, py(400) + 26, 'rottura', 13, True, RUST, 'middle'))
    o.append(A(px(0.0), Y0 + PH + 26, px(0.26), Y0 + PH + 26, INK, 2, 8)); o.append(T(px(0.13), Y0 + PH + 46, 'allungamento A ≥ 21 %', 14, True, INK, 'middle'))
    o.append(T(X0 + 6, Y0 - 10, 'σ (N/mm²)', 13, True, INK)); o.append(T(X0 + PW, Y0 + PH - 8, 'ε', 15, True, INK, 'end'))
    o.append(T(px(0.03), py(150), 'campo elastico: E ≈ 206 000 N/mm²', 13, False, GRAY))
    return ''.join(o)
add(E2, 'Prova di trazione',
    ['**ReH**: snervamento, il valore di progetto',
     '**Rm**: carico di rottura, entro un intervallo',
     '**A %**: allungamento su provino proporzionale',
     'Provini e procedure: **IACS UR W2**'],
    'curva sforzo-deformazione schematica di un AH36', d8(),
    "Richiamo dalla U.D. 1.2.8 applicato ai requisiti di classe. Prova di trazione secondo IACS UR W2 Rev.3 (2021): provini proporzionali con tratto utile L0 = 5,65 √S0. Si misurano il carico unitario di snervamento superiore ReH (o lo 0,2 % Rp0,2 se lo snervamento non è evidente, W11 paragrafo 6.1), il carico unitario di rottura Rm e l'allungamento percentuale A. Per un AH36 la UR W11 (tabella 7) richiede ReH ≥ 355 N/mm², Rm 490–630 N/mm², A ≥ 21 %. Il diagramma è schematico (scala delle deformazioni non lineare dopo lo snervamento). Far notare: il progettista usa ReH (con il fattore k), non Rm; un intervallo massimo per Rm evita acciai troppo duri e poco saldabili. Il modulo elastico E, circa 206 000 N/mm² per l'acciaio, è lo stesso per tutti i gradi: un acciaio ad alta resistenza non è più rigido.")

# ---------------- 9 Charpy ----------------
def d9():
    o = [head('Prova Charpy con intaglio a V (UR W2)')]
    # provino
    o.append(R(60, 120, 260, 52, '#C9D6DE', HULL, 2, 2))
    o.append(P([(182, 120), (190, 136), (198, 120)], '#FFFFFF', HULL, 2))
    o.append(T(190, 200, '55 × 10 × 10 mm', 14, True, INK, 'middle'))
    o.append(T(190, 222, 'intaglio a V: 2 mm, 45°, r = 0,25 mm', 13, False, GRAY, 'middle'))
    # pendolo
    o.append(C(500, 90, 8, INK)); o.append(L(500, 90, 430, 270, INK, 3)); o.append(R(400, 262, 60, 34, STEEL, INK, 2, 4))
    o.append(PATH('M 500 90 m -120 60 a 140 140 0 0 0 40 60', 'none', GRAY, 2, '5 4'))
    o.append(T(560, 170, 'pendolo', 14, True, INK))
    o.append(R(28, 320, 610, 110, SOFTB, BLUE, 2, 10))
    o.append(T(44, 348, 'Risultato: energia assorbita KV in joule', 15, True, BLUE, maxw=580))
    o.append(T(44, 372, '3 provini: conta la media; uno solo può essere più basso,', 14, False, INK, maxw=580))
    o.append(T(44, 394, 'ma non sotto il 70 % della media richiesta (W11, 6.4)', 14, False, INK, maxw=580))
    o.append(T(44, 416, 'alla temperatura di prova del grado', 14, False, INK, maxw=580))
    return ''.join(o)
add(E2, 'Tenacità e prova Charpy',
    ['Misura l\'**energia** per rompere un provino intagliato',
     'Si prova a **temperatura fissata** dal grado',
     '**Tre provini**: media e minimo singolo',
     'È ciò che distingue **A, B, D, E**'],
    'provino Charpy V e pendolo, schema', d9(),
    "Prova di resilienza Charpy con intaglio a V secondo IACS UR W2 Rev.3: provino 55 × 10 × 10 mm, intaglio profondo 2 mm (8 mm di sezione resistente), angolo 45°, raggio di fondo 0,25 mm, a metà lunghezza; per lamiere sottili si usano provini ridotti da 7,5 o 5 mm. Il pendolo rompe il provino e si misura l'energia assorbita KV in joule. UR W11, paragrafo 6.4: si provano serie di tre provini; conta la media, e un solo valore può essere inferiore al valore richiesto purché non sotto il 70 %. I provini sono normalmente longitudinali (prelevati nella direzione di laminazione); i valori trasversali, più bassi, sono garantiti dal fornitore (6.3). Per spessori inferiori a 6 mm la prova di norma non si fa (6.5). La temperatura di prova è ciò che distingue i gradi: lo vediamo tra due slide.")

# ---------------- 10 Transizione ----------------
def d10():
    o = [head('Energia Charpy e temperatura')]
    X0, Y0, PW, PH = 70, 66, 548, 280
    def px(t): return X0 + (t + 80) / 120 * PW
    def py(e): return Y0 + PH - e / 220 * PH
    o.append(L(X0, Y0 + PH, X0 + PW, Y0 + PH, INK, 2)); o.append(L(X0, Y0, X0, Y0 + PH, INK, 2))
    for t in (-80, -60, -40, -20, 0, 20, 40):
        o.append(L(px(t), Y0 + PH, px(t), Y0 + PH + 6, INK, 1.5)); o.append(T(px(t), Y0 + PH + 22, f'{t}', 13, False, GRAY, 'middle'))
    def curve(t0, w, col, dash=None):
        pts = []
        for i in range(0, 121):
            t = -80 + i
            e = 10 + 190 / (1 + math.exp(-(t - t0) / w))
            pts.append((px(t), py(e)))
        o.append(P(pts, 'none', col, 3.5, False, dash))
    curve(-5, 9, STEEL, '8 5'); curve(-45, 9, BLUE)
    o.append(L(X0, py(27), X0 + PW, py(27), RUST, 1.5, '6 4')); o.append(T(X0 + 6, py(27) - 6, '27 J', 13, True, RUST))
    for t, g in [(0, 'B'), (-20, 'D'), (-40, 'E')]:
        o.append(L(px(t), py(27), px(t), Y0 + 6, RUST, 1, '3 4')); o.append(T(px(t), Y0 + 2, g, 15, True, RUST, 'middle'))
    o.append(T(px(10), py(120), 'acciaio comune', 13, True, STEEL)); o.append(T(px(-70), py(150), 'grano fine', 13, True, BLUE))
    o.append(T(X0 + PW / 2, Y0 + PH + 44, 'temperatura di prova (°C)', 14, True, INK, 'middle'))
    o.append(T(X0 + 4, Y0 + 10, 'KV (J)', 13, True, INK))
    return ''.join(o)
add(E2, 'Duttile o fragile: la temperatura',
    ['Sopra la transizione: rottura **duttile**, molta energia',
     'Sotto: rottura **fragile**, poca energia, veloce',
     'Il grado garantisce **27 J** alla sua temperatura',
     '**Grano fine** sposta la transizione al freddo'],
    'curva di transizione schematica e temperature dei gradi B, D, E', d10(),
    "La curva di transizione mostra l'energia Charpy in funzione della temperatura. Gli acciai ferritici da scafo passano da un comportamento duttile (molta energia, superficie di frattura fibrosa) a uno fragile (poca energia, frattura cristallina che si propaga a velocità molto alta) in un intervallo di temperatura. Il grado di acciaio non cambia la resistenza ma garantisce una tenacità minima a una temperatura di prova: per gli acciai normali 27 J (longitudinale, fino a 50 mm) a 0 °C per B, −20 °C per D, −40 °C per E. Il grano fine (alluminio, microlegati, normalizzazione o TMCP) sposta la curva verso le basse temperature. Le curve della figura sono schematiche, non dati di un acciaio reale.")

# ---------------- 11 Frattura fragile ----------------
def d11():
    o = [head('Perché la tenacità diventò un requisito')]
    ev = [('1943', 'Schenectady (T2): si spezza in porto', RUST), ('1943–46', 'navi Liberty e T2: centinaia di cricche', RUST),
          ('anni \'50', 'gradi con prova Charpy nelle regole', BLUE), ('1979', 'Kurdistan: frattura fragile in mare freddo', RUST),
          ('oggi', 'gradi A–F e acciai crack arrest (W31)', GREEN)]
    for i, (y, t, c) in enumerate(ev):
        yy = 74 + i * 72
        o.append(C(60, yy, 10, c, '#fff', 2)); o.append(T(84, yy + 6, y, 16, True, c))
        o.append(T(200, yy + 6, t, 15, False, INK, maxw=430))
        if i < len(ev) - 1:
            o.append(L(60, yy + 12, 60, yy + 60, LINE, 2))
    o.append(callout(420 - 26, 'Cause comuni: freddo, intagli, saldature, acciaio poco tenace', 'y', h=46, size=15))
    return ''.join(o)
add(E2, 'Frattura fragile: le lezioni',
    ['Navi **saldate** della guerra: fratture improvvise',
     'Spesso a **bassa temperatura** e da un **intaglio**',
     'Da qui la **prova Charpy** nei requisiti',
     'Il problema torna con **spessori elevati**'],
    'casi storici di frattura fragile', d11(),
    "Con il passaggio dalla chiodatura alla saldatura, durante la seconda guerra mondiale le navi Liberty e le petroliere T2 costruite negli Stati Uniti subirono numerose fratture fragili; il caso più noto è la petroliera Schenectady, che nel gennaio 1943 si spezzò in due all'ormeggio, a nave nuova e con acqua fredda. Le indagini individuarono tre fattori combinati: acciaio con temperatura di transizione alta, concentrazioni di tensione (angoli dei boccaporti, intagli, difetti di saldatura) e bassa temperatura. Da qui la classificazione degli acciai per tenacità e la prova Charpy nei regolamenti. Un caso più recente citato in letteratura è la petroliera Kurdistan (1979), che si spezzò in acque fredde con carico riscaldato. Oggi lo stesso problema si ripresenta con lamiere molto spesse sulle grandi portacontenitori: per questo esistono gli acciai crack arrest (slide 16). Date e dettagli dei casi sono di letteratura generale: verificarli prima di citarli all'esame.")

# ---------------- 12 Gradi normali ----------------
def d12():
    o = [grid('Acciai normali (W11, tabella 6)', ['Grado', 'ReH min', 'Rm', 'A %', 'Prova a', 'KV long. t ≤ 50'], [
        ('A', '235', '400–520', '22', '+20 °C*', '–'), ('B', '235', '400–520', '22', '0 °C', '27 J**'),
        ('D', '235', '400–520', '22', '−20 °C', '27 J'), ('E', '235', '400–520', '22', '−40 °C', '27 J')],
        [28, 118, 216, 330, 404, 504], y0=62, rh=46, size=15)]
    o.append(T(28, 312, 'N/mm² · tra 50 e 100 mm l\'energia sale a 34 e 41 J', 14, False, GRAY, maxw=610))
    o.append(T(28, 336, '* grado A: prova solo oltre 50 mm', 14, False, GRAY, maxw=610))
    o.append(T(28, 358, '** grado B: prova di norma non richiesta fino a 25 mm', 14, False, GRAY, maxw=610))
    o.append(callout(382, 'Stessa resistenza: cambia solo la tenacità', 'b', h=46, size=16))
    return ''.join(o)
add(E3, 'Gradi A, B, D, E',
    ['Acciaio **normale**: ReH **235** N/mm²',
     'Rm **400–520**, allungamento **22 %**',
     'La lettera dice la **temperatura** della prova',
     'Più si scende nell\'alfabeto, più **tenace**'],
    'requisiti meccanici degli acciai normali', d12(),
    "IACS UR W11 Rev.9, tabella 6. Tutti e quattro i gradi normali hanno snervamento minimo 235 N/mm², rottura 400–520 N/mm² e allungamento minimo 22 % (provino proporzionale). Cambia la prova Charpy: grado A a +20 °C ma solo oltre 50 mm di spessore (34 J tra 50 e 70 mm, 41 J tra 70 e 100 mm); grado B a 0 °C (27 J longitudinali e 20 J trasversali fino a 50 mm; di norma la prova non è richiesta fino a 25 mm); D a −20 °C; E a −40 °C, con gli stessi valori di energia. Cambiano anche la disossidazione e lo stato di fornitura: il grado E è calmato, a grano fine e normalizzato o TM. Le CSR chiamano questi acciai MS (mild steel). Errore tipico all'esame: pensare che E sia più resistente di A. Ha la stessa resistenza, ma è più tenace.")

# ---------------- 13 Alta resistenza ----------------
def d13():
    o = [grid('Alta resistenza (W11, tabella 7)', ['Livello', 'ReH min', 'Rm', 'A %', 'KV long. t ≤ 50'], [
        ('32', '315', '440–570', '22', '31 J'), ('36', '355', '490–630', '21', '34 J'), ('40', '390', '510–660', '20', '39 J')],
        [28, 140, 260, 400, 480], y0=62, rh=44, size=15)]
    o.append(grid(None, ['Lettera', 'A', 'D', 'E', 'F'], [('Prova a', '0 °C', '−20 °C', '−40 °C', '−60 °C')], [28, 140, 260, 380, 500], y0=262, rh=44, size=15))
    o.append(callout(370, 'EH36 = 355 N/mm², provato a −40 °C', 'b', h=50, size=17))
    return ''.join(o)
add(E3, 'Gradi ad alta resistenza',
    ['Tre livelli: **32, 36, 40**',
     'Snervamento **315, 355, 390** N/mm²',
     'Quattro lettere: **A, D, E, F** (fino a −60 °C)',
     'Si scrive **AH36** o **A36**: è lo stesso'],
    'requisiti degli acciai da scafo ad alta resistenza', d13(),
    "IACS UR W11 Rev.9, tabella 7: per gli acciai ad alta resistenza (HT nelle CSR) ci sono tre livelli di snervamento minimo, 315, 355 e 390 N/mm² (indicati con 32, 36, 40, dai vecchi kgf/mm²), con rottura 440–570, 490–630 e 510–660 N/mm² e allungamento 22, 21 e 20 %. Ogni livello ha quattro gradi di tenacità: A a 0 °C, D a −20 °C, E a −40 °C, F a −60 °C. Energia minima longitudinale fino a 50 mm: 31 J (32), 34 J (36), 39 J (40); valori più alti tra 50 e 100 mm. Nota 1 della tabella 2: la H si può mettere davanti o dietro (HA36 o AH36); si legge anche A36. Oltre 390 N/mm² ci sono gli acciai YP47 (460 N/mm², UR W31) e gli acciai bonificati della UR W16 per strutture saldate speciali. Le CSR (Pt 1 Ch 3 Sec 1, tabella 1) usano gli stessi valori.")

# ---------------- 14 Fattore k ----------------
def d14():
    items = [('normale 235', 1.00, STEEL, 'k = 1,00'), ('AH32 · 315', 0.78, BLUE, 'k = 0,78'), ('AH36 · 355', 0.72, BLUE, 'k = 0,72'), ('AH40 · 390', 0.68, BLUE, 'k = 0,68')]
    o = [hbars('Fattore del materiale k (UR S4, CSR)', items, y0=66, maxv=1.0, vw=300, bh=34, gap=20, lw=170, size=15)]
    o.append(R(28, 300, 610, 128, SOFTY, YEL, 2, 10))
    o.append(T(44, 330, 'Modulo di resistenza richiesto: Z ∝ k', 15, True, '#7A5200', maxw=580))
    o.append(T(44, 356, 'con AH36 serve il 72 % del modulo in acciaio normale', 14, False, INK, maxw=580))
    o.append(T(44, 382, 'Lamiera sotto pressione: t ∝ √k → circa 15 % più sottile', 14, False, INK, maxw=580))
    o.append(T(44, 408, 'tensione ammessa: 175/k e 110/k N/mm² (UR S11)', 14, False, INK, maxw=580))
    return ''.join(o)
add(E3, 'Il fattore del materiale k',
    ['Converte lo snervamento in **regole di progetto**',
     '**k < 1**: tensioni ammesse più alte',
     'Strutture **più leggere**, non più rigide',
     'Lo stesso k della **U.D. 2.2.1** di coperta'],
    'valori del fattore k e loro effetto sulle dimensioni', d14(),
    "Il fattore del materiale k (IACS UR S4 Rev.4 del 2017 e CSR Pt 1 Ch 3 Sec 1, tabella 2) vale 1 per l'acciaio normale (235 N/mm²), 0,78 per 315, 0,72 per 355 e 0,68 per 390 N/mm²; per valori intermedi si interpola. Le tensioni ammesse delle regole si dividono per k (per esempio 175/k e 110/k N/mm² per la robustezza longitudinale, UR S11), e i moduli di resistenza richiesti si moltiplicano per k. Per le lamiere sotto pressione laterale lo spessore richiesto è proporzionale a √k: con AH36, √0,72 = 0,85, cioè circa il 15 % in meno. Nota UR S4: per l'acciaio a 390 N/mm² k può valere 0,66 se si fa una verifica a fatica; non si applica alle navi CSR. Attenzione: il modulo elastico non cambia, quindi strutture più sottili si deformano di più e sono più sensibili a instabilità e fatica (seconda parte).")

# ---------------- 15 Dove va quale grado ----------------
def d15():
    o = [grid('CSR: classe del materiale per spessore', ['t (mm)', 'Classe I', 'Classe II', 'Classe III'], [
        ('≤ 15', 'A / AH', 'A / AH', 'A / AH'), ('15–20', 'A / AH', 'A / AH', 'B / AH'), ('20–25', 'A / AH', 'B / AH', 'D / DH'),
        ('25–30', 'A / AH', 'D / DH', 'D / DH'), ('30–40', 'B / AH', 'D / DH', 'E / EH'), ('40–50', 'D / DH', 'E / EH', 'E / EH')],
        [28, 150, 314, 476], y0=58, rh=40, size=15, fills=[None, None, None, None, None, None])]
    o.append(T(28, 360, 'Classe III a centro nave (0,4 L): cinta, trincarino,', 14, True, RUST, maxw=610))
    o.append(T(28, 382, 'corso del ginocchio, mastre lunghe, angoli dei boccaporti', 14, True, RUST, maxw=610))
    o.append(T(28, 410, 'Classe II: fondo, chiglia, ponte resistente · Classe I: fianco', 14, False, INK, maxw=610))
    o.append(T(28, 432, 'Pt 1 Ch 3 Sec 1, tabelle 3 e 7 · navi oltre 250 m: cinta e trincarino E/EH', 13, False, GRAY, maxw=610))
    return ''.join(o)
add(E4, 'Dove va quale grado',
    ['Ogni elemento ha una **classe** (I, II, III)',
     'Classe e **spessore** danno il grado minimo',
     'Classe **III** dove le tensioni sono massime',
     'A bordo c\'è il **piano dei gradi** di acciaio'],
    'tabella CSR dei gradi minimi per classe e spessore', d15(),
    "CSR edizione 1 luglio 2025, Pt 1 Ch 3 Sec 1, [2.3] e tabelle 3–7. Ogni elemento strutturale appartiene a una categoria (secondaria, primaria, speciale) che corrisponde a una classe di materiale I, II o III, diversa dentro e fuori 0,4 L a centro nave. La tabella 7 dà il grado minimo in funzione della classe e dello spessore di costruzione (riprodotta fino a 50 mm). Esempi della tabella 3: cinta, trincarino, corso del ponte alla paratia longitudinale, corso del ginocchio e mastre longitudinali più lunghe di 0,15 L sono di classe III entro 0,4 L; fondo, chiglia e ponte resistente di classe II; fianco e paratie longitudinali di classe I. Tabelle 4–6: oltre 150 m il ponte resistente almeno B/AH entro 0,4 L; oltre 250 m cinta e trincarino almeno E/EH, corso del ginocchio D/DH; nelle portarinfuse a fianco singolo oltre 150 m i braccioli inferiori delle ossature e il fasciame vicino alla tramoggia almeno D/DH. CSR [2.1.5]: a bordo deve esserci un piano con i tipi e i gradi di acciaio usati. Serve in ogni riparazione.")

# ---------------- 16 Freddo e spessori elevati ----------------
def d16():
    o = [head('Oltre i gradi normali')]
    o.append(tile(28, 60, 298, 170, 'Basse temperature', 'navi in zone fredde e polari: gradi scelti con la temperatura di progetto (CSR Ch 1 Sec 2 [3.4.4]; Polar Code)', 'b', 16, 14))
    o.append(tile(340, 60, 298, 170, 'Spessori elevati', 'portacontenitori: mastre e ponte oltre 50 mm, acciai YP47 (460 N/mm²) e crack arrest (UR W31, S33)', 'r', 16, 14))
    o.append(grid(None, ['Suffisso W31', 'Spessore', 'Kca a −10 °C'], [('BCA1', '50–100 mm', '≥ 6 000 N/mm^1,5'), ('BCA2', '80–100 mm', '≥ 8 000 N/mm^1,5')], [28, 230, 420], y0=256, rh=44, size=15))
    o.append(T(28, 410, 'esempio di marcatura: EH47-BCA1', 15, True, RUST, maxw=610))
    o.append(T(28, 432, 'crack arrest = ferma una cricca fragile già partita', 14, False, GRAY, maxw=610))
    return ''.join(o)
add(E4, 'Freddo e spessori elevati',
    ['Al **freddo** servono gradi più tenaci',
     'Lamiere **molto spesse**: tenacità più difficile',
     'Acciai **YP47**: 460 N/mm² per le portacontenitori',
     'Acciai **crack arrest** fermano la cricca'],
    'acciai per basse temperature e per grandi spessori', d16(),
    "Due casi oltre la tabella dei gradi. Basse temperature: per navi destinate a zone con basse temperature dell'aria le CSR rimandano a Pt 1 Ch 1 Sec 2 [3.4.4] e ai regolamenti della società; per le navi polari il Polar Code e i requisiti IACS per le Polar Class scelgono il grado in base alla temperatura di progetto della struttura esposta. Spessori elevati: sulle grandi portacontenitori le mastre e il ponte superano 50 mm; più una lamiera è spessa, più è difficile garantirne la tenacità. IACS UR W31 Rev.3 (2023) definisce gli acciai YP47 (snervamento minimo 460 N/mm², per il ponte e le mastre delle portacontenitori, spessori tra 50 e 100 mm) e gli acciai crack arrest, che fermano una cricca fragile già partita: suffisso BCA1 (50–100 mm, tenacità all'arresto Kca a −10 °C almeno 6 000 N/mm^1,5) e BCA2 (80–100 mm, almeno 8 000). L'uso è regolato dalla UR S33. Per un ufficiale di macchina interessa sapere che esistono e che non si sostituiscono con acciai ordinari in riparazione.")

# ---------------- 17 Grado Z ----------------
def d17():
    o = [head('Proprietà nello spessore: acciaio Z')]
    o.append(R(80, 150, 300, 30, '#C9D6DE', HULL, 2, 0))
    o.append(R(215, 60, 30, 90, '#C9D6DE', HULL, 2, 0))
    o.append(P([(200, 150), (215, 135), (215, 150)], STEEL, INK, 1.5)); o.append(P([(245, 150), (245, 135), (260, 150)], STEEL, INK, 1.5))
    for i in range(5):
        x = 150 + i * 30
        o.append(L(x, 158 + (i % 2) * 6, x + 22, 158 + (i % 2) * 6, RUST, 2.5))
    o.append(A(230, 240, 230, 196, RUST, 2.5, 8)); o.append(T(244, 236, 'trazione nello spessore', 13, True, RUST))
    o.append(T(392, 170, 'strappo lamellare', 13, True, RUST))
    o.append(grid(None, ['Qualità (W14)', 'Strizione media', 'Minimo singolo'], [('Z25', '≥ 25 %', '≥ 15 %'), ('Z35', '≥ 35 %', '≥ 25 %')], [28, 240, 440], y0=274, rh=44, size=15))
    o.append(T(28, 430, 'esempio di designazione: EH36Z35', 15, True, BLUE, maxw=610))
    return ''.join(o)
add(E4, 'Proprietà nello spessore (grado Z)',
    ['Giunti a **T** e a croce tirano **nello spessore**',
     'Rischio: **strappo lamellare**',
     'Acciai **Z25** e **Z35**: strizione garantita',
     'Si scrive dopo il grado: **EH36Z35**'],
    'strappo lamellare e acciai con proprietà nello spessore', d17(),
    "Quando un giunto a T o a croce a piena penetrazione tira la lamiera perpendicolarmente alla sua superficie, inclusioni allungate dalla laminazione possono aprirsi a gradini: è lo strappo lamellare (lamellar tearing), che compare durante la fabbricazione. IACS UR W14 Rev.3 (2021) definisce due qualità: Z25 per le applicazioni navali normali e Z35 per quelle più severe, caratterizzate dalla strizione in una prova di trazione nello spessore: media di almeno tre provini 25 % (minimo singolo 15 %) e 35 % (minimo singolo 25 %). La designazione si aggiunge al grado (EH36Z25, EH36Z35). Le CSR (Pt 1 Ch 3 Sec 1 [2.5]) chiedono di considerarli dove giunti a T o a croce trasmettono tensioni di trazione significative nello spessore; tipico: lamiere di testa delle mastre, attacchi di grandi bracciali, fondazioni di macchinari pesanti.")

# ---------------- 18 Profilati e tolleranze ----------------
def d18():
    o = [head('Profilati e tolleranze di spessore')]
    shapes = [('bulbo (HP)', 70), ('angolare', 230), ('T saldato', 390), ('piatto', 550)]
    for name, x in shapes:
        o.append(R(x - 6, 70, 12, 120, '#C9D6DE', HULL, 2, 0))
        if name == 'bulbo (HP)':
            o.append(C(x + 6, 182, 12, '#C9D6DE', HULL, 2))
        elif name == 'angolare':
            o.append(R(x - 6, 178, 60, 12, '#C9D6DE', HULL, 2, 0))
        elif name == 'T saldato':
            o.append(R(x - 34, 178, 68, 12, '#C9D6DE', HULL, 2, 0))
        o.append(R(x - 50, 58, 100, 12, STEEL, INK, 1, 0))
        o.append(T(x, 222, name, 14, True, INK, 'middle'))
    o.append(R(28, 260, 610, 170, SOFTB, BLUE, 2, 10))
    o.append(T(44, 290, 'Tolleranza negativa sullo spessore (UR W13)', 15, True, BLUE, maxw=580))
    o.append(T(44, 318, 'acciai W11 e W16: −0,3 mm per qualunque spessore', 15, False, INK, maxw=580))
    o.append(T(44, 344, 'la media misurata non può stare sotto il nominale', 14, False, INK, maxw=580))
    o.append(T(44, 370, 'conta per le spessimetrie: il "nuovo" non è', 14, False, INK, maxw=580))
    o.append(T(44, 392, 'mai esattamente il nominale', 14, False, INK, maxw=580))
    return ''.join(o)
add(E4, 'Profilati e tolleranze',
    ['**Bulbi**, angolari, T saldati, piatti',
     'Stessi gradi e requisiti delle **lamiere**',
     'Tolleranza negativa: **0,3 mm** (UR W13)',
     'Utile per leggere le **spessimetrie**'],
    'profilati comuni e tolleranza di spessore', d18(),
    "Rinforzi ordinari: profilati a bulbo (Holland Profile, HP), angolari, T saldati da piatti, piatti semplici. Hanno gli stessi gradi e requisiti delle lamiere (UR W11 si applica a lamiere, larghi piatti, profilati e barre). Tolleranze di spessore: IACS UR W13 Rev.7 (2021) fissa per i prodotti secondo UR W11 e W16 una tolleranza negativa sullo spessore nominale di 0,3 mm indipendentemente dallo spessore, e richiede che la media delle misure non sia inferiore al nominale (classe C della ISO 7452 o equivalente). Le tolleranze positive e di planarità seguono le norme nazionali. Collegamento con l'ESP e con la lezione 3: lo spessore misurato su una nave nuova può essere diverso dal nominale entro queste tolleranze, e i criteri di rinnovo partono dallo spessore di costruzione.")

# ---------------- 19 Marcatura ----------------
def d19():
    o = [head('Marcatura di una lamiera (W11, 16)')]
    o.append(R(40, 60, 586, 150, '#C9D6DE', HULL, 2, 4))
    o.append(C(140, 135, 46, 'none', RUST, 3))
    o.append(T(140, 130, 'CLASSE', 14, True, RUST, 'middle')); o.append(T(140, 150, 'timbro', 13, False, RUST, 'middle'))
    o.append(T(220, 112, 'EH36 TM Z35', 22, True, INK)); o.append(T(220, 144, 'ACCIAIERIA · colata 4A1234 · pezzo 07', 16, False, INK, maxw=390))
    o.append(T(220, 172, 'ordine 5521 · scafo 2215', 15, False, GRAY, maxw=390))
    o.append(rows('', [('Grado', 'sigla unificata: A, A36, EH36 …', 'b'), ('Suffissi', 'S = approvazione speciale, TM, Z25/Z35, BCA', 'b'),
                       ('Origine', 'acciaieria, colata, numero del pezzo', 'g'), ('Timbro', 'della società di classifica', 'r')], y0=226, lw=110, size=14))
    return ''.join(o)
add(E5, 'Marcatura e timbro della classe',
    ['Ogni pezzo porta **grado** e **timbro** della classe',
     'Suffissi: **TM**, **Z35**, **S**, **BCA**',
     '**Colata** e numero del pezzo: tracciabilità',
     'Marcatura **cerchiata** di vernice'],
    'esempio di marcatura su una lamiera, schema', d19(),
    "IACS UR W11 Rev.9, paragrafo 16: ogni pezzo finito è marcato dal produttore in almeno un punto con il timbro della società di classifica e con: la sigla unificata del grado (A, A36, EH36); la lettera S per acciai approvati in modo speciale che si scostano dai requisiti (A36S); TM per gli acciai termomeccanici quando richiesto; nome o sigla dell'acciaieria; numero di colata o del pezzo; se richiesto, l'ordine dell'acquirente. Si aggiungono le designazioni Z (UR W14), BCA (UR W31) e, per gli acciai resistenti alla corrosione delle cisterne di petroliere, RCU, RCB o RCW (esempio della UR: A36 TM RCB Z35). La marcatura è cerchiata con vernice per riconoscerla (16.3); per materiali leggeri in fasci può bastare un cartellino (16.4); se un pezzo non supera le prove il timbro va cancellato (16.5). L'esempio della figura è inventato.")

# ---------------- 20 Certificato ----------------
def d20():
    return grid('Certificato di collaudo: che cosa contiene', ['Voce (W11, 17.1)', 'Esempio'], [
        ('Ordine e scafo', 'ordine 5521, costruzione 2215'), ('Colata e pezzo', '4A1234 · pezzo 07 · provino 3'),
        ('Acciaieria', 'nome dello stabilimento'), ('Grado', 'EH36 TM Z35'),
        ('Analisi di colata', 'C 0,15 · Mn 1,45 · Si 0,30 · P 0,012 · S 0,004'), ('Stato di fornitura', 'TM'),
        ('Prove', 'ReH 392 · Rm 528 · A 26 % · KV −40 °C: 112-98-120 J'), ('Firma', 'produttore e ispettore della classe')],
        [28, 210], y0=58, rh=42, size=14)
add(E5, 'Il certificato di collaudo',
    ['Accompagna ogni **fornitura** di acciaio',
     '**Analisi**, stato di fornitura, **prove**',
     'Firmato dal **produttore** e dalla **classe**',
     'Si conserva con la **documentazione** della nave'],
    'contenuto minimo del certificato secondo la UR W11', d20(),
    "IACS UR W11 Rev.9, paragrafo 17: per ogni fornitura accettata l'ispettore riceve certificati di collaudo o bolle che riportano almeno: ordine dell'acquirente e, se noto, numero dello scafo; identificazione di colata, pezzo e provino; acciaieria; grado; analisi di colata degli elementi delle tabelle 1 e 2; stato di fornitura se diverso da laminato; eventuale impiego di acciaio effervescente per profilati A fino a 12,5 mm; risultati delle prove. Prima della firma dell'ispettore il produttore dichiara che il materiale è stato prodotto con un processo approvato e provato secondo le regole della società (17.2), e il nome della società compare sul certificato. Il certificato della figura è un esempio didattico con valori plausibili: si usa nell'esercizio della slide seguente.")

# ---------------- 21 Esercizio ----------------
def d21():
    o = [head('Esercizio: il materiale è conforme?')]
    qs = [('1', 'ReH 392, Rm 528, A 26 %: va bene per un EH36?'),
          ('2', 'KV a −40 °C: 112, 98, 120 J. Supera il requisito?'),
          ('3', 'Calcola il Ceq dall\'analisi: va bene per un 36 TM?'),
          ('4', 'Potrei usare questa lamiera al posto di un DH36?'),
          ('5', 'E al posto di un EH40?')]
    for i, (n, q) in enumerate(qs):
        y = 62 + i * 74
        o.append(R(28, y, 610, 62, SOFTY, YEL, 2, 9)); o.append(T(46, y + 38, n, 20, True, '#7A5200'))
        o.append(T(76, y + 37, q, 16, True, INK, maxw=548))
    return ''.join(o)
add(E5, 'Esercizio: leggere il certificato',
    ['Usare il **certificato** della slide precedente',
     'Confrontare con le **tabelle W11**',
     'Rispondere a **coppie** in 5 minuti',
     'Soluzione nelle note e alla **ripresa**'],
    'cinque domande sul certificato di esempio', d21(),
    "Soluzione. 1) Sì: EH36 richiede ReH ≥ 355, Rm 490–630, A ≥ 21 %. 2) Sì: media (112+98+120)/3 = 110 J, molto sopra 34 J; nessun valore sotto il 70 % di 34 J. 3) No: Ceq = 0,15 + 1,45/6 = 0,39 % (gli altri elementi non sono dichiarati, quindi sono trascurati); per un grado 36 TM fino a 50 mm la UR W11 (tabella 3) ammette al massimo 0,38 %. Le prove meccaniche sono buone, ma la chimica no: la classe non accetta la lamiera come EH36 TM. È il messaggio dell'esercizio: si leggono tutte le righe del certificato. 4) Sì: un EH36 ha la stessa resistenza di un DH36 ed è provato a temperatura più bassa; il grado superiore sostituisce quello inferiore con lo stesso livello di resistenza, ma ogni sostituzione va accettata dalla classe. 5) No: EH40 ha snervamento 390 N/mm²; un EH36 è meno resistente e richiederebbe spessori maggiori.")

# ---------------- 22 Sintesi ----------------
def d22():
    o = [head('Sintesi e tre domande per la pausa')]
    sm = [('Proprietà', 'ReH, Rm, A, KV, Ceq', 'b'), ('Gradi', 'A–E, AH–FH 32/36/40', 'b'),
          ('Dove', 'classi I, II, III e spessore', 'r'), ('Documenti', 'marcatura e certificato', 'g')]
    bw = (610 - 14) / 2
    for i, (t, s, k) in enumerate(sm):
        o.append(tile(28 + (i % 2) * (bw + 14), 62 + (i // 2) * 82, bw, 70, t, s, k, 16, 14))
    qs = ['Che differenza c\'è tra un grado A e un grado E?', 'Che cosa indica il numero in "AH36"?', 'Perché la cinta a centro nave è di classe III?']
    for i, q in enumerate(qs):
        y = 242 + i * 64
        o.append(R(28, y, 610, 54, SOFTY, YEL, 2, 9)); o.append(T(44, y + 34, f'{i + 1}', 20, True, '#7A5200'))
        o.append(T(72, y + 33, q, 16, True, INK, maxw=552))
    return ''.join(o)
add('PARTE 1 · SINTESI', 'Sintesi della prima parte',
    ['Prove: **trazione**, **Charpy**, carbonio equivalente',
     'Gradi: lettera = **tenacità**, numero = **resistenza**',
     'Classi di materiale: dove **serve** tenacità',
     '**Marcatura** e certificato: la tracciabilità'],
    'sintesi e domande di richiamo', d22(),
    "Chiudere la prima parte con i quattro concetti e lasciare tre domande per la pausa; risposte alla ripresa (slide 23). Risposte attese: 1) stessa resistenza (235 N/mm²), diversa tenacità: A non è provato a Charpy fino a 50 mm, E garantisce 27 J a −40 °C; inoltre E è calmato, a grano fine e normalizzato o TM. 2) il livello di snervamento: 36 → 355 N/mm² (dal vecchio valore di 36 kgf/mm²); la H indica alta resistenza. 3) perché a centro nave la cinta, insieme al trincarino, porta le tensioni massime della flessione della trave-scafo ed è il punto da cui una cricca fragile può propagarsi lungo il fianco o il ponte: serve la tenacità più alta (D/DH o E/EH secondo lo spessore).")
